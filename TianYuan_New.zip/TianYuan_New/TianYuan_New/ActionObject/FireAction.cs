﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TianYuan_New.ActionObject
{
    class FireAction
    {
        /// <summary>
        /// 守灵厅办理 01
        /// </summary>
        public static int FireSales_01(string ac001,string si001,decimal nums,DateTime so005 ,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness01", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //守灵厅编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;
            //存放天数
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;
            //存放开始时间
            OracleParameter op_so005 = new OracleParameter("id_so005", OracleDbType.Date);
            op_so005.Direction = ParameterDirection.Input;
            op_so005.Value = so005;
            //经办人
            OracleParameter op_handler= new OracleParameter("ic_handler", OracleDbType.Varchar2,10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2,100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001, op_nums, op_so005, op_handler, appcode , apperror });
                cmd.ExecuteNonQuery();

                if(int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(),"错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 冷藏办理 02
        /// </summary>
        public static int FireSales_02(string ac001, string si001, decimal nums, DateTime so005, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness02", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //冷餐柜编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;
            //存放天数
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;
            //存放开始时间
            OracleParameter op_so005 = new OracleParameter("id_so005", OracleDbType.Date);
            op_so005.Direction = ParameterDirection.Input;
            op_so005.Value = so005;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001, op_nums, op_so005, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 休息室办理 03
        /// </summary>
        public static int FireSales_03(string ac001, string si001,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness03", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //冷餐柜编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;
      
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        //获取逝者办理的休息室 
        public static string GetRestRoomList(string ac001)
        {
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;

            return SqlAssist.ExecuteScalar("select pkg_business.fun_getRestRoomList(:ac001) from dual", new OracleParameter[] { op_ac001 }).ToString();
        }

        //获取逝者告别时间
        public static Object GetGBTime(string ac001)
        {
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            Object re = SqlAssist.ExecuteScalar("select ac018 from ac01 where ac001 = :ac001", new OracleParameter[] { op_ac001 });
            return re;         
        }

        //获取逝者火化时间
        public static Object GetHHTime(string ac001)
        {
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            Object re = SqlAssist.ExecuteScalar("select ac015 from ac01 where ac001 = :ac001", new OracleParameter[] { op_ac001 });
            return re;
        }


        /// <summary>
        /// 告别办理
        /// </summary>
        /// <param name="ac001"></param>
        /// <param name="si001"></param>
        /// <param name="so005"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FireSales_04(string ac001, string si001, DateTime so005, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness04", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //告别厅编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;   
            //存放开始时间
            OracleParameter op_so005 = new OracleParameter("id_so005", OracleDbType.Date);
            op_so005.Direction = ParameterDirection.Input;
            op_so005.Value = so005;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001, op_so005, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 灵车办理
        /// </summary>
        /// <param name="ac001"></param>
        /// <param name="si001"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FireSales_07(string ac001, string si001,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness07", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //灵车编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;

            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 火化办理
        /// </summary>
        /// <param name="ac001"></param>
        /// <param name="si001"></param>
        /// <param name="so005"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FireSales_06(string ac001, string si001, DateTime so005, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusiness06", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //火化标准编号
            OracleParameter op_si001 = new OracleParameter("ic_si001", OracleDbType.Varchar2, 10);
            op_si001.Direction = ParameterDirection.Input;
            op_si001.Value = si001;
            //火化时间
            OracleParameter op_so005 = new OracleParameter("id_so005", OracleDbType.Date);
            op_so005.Direction = ParameterDirection.Input;
            op_so005.Value = so005;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_si001, op_so005, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public static int FireSales_Misc(string ac001, string itemId, int nums,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusinessMisc", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //项目编号
            OracleParameter op_itemId = new OracleParameter("ic_itemId", OracleDbType.Varchar2, 10);
            op_itemId.Direction = ParameterDirection.Input;
            op_itemId.Value = itemId;
            //数量
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_itemId, op_nums, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 删除销售记录
        /// </summary>
        /// <returns></returns>
        public static int FireBusinessRemove(string sa001)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusinessRemove", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //销售编号
            OracleParameter op_sa001 = new OracleParameter("ic_sa001", OracleDbType.Varchar2, 10);
            op_sa001.Direction = ParameterDirection.Input;
            op_sa001.Value = sa001;
           

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_sa001, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 应用套餐
        /// </summary>
        /// <param name="sa001"></param>
        /// <returns></returns>
        public static int ApplyUserCombo(string ac001,string cb001,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_ApplyUserCombo", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //套餐编号
            OracleParameter op_cb001 = new OracleParameter("ic_cb001", OracleDbType.Varchar2, 10);
            op_cb001.Direction = ParameterDirection.Input;
            op_cb001.Value = cb001;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001,op_cb001,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 销售项目修改
        /// </summary>
        /// <param name="sa001"></param>
        /// <param name="price"></param>
        /// <param name="nums"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FireBusinessEdit(string sa001, decimal price,decimal nums, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusinessEdit", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //销售记录编号
            OracleParameter op_sa001 = new OracleParameter("ic_sa001", OracleDbType.Varchar2, 10);
            op_sa001.Direction = ParameterDirection.Input;
            op_sa001.Value = sa001;
            //单价
            OracleParameter op_price= new OracleParameter("in_price", OracleDbType.Decimal);
            op_price.Direction = ParameterDirection.Input;
            op_price.Value = price;
            //数量
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;

            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_sa001, op_price,op_nums, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public static int FireBusinessSettle(string settleId, string ac001, string[] sa001_arry, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireBusinessSettle", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //结算流水号
            OracleParameter op_settleId = new OracleParameter("ic_settleId", OracleDbType.Varchar2, 10);
            op_settleId.Direction = ParameterDirection.Input;
            op_settleId.Value = settleId;
            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //销售记录编号数组
            OracleParameter op_sa001_arry = new OracleParameter("ic_sa001_arry", OracleDbType.Varchar2);
            op_sa001_arry.Direction = ParameterDirection.Input;
            op_sa001_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_sa001_arry.Value = sa001_arry;

            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_settleId, op_ac001, op_sa001_arry, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        
        public static string GetOperatorName(string uc001)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_OperatorMapper", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 50);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_uc001 = new OracleParameter("ic_uc001", OracleDbType.Varchar2, 10);
            op_uc001.Direction = ParameterDirection.Input;
            op_uc001.Size = 50;
            op_uc001.Value = uc001;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_uc001);

                cmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }

        /// <summary>
        /// 判断火化业务是否结算
        /// </summary>
        /// <param name="ac001"></param>
        /// <returns></returns>
        public static string FireIsSettled(string ac001)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_FireIsSettled", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 3);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Size = 10;
            op_ac001.Value = ac001;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_ac001);

                cmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }

        /// <summary>
        /// 打印火化证明
        /// </summary>
        /// <param name="ac001"></param>
        public static void Print_HHZM(string ac001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            int result = PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Fire_HHZM",
                                         ac001,
                                         null
                );
            if (result > 0)
            {  //记录火化证明打印日志
                PrtServAction.FireCertLog(ac001, Envior.cur_userId);
            }
        }

        /// <summary>
        /// 打印收据
        /// </summary>
        /// <param name="settleId"></param>
        public static void Print_invoice(string settleId)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Fire_invoice",
                                         settleId,
                                         null
                );
        }


        /// <summary>
        /// 财务作废
        /// </summary>
        /// <param name="fa001"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FinanceRemove(string fa001,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FinanceRemove", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //结算流水号
            OracleParameter op_fa001 = new OracleParameter("ic_fa001", OracleDbType.Varchar2, 10);
            op_fa001.Direction = ParameterDirection.Input;
            op_fa001.Value = fa001;
    
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_fa001,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        ////财务类别统计
        public static int ClassStat(string accountId,string dbegin, string dend, string[] class_arry,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_report.prc_ClassStat", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;
            //帐套
            OracleParameter op_accountId= new OracleParameter("accountId", OracleDbType.Varchar2, 3);
            op_accountId.Direction = ParameterDirection.Input;
            op_accountId.Value = accountId;

            //统计日期1
            OracleParameter op_begin = new OracleParameter("ic_begin", OracleDbType.Varchar2, 16);
            op_begin.Direction = ParameterDirection.Input;
            op_begin.Value = dbegin;
            //统计日期2
            OracleParameter op_end = new OracleParameter("ic_end", OracleDbType.Varchar2,16);
            op_end.Direction = ParameterDirection.Input;
            op_end.Value = dend;

            //销售记录编号数组
            OracleParameter op_class_arry = new OracleParameter("ic_class", OracleDbType.Varchar2);
            op_class_arry.Direction = ParameterDirection.Input;
            op_class_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_class_arry.Value = class_arry;

            //收费员
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_accountId,op_begin,op_end,op_class_arry,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }

        }

        /// <summary>
        /// 火化登记记录删除
        /// </summary>
        /// <param name="ac001"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int RemoveFireCheckin(string ac001,string handler)
        {
            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;

            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            return SqlAssist.ExecuteProcedure("pkg_business.prc_RemoveFireCheckin", new OracleParameter[] { op_ac001, op_handler });
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="uc001"></param>
        /// <param name="newPwd"></param>
        /// <returns></returns>
        public static int ModifyPwd(string uc001,string newPwd)
        {
            //操作员编号
            OracleParameter op_uc001 = new OracleParameter("ic_uc001", OracleDbType.Varchar2, 10);
            op_uc001.Direction = ParameterDirection.Input;
            op_uc001.Value = uc001;

            //新密码
            OracleParameter op_newpwd = new OracleParameter("ic_newPwd", OracleDbType.Varchar2, 50);
            op_newpwd.Direction = ParameterDirection.Input;
            op_newpwd.Value = newPwd;

            return SqlAssist.ExecuteProcedure("pkg_business.prc_Modify_Pwd", new OracleParameter[] { op_uc001, op_newpwd });
        }




        /// <summary>
        /// 根据逝者编号判断 帐套 编号
        /// </summary>
        /// <param name="uc001"></param>
        /// <returns></returns>
        public static string GetAccountIdByAc001(string ac001)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_getAccountIdByAc001", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 3);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Size = 10;
            op_ac001.Value = ac001;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_ac001);

                cmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }

        public static int GrantRights(string ro001,string[] ri001_arry,string[] right_arry)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_GrantRights", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //角色编号
            OracleParameter op_ro001 = new OracleParameter("ic_ro001", OracleDbType.Varchar2, 10);
            op_ro001.Direction = ParameterDirection.Input;
            op_ro001.Value = ro001;
            //功能编号数组
            OracleParameter op_ri001_arry = new OracleParameter("ri001_arry", OracleDbType.Varchar2);
            op_ri001_arry.Direction = ParameterDirection.Input;
            op_ri001_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_ri001_arry.Value = ri001_arry;

            //授权数组
            OracleParameter op_right_arry = new OracleParameter("right_arry", OracleDbType.Varchar2);
            op_right_arry.Direction = ParameterDirection.Input;
            op_right_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_right_arry.Value = right_arry;
 
            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ro001, op_ri001_arry,op_right_arry, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        
    }
}
