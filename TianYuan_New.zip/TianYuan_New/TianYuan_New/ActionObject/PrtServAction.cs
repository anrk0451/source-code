﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace TianYuan_New.ActionObject
{
    /// <summary>
    /// 打印服务程序
    /// </summary>
    class PrtServAction
    {
        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);
 
        public static int Connect(int connId,int prtservHandle,int clientHandle)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_ConnectPrtServ", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //连接Id
            OracleParameter op_connId = new OracleParameter("in_connectId", OracleDbType.Int32, 10);
            op_connId.Direction = ParameterDirection.Input;
            op_connId.Value = connId;
            //打印服务窗口Handle
            OracleParameter op_servHandle = new OracleParameter("in_servHandle", OracleDbType.Int32);
            op_servHandle.Direction = ParameterDirection.Input;
            op_servHandle.Value = prtservHandle;
            //打印客户端窗口
            OracleParameter op_clientHandle = new OracleParameter("in_clientHandle", OracleDbType.Int32);
            op_clientHandle.Direction = ParameterDirection.Input;
            op_clientHandle.Value = clientHandle;
            
            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_connId, op_servHandle, op_clientHandle,appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        /// <summary>
        /// 发送打印命令
        /// </summary>
        /// <param name="connId"></param>
        /// <param name="clientHandle"></param>
        /// <param name="commandNum"></param>
        /// <param name="commandString"></param>
        /// <param name="para1"></param>
        /// <param name="para2"></param>
        /// <returns></returns>
        public static int SendPrtCommand(int connId, int clientHandle,int commandNum,string commandString,string para1,string para2)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_SendPrtCommand", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //连接Id
            OracleParameter op_connId = new OracleParameter("in_connectId", OracleDbType.Int32, 10);
            op_connId.Direction = ParameterDirection.Input;
            op_connId.Value = connId;
            //打印客户端窗口
            OracleParameter op_clientHandle = new OracleParameter("in_clientHandle", OracleDbType.Int32);
            op_clientHandle.Direction = ParameterDirection.Input;
            op_clientHandle.Value = clientHandle;
            //打印命令编号
            OracleParameter op_commandNum = new OracleParameter("in_commandNum", OracleDbType.Int32);
            op_commandNum.Direction = ParameterDirection.Input;
            op_commandNum.Value = commandNum;
            //打印命令字符串
            OracleParameter op_commandString = new OracleParameter("ic_commandString", OracleDbType.Varchar2,50);
            op_commandString.Direction = ParameterDirection.Input;
            op_commandString.Value = commandString;
            //参数1
            OracleParameter op_para1 = new OracleParameter("ic_para1", OracleDbType.Varchar2, 50);
            op_para1.Direction = ParameterDirection.Input;
            op_para1.Value = para1;
            //参数2
            OracleParameter op_para2 = new OracleParameter("ic_para2", OracleDbType.Varchar2, 50);
            op_para2.Direction = ParameterDirection.Input;
            op_para2.Value = para2;


            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_connId, op_clientHandle,op_commandNum,op_commandString,op_para1,op_para2, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
                trans.Commit();

                SendMessage(Envior.prtservHandle, 0x2710, commandNum, 0);

                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        
        /// <summary>
        /// 生成新的命令编号
        /// </summary>
        /// <returns></returns>
        public static int GenNewCommandNum()
        {
            int result = int.Parse(SqlAssist.ExecuteScalar("select seq_prtserv.nextVal from dual", null).ToString());
            return result;
        }

        /// <summary>
        /// 返回打印服务响应
        /// </summary>
        /// <param name="commandNum"></param>
        /// <returns></returns>
        public static string GetResponseText(int commandNum)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_getResponseText ", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 100);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_commandNum = new OracleParameter("in_commandNum", OracleDbType.Int32);
            op_commandNum.Direction = ParameterDirection.Input;
            op_commandNum.Value = commandNum;
 
            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_commandNum);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString(); 
        }

        /// <summary>
        /// 记录 打印火化证明
        /// </summary>
        /// <param name="ac001"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int FireCertLog(string ac001,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_FireCertLog", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_ac001 = new OracleParameter("ic_ac001", OracleDbType.Varchar2, 10);
            op_ac001.Direction = ParameterDirection.Input;
            op_ac001.Value = ac001;
            //经办人
            OracleParameter op_fc100 = new OracleParameter("ic_fc100", OracleDbType.Varchar2, 10);
            op_fc100.Direction = ParameterDirection.Input;
            op_fc100.Value = handler;
             
            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_ac001, op_fc100,appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }




    }
}
