﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace TianYuan_New.ActionObject
{
    /// <summary>
    /// 寄存处理类
    /// </summary>
    class RegisterAction
    {
        //[DllImport("fr606.dll", EntryPoint = "OpenCom", SetLastError = true, CharSet = CharSet.Auto)]
        //public static extern int OpenCom([MarshalAs(UnmanagedType.LPArray)] byte[] comport, long baud);

        //[DllImport("fr606.dll", EntryPoint = "Reset", SetLastError = true, CharSet = CharSet.Auto)]
        //public static extern int Reset();

        //[DllImport("fr606.dll", EntryPoint = "CloseCom", SetLastError = true, CharSet = CharSet.Auto)]
        //public static extern int CloseCom();

        //[DllImport("fr606.dll", EntryPoint = "ReadData", SetLastError = true, CharSet = CharSet.Auto)]
        //public static extern int ReadData([MarshalAs(UnmanagedType.LPArray)] byte[] track2, [MarshalAs(UnmanagedType.LPArray)] byte[] track3 ,int track);

        //[DllImport("fr606.dll", EntryPoint = "WriteData", SetLastError = true, CharSet = CharSet.Auto)]
        //public static extern int WriteData([MarshalAs(UnmanagedType.LPArray)] byte[] track2, [MarshalAs(UnmanagedType.LPArray)] byte[] track3, int track);

        //获取附品价格
        public static decimal GetFixPrice(string itemId)
        {
            OracleParameter op_itemId= new OracleParameter("ic_ItemId", OracleDbType.Varchar2, 10);
            op_itemId.Direction = ParameterDirection.Input;
            op_itemId.Value = itemId;
            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getFixPrice(:ic_ItemId) from dual", new OracleParameter[] { op_itemId });
            return decimal.Parse(re.ToString());
        }

        //获取号位状态
        public static string GetBitStatus(string regionId,string bitDesc)
        {
            OracleParameter op_regionId = new OracleParameter("ic_regionId", OracleDbType.Varchar2, 10);
            op_regionId.Direction = ParameterDirection.Input;
            op_regionId.Value = regionId;

            OracleParameter op_bitDesc = new OracleParameter("ic_bitdesc", OracleDbType.Varchar2, 50);
            op_bitDesc.Direction = ParameterDirection.Input;
            op_bitDesc.Value = bitDesc;

            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getBitStatus(:ic_regionId,:ic_bitdesc) from dual", new OracleParameter[] { op_regionId, op_bitDesc });
            return re.ToString();
        }

        /// <summary>
        /// 生成新的寄存证号
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static string GenRegisterNo(string type)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.GenRegisterNo", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 50);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_type = new OracleParameter("ic_Type", OracleDbType.Varchar2, 3);
            op_type.Direction = ParameterDirection.Input;
            op_type.Value = type;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_type);
                cmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("生成寄存证号错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }

        //获取号位地址
        public static string GetBitFullName(string regionId,string bitDesc)
        {
            OracleParameter op_regionId = new OracleParameter("ic_regionId", OracleDbType.Varchar2, 10);
            op_regionId.Direction = ParameterDirection.Input;
            op_regionId.Value = regionId;

            OracleParameter op_bitDesc = new OracleParameter("ic_bitdesc", OracleDbType.Varchar2, 50);
            op_bitDesc.Direction = ParameterDirection.Input;
            op_bitDesc.Value = bitDesc;

            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getBitFullName(:ic_regionId,:ic_bitdesc) from dual", new OracleParameter[] { op_regionId, op_bitDesc });
            return re.ToString();
        }

        //获取号位地址
        public static string GetRegPathName(string rc001)
        {
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;
 
            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getRegPathName(:ic_rc001) from dual", new OracleParameter[] { op_rc001 });
            return re.ToString();
        }

        //根据寄存架号+号位描述 返回寄存号位编号
        public static string GetBitId(string regionId, string bitDesc)
        {
            OracleParameter op_regionId = new OracleParameter("ic_regionId", OracleDbType.Varchar2, 10);
            op_regionId.Direction = ParameterDirection.Input;
            op_regionId.Value = regionId;

            OracleParameter op_bitDesc = new OracleParameter("ic_bitdesc", OracleDbType.Varchar2, 50);
            op_bitDesc.Direction = ParameterDirection.Input;
            op_bitDesc.Value = bitDesc;
 
            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getBitId(:ic_regionId,:ic_bitdesc) from dual", new OracleParameter[] { op_regionId, op_bitDesc });
            return re.ToString();
        }

        //获取号位定价
        public static decimal GetBitPrice(string regionId, string bitDesc)
        {
            OracleParameter op_regionId = new OracleParameter("ic_regionId", OracleDbType.Varchar2, 10);
            op_regionId.Direction = ParameterDirection.Input;
            op_regionId.Value = regionId;

            OracleParameter op_bitDesc = new OracleParameter("ic_bitdesc", OracleDbType.Varchar2, 50);
            op_bitDesc.Direction = ParameterDirection.Input;
            op_bitDesc.Value = bitDesc;

            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getBitPrice(:ic_regionId,:ic_bitdesc) from dual", new OracleParameter[] { op_regionId, op_bitDesc });
            return Convert.ToDecimal(re);
        }

        //获取号位定价
        public static decimal GetBitPrice(string bitId)
        {
            OracleParameter op_bitId = new OracleParameter("ic_bitId", OracleDbType.Varchar2, 10);
            op_bitId.Direction = ParameterDirection.Input;
            op_bitId.Value = bitId;

            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_getBitPrice(:ic_bitId) from dual", new OracleParameter[] { op_bitId });
            return Convert.ToDecimal(re);
        }

        //获取迁出差异天数
        public static int CalcOutDiffDays(string rc001)
        {
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;

            Object re = SqlAssist.ExecuteScalar("select pkg_business.fun_CalcOutDiffDays(:ic_rc001) from dual", new OracleParameter[] { op_rc001 });
            return Convert.ToInt32(re);
        }

        //寄存办理
        public static int Register( string rc001,string rc109,string fa001,string rc002,string rc202,string rc003,string rc303,int rc004,int rc404,
            string rc014,string rc050,string rc051,string rc052,string rc055,string rc099,string rc130,decimal price,DateTime rc140,DateTime rc150,
            decimal nums,string source,string[] itemId_arry,decimal[] itemPrice_arry,int[] itemNums_arry,string handler
            )
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_Register", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;
            //寄存证号
            OracleParameter op_rc109 = new OracleParameter("ic_rc109", OracleDbType.Varchar2, 20);
            op_rc109.Direction = ParameterDirection.Input;
            op_rc109.Value = rc109;
            //结算流水号
            OracleParameter op_fa001 = new OracleParameter("ic_fa001", OracleDbType.Varchar2, 10);
            op_fa001.Direction = ParameterDirection.Input;
            op_fa001.Value = fa001;
            //性别
            OracleParameter op_rc002 = new OracleParameter("ic_rc002", OracleDbType.Varchar2, 3);
            op_rc002.Direction = ParameterDirection.Input;
            op_rc002.Value = rc002;
            //性别2
            OracleParameter op_rc202 = new OracleParameter("ic_rc202", OracleDbType.Varchar2, 3);
            op_rc202.Direction = ParameterDirection.Input;
            op_rc202.Value = rc202;
            //逝者姓名
            OracleParameter op_rc003 = new OracleParameter("ic_rc003", OracleDbType.Varchar2, 20);
            op_rc003.Direction = ParameterDirection.Input;
            op_rc003.Value = rc003;
            //逝者姓名2
            OracleParameter op_rc303 = new OracleParameter("ic_rc303", OracleDbType.Varchar2, 20);
            op_rc303.Direction = ParameterDirection.Input;
            op_rc303.Value = rc303;
            //年龄
            OracleParameter op_rc004 = new OracleParameter("ic_rc004", OracleDbType.Int32);
            op_rc004.Direction = ParameterDirection.Input;
            op_rc004.Value = rc004;
            //年龄2
            OracleParameter op_rc404 = new OracleParameter("ic_rc404", OracleDbType.Int32);
            op_rc404.Direction = ParameterDirection.Input;
            op_rc404.Value = rc404;
            //身份证号
            OracleParameter op_rc014 = new OracleParameter("ic_rc014", OracleDbType.Varchar2, 18);
            op_rc014.Direction = ParameterDirection.Input;
            op_rc014.Value = rc014;
            //联系人
            OracleParameter op_rc050 = new OracleParameter("ic_rc050", OracleDbType.Varchar2, 50);
            op_rc050.Direction = ParameterDirection.Input;
            op_rc050.Value = rc050;
            //联系电话
            OracleParameter op_rc051 = new OracleParameter("ic_rc051", OracleDbType.Varchar2, 50);
            op_rc051.Direction = ParameterDirection.Input;
            op_rc051.Value = rc051;
            //与逝者关系
            OracleParameter op_rc052 = new OracleParameter("ic_rc052", OracleDbType.Varchar2, 10);
            op_rc052.Direction = ParameterDirection.Input;
            op_rc052.Value = rc052;
            //联系地址
            OracleParameter op_rc055 = new OracleParameter("ic_rc055", OracleDbType.Varchar2, 80);
            op_rc055.Direction = ParameterDirection.Input;
            op_rc055.Value = rc055;
            //备注
            OracleParameter op_rc099 = new OracleParameter("ic_rc099", OracleDbType.Varchar2, 200);
            op_rc099.Direction = ParameterDirection.Input;
            op_rc099.Value = rc099;
            //寄存号位编号
            OracleParameter op_rc130 = new OracleParameter("ic_rc130", OracleDbType.Varchar2, 10);
            op_rc130.Direction = ParameterDirection.Input;
            op_rc130.Value = rc130;
            //寄存号位价格
            OracleParameter op_price = new OracleParameter("in_price", OracleDbType.Decimal);
            op_price.Direction = ParameterDirection.Input;
            op_price.Value = price;
            //寄存日期
            OracleParameter op_rc140 = new OracleParameter("id_rc140", OracleDbType.Date);
            op_rc140.Direction = ParameterDirection.Input;
            op_rc140.Value = rc140;
            //寄存到期日期
            OracleParameter op_rc150 = new OracleParameter("id_rc150", OracleDbType.Date);
            op_rc150.Direction = ParameterDirection.Input;
            op_rc150.Value = rc150;
            //缴费年限
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;
            //寄存来源
            OracleParameter op_source= new OracleParameter("ic_source", OracleDbType.Varchar2, 3);
            op_source.Direction = ParameterDirection.Input;
            op_source.Value = source;

            ////项目编号数组
            //OracleParameter op_itemId_arry = new OracleParameter("ic_itemId_arry", OracleDbType.Varchar2);
            //op_itemId_arry.Direction = ParameterDirection.Input;
            //op_itemId_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            //op_itemId_arry.Size = itemId_arry.Count();
            //op_itemId_arry.Value = itemId_arry;

            //if (itemId_arry.Count() > 0)
            //    op_itemId_arry.Value = itemId_arry;
            //else
            //    op_itemId_arry.Status = OracleParameterStatus.NullInsert;

            ////单价数组
            //OracleParameter op_price_arry = new OracleParameter("in_itemPrice_arry", OracleDbType.Decimal);
            //op_price_arry.Direction = ParameterDirection.Input;
            //op_price_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            //op_price_arry.Size = itemPrice_arry.Count();
            //op_price_arry.Value = itemPrice_arry;
           

            //if (itemPrice_arry.Count() > 0)
            //    op_price_arry.Value = itemPrice_arry;
            //else
            //    op_price_arry.Status = OracleParameterStatus.NullInsert;
            //OracleParameterStatus.

            ////数量数组
            //OracleParameter op_nums_arry = new OracleParameter("in_itemNums_arry", OracleDbType.Int32);
            //op_nums_arry.Direction = ParameterDirection.Input;
            //op_nums_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            //op_nums_arry.Size = itemNums_arry.Count();
            //op_nums_arry.Value = itemNums_arry;

            //if (itemNums_arry.Count() > 0)
            //    op_nums_arry.Value = itemNums_arry;
            //else
            //    op_nums_arry.Status = OracleParameterStatus.NullInsert;

            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;
             

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_rc001 , op_rc109, op_fa001, op_rc002, op_rc202, op_rc003, op_rc303, op_rc004, op_rc404,
                   op_rc014, op_rc050, op_rc051,op_rc052, op_rc055,op_rc099, op_rc130, op_price,op_rc140,op_rc150, op_nums,op_source,
                    /*op_itemId_arry,op_price_arry,op_nums_arry,*/ op_handler,appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        //寄存办理
        public static int RegisterEdit(string rc001,string rc002, string rc202, string rc003, string rc303, int rc004, int rc404,
            string rc014, string rc050, string rc051, string rc052, string rc055, string rc099)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_RegisterEdit", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;
            //性别
            OracleParameter op_rc002 = new OracleParameter("ic_rc002", OracleDbType.Varchar2, 3);
            op_rc002.Direction = ParameterDirection.Input;
            op_rc002.Value = rc002;
            //性别2
            OracleParameter op_rc202 = new OracleParameter("ic_rc202", OracleDbType.Varchar2, 3);
            op_rc202.Direction = ParameterDirection.Input;
            op_rc202.Value = rc202;
            //逝者姓名
            OracleParameter op_rc003 = new OracleParameter("ic_rc003", OracleDbType.Varchar2, 20);
            op_rc003.Direction = ParameterDirection.Input;
            op_rc003.Value = rc003;
            //逝者姓名2
            OracleParameter op_rc303 = new OracleParameter("ic_rc303", OracleDbType.Varchar2, 20);
            op_rc303.Direction = ParameterDirection.Input;
            op_rc303.Value = rc303;
            //年龄
            OracleParameter op_rc004 = new OracleParameter("ic_rc004", OracleDbType.Int32);
            op_rc004.Direction = ParameterDirection.Input;
            op_rc004.Value = rc004;
            //年龄2
            OracleParameter op_rc404 = new OracleParameter("ic_rc404", OracleDbType.Int32);
            op_rc404.Direction = ParameterDirection.Input;
            op_rc404.Value = rc404;
            //身份证号
            OracleParameter op_rc014 = new OracleParameter("ic_rc014", OracleDbType.Varchar2, 18);
            op_rc014.Direction = ParameterDirection.Input;
            op_rc014.Value = rc014;
            //联系人
            OracleParameter op_rc050 = new OracleParameter("ic_rc050", OracleDbType.Varchar2, 50);
            op_rc050.Direction = ParameterDirection.Input;
            op_rc050.Value = rc050;
            //联系电话
            OracleParameter op_rc051 = new OracleParameter("ic_rc051", OracleDbType.Varchar2, 50);
            op_rc051.Direction = ParameterDirection.Input;
            op_rc051.Value = rc051;
            //与逝者关系
            OracleParameter op_rc052 = new OracleParameter("ic_rc052", OracleDbType.Varchar2, 10);
            op_rc052.Direction = ParameterDirection.Input;
            op_rc052.Value = rc052;
            //联系地址
            OracleParameter op_rc055 = new OracleParameter("ic_rc055", OracleDbType.Varchar2, 80);
            op_rc055.Direction = ParameterDirection.Input;
            op_rc055.Value = rc055;
            //备注
            OracleParameter op_rc099 = new OracleParameter("ic_rc099", OracleDbType.Varchar2, 200);
            op_rc099.Direction = ParameterDirection.Input;
            op_rc099.Value = rc099;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_rc001 , op_rc002, op_rc202, op_rc003, op_rc303, op_rc004, op_rc404,
                   op_rc014, op_rc050, op_rc051,op_rc052, op_rc055,op_rc099,appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }

        }

        public static int RegisterMove(string rc001,string rc130_b,string rc130_a,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_RegisterMove", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;
            //变更前位置
            OracleParameter op_rc130_b = new OracleParameter("ic_rc130_b", OracleDbType.Varchar2, 10);
            op_rc130_b.Direction = ParameterDirection.Input;
            op_rc130_b.Value = rc130_b;
            //变更后位置
            OracleParameter op_rc130_a = new OracleParameter("ic_rc130_a", OracleDbType.Varchar2, 10);
            op_rc130_a.Direction = ParameterDirection.Input;
            op_rc130_a.Value = rc130_a;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_rc001,op_rc130_b, op_rc130_a,op_handler,appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }

        }

        public static int RegisterPay(string rc001,string fa001,decimal price,decimal nums,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_RegisterPay", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;

            //结算流水号
            OracleParameter op_fa001 = new OracleParameter("ic_fa001", OracleDbType.Varchar2, 10);
            op_fa001.Direction = ParameterDirection.Input;
            op_fa001.Value = fa001;

            //单价
            OracleParameter op_price = new OracleParameter("in_price", OracleDbType.Decimal);
            op_price.Direction = ParameterDirection.Input;
            op_price.Value = price;

            //数量
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;

            // 操作员
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_rc001, op_fa001, op_price,op_nums, op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public static int RegisterOut(string rc001,string oc003,string oc004,string oc005,int oc030,string fa001,decimal price,decimal nums,string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_RegisterOut", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //逝者编号
            OracleParameter op_rc001 = new OracleParameter("ic_rc001", OracleDbType.Varchar2, 10);
            op_rc001.Direction = ParameterDirection.Input;
            op_rc001.Value = rc001;

            //迁出人
            OracleParameter op_oc003 = new OracleParameter("ic_oc003", OracleDbType.Varchar2, 20);
            op_oc003.Direction = ParameterDirection.Input;
            op_oc003.Value = oc003;

            //迁出人身份证号
            OracleParameter op_oc004 = new OracleParameter("ic_oc004", OracleDbType.Varchar2, 20);
            op_oc004.Direction = ParameterDirection.Input;
            op_oc004.Value = oc004;

            //迁出原因
            OracleParameter op_oc005 = new OracleParameter("ic_oc005", OracleDbType.Varchar2, 200);
            op_oc005.Direction = ParameterDirection.Input;
            op_oc005.Value = oc005;

            //差异天数
            OracleParameter op_oc030 = new OracleParameter("in_oc030", OracleDbType.Int32);
            op_oc030.Direction = ParameterDirection.Input;
            op_oc030.Value = oc030;

            //结算流水号
            OracleParameter op_fa001 = new OracleParameter("ic_fa001", OracleDbType.Varchar2, 10);
            op_fa001.Direction = ParameterDirection.Input;
            op_fa001.Value = fa001;

            //单价
            OracleParameter op_price = new OracleParameter("in_price", OracleDbType.Decimal);
            op_price.Direction = ParameterDirection.Input;
            op_price.Value = price;
            //数量
            OracleParameter op_nums = new OracleParameter("in_nums", OracleDbType.Decimal);
            op_nums.Direction = ParameterDirection.Input;
            op_nums.Value = nums;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_rc001,op_oc003,op_oc004,op_oc005,op_oc030,op_fa001,op_price,op_nums,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 打印迁出卡
        /// </summary>
        /// <param name="rc001"></param>
        public static void PrtRegisterOutCard(string rc001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "OutCard",
                                         rc001,
                                         null
                );
        }

        /// <summary>
        /// 打印迁出 补退费收据
        /// </summary>
        /// <param name="rc001"></param>
        public static void PrtRegisterOutInvoice(string fa001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Out_Invoice",
                                         fa001,
                                         null
                );
        }

        /// <summary>
        /// 打印寄存证
        /// </summary>
        /// <param name="rc001"></param>
        public static void PrtRegisterCertCard(string rc001, string fa001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Register_Cert_First",
                                         rc001,
                                         fa001
                );
        }

        /// <summary>
        /// 打印骨灰安置卡
        /// </summary>
        /// <param name="rc001"></param>
        public static void PrtRegSettleCard(string rc001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Register_SettleCard",
                                         rc001,
                                         null
                );
        }

        /// <summary>
        /// 打印寄存收据
        /// </summary>
        /// <param name="rc001"></param>
        public static void PrtRegisterInvoice(string fa001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Register_invoice",
                                         fa001,
                                         null
                );
        }

        /// <summary>
        /// 返回寄存结构共有号位数
        /// </summary>
        /// <param name="rg001"></param>
        /// <returns></returns>
        public static int GetRgAllBits(string rg001)
        {
            OracleParameter op_rg001 = new OracleParameter("ic_rg001", OracleDbType.Varchar2, 10);
            op_rg001.Direction = ParameterDirection.Input;
            op_rg001.Value = rg001;
 
            Object re = SqlAssist.ExecuteScalar("select pkg_Report.fun_GetRgAllBits(:ic_rg001) from dual", new OracleParameter[] { op_rg001 });
            return Convert.ToInt32(re);
        }

        /// <summary>
        /// 返回寄存结构空闲号位数
        /// </summary>
        /// <param name="rg001"></param>
        /// <returns></returns>
        public static int GetRgFreeBits(string rg001)
        {
            OracleParameter op_rg001 = new OracleParameter("ic_rg001", OracleDbType.Varchar2, 10);
            op_rg001.Direction = ParameterDirection.Input;
            op_rg001.Value = rg001;

            Object re = SqlAssist.ExecuteScalar("select pkg_Report.fun_GetRgFreeBits(:ic_rg001) from dual", new OracleParameter[] { op_rg001 });
            return Convert.ToInt32(re);
        }

        /// <summary>
        /// 返回寄存结构占用号位数
        /// </summary>
        /// <param name="rg001"></param>
        /// <returns></returns>
        public static int GetRgUsedBits(string rg001)
        {
            OracleParameter op_rg001 = new OracleParameter("ic_rg001", OracleDbType.Varchar2, 10);
            op_rg001.Direction = ParameterDirection.Input;
            op_rg001.Value = rg001;

            Object re = SqlAssist.ExecuteScalar("select pkg_Report.fun_GetRgUsedBits(:ic_rg001) from dual", new OracleParameter[] { op_rg001 });
            return Convert.ToInt32(re);
        }

        /// <summary>
        /// 返回寄存结构欠费号位数
        /// </summary>
        /// <param name="rg001"></param>
        /// <returns></returns>
        public static int GetRgDebtBits(string rg001)
        {
            OracleParameter op_rg001 = new OracleParameter("ic_rg001", OracleDbType.Varchar2, 10);
            op_rg001.Direction = ParameterDirection.Input;
            op_rg001.Value = rg001;

            Object re = SqlAssist.ExecuteScalar("select pkg_Report.fun_GetRgDebtBits(:ic_rg001) from dual", new OracleParameter[] { op_rg001 });
            return Convert.ToInt32(re);
        }
    }
}
