﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TianYuan_New.ActionObject
{
    /// <summary>
    /// 临时性销售处理类
    /// </summary>
    class TempSalesAction
    {
        public static string GetItemFullName(string itemId)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_getItemFullName ", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 100);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_itemId = new OracleParameter("ic_itemId", OracleDbType.Varchar2,10);
            op_itemId.Direction = ParameterDirection.Input;
            op_itemId.Value = itemId;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_itemId);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }

        /// <summary>
        /// 临时性销售结算
        /// </summary>
        /// <param name="cuname"></param>
        /// <param name="settleId"></param>
        /// <param name="itemId_arry"></param>
        /// <param name="itemType_arry"></param>
        /// <param name="price_arry"></param>
        /// <param name="nums_arry"></param>
        /// <param name="handler"></param>
        /// <returns></returns>
        public static int TempSalesSettle(string accountId,string cuname,string settleId,
            string[] itemId_arry, string[] itemType_arry,decimal[] price_arry,decimal[] nums_arry, string handler)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.prc_TempSalesSettle", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleTransaction trans = null;

            //帐套
            OracleParameter op_accountId = new OracleParameter("ic_accountId", OracleDbType.Varchar2, 3);
            op_accountId.Direction = ParameterDirection.Input;
            op_accountId.Value = accountId;

            //交款人
            OracleParameter op_cuname = new OracleParameter("ic_cuname", OracleDbType.Varchar2, 50);
            op_cuname.Direction = ParameterDirection.Input;
            op_cuname.Value = cuname;
            //结算流水号
            OracleParameter op_settleId = new OracleParameter("ic_settleId", OracleDbType.Varchar2, 10);
            op_settleId.Direction = ParameterDirection.Input;
            op_settleId.Value = settleId;
            //项目编号数组
            OracleParameter op_itemId_arry = new OracleParameter("ic_itemId_arry", OracleDbType.Varchar2);
            op_itemId_arry.Direction = ParameterDirection.Input;
            op_itemId_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_itemId_arry.Value = itemId_arry;
            //项目类型数组
            OracleParameter op_itemType_arry = new OracleParameter("ic_itemType_arry", OracleDbType.Varchar2);
            op_itemType_arry.Direction = ParameterDirection.Input;
            op_itemType_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_itemType_arry.Value = itemType_arry;
            //单价数组
            OracleParameter op_price_arry = new OracleParameter("in_price_arry", OracleDbType.Decimal);
            op_price_arry.Direction = ParameterDirection.Input;
            op_price_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_price_arry.Value = price_arry;
            //数量数组
            OracleParameter op_nums_arry = new OracleParameter("in_nums_arry", OracleDbType.Decimal);
            op_nums_arry.Direction = ParameterDirection.Input;
            op_nums_arry.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            op_nums_arry.Value = nums_arry;
            //经办人
            OracleParameter op_handler = new OracleParameter("ic_handler", OracleDbType.Varchar2, 10);
            op_handler.Direction = ParameterDirection.Input;
            op_handler.Value = handler;

            OracleParameter appcode = new OracleParameter("on_appcode", OracleDbType.Int16);
            appcode.Direction = ParameterDirection.Output;
            OracleParameter apperror = new OracleParameter("oc_error", OracleDbType.Varchar2, 100);
            apperror.Direction = ParameterDirection.Output;

            try
            {
                trans = SqlAssist.conn.BeginTransaction();
                cmd.Parameters.AddRange(new OracleParameter[] { op_accountId,op_cuname,op_settleId, op_itemId_arry, op_itemType_arry,op_price_arry, op_nums_arry,op_handler, appcode, apperror });
                cmd.ExecuteNonQuery();

                if (int.Parse(appcode.Value.ToString()) < 0)
                {
                    trans.Rollback();
                    MessageBox.Show(apperror.Value.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                trans.Commit();
                return 1;
            }
            catch (InvalidOperationException e)
            {
                trans.Rollback();
                MessageBox.Show("执行过程错误!\n" + e.ToString(), "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        /// <summary>
        /// 打印收据
        /// </summary>
        /// <param name="settleId"></param>
        public static void Print_invoice(string settleId)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "TempSales_invoice",
                                         settleId,
                                         null
                );
        }
    }
}
