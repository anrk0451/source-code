﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New
{
    //应用基础信息
    class AppInfo
    {
        private static string _AppTitle = "殡仪馆管理信息系统";    //应用标题
        private static string _AppVersion = "19.0508001";           //应用版本号
        private static string _UnitName = "大庆天园殡仪馆";        //使用单位    
        private static string _ROOTID = "0000000000";              //root用户Id
        private static string _NewStItemId = "9999999999";         //新字典项目编号
        public static int invoicePageCount { get; } = 16;          //发票每页项目数 

        public static string UnitName
        {
            get { return AppInfo._UnitName; }
        }

        public static string AppTitle
        {
            get { return _AppTitle; }
        }

        public static string AppVersion
        {
            get { return _AppVersion; }
        }

        public static string ROOTID
        {
            get { return _ROOTID; }
        }
        
        public static string NewStItemId {
            get { return _NewStItemId; }
        }
        
    }
}
