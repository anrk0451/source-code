﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace TianYuan_New.Business
{
    /// <summary>
    ///  业务tabpage 基类
    /// </summary>
    public partial class BusinessObject : DevExpress.XtraEditors.XtraUserControl
    {
        ///父窗口
        public XtraForm mainForm { get; set; }
        public Dictionary<string,object> cdata { get; set; }

        public BusinessObject()
        {
            InitializeComponent();
            cdata = new Dictionary<string, object>();
        }

        private void BusinessObject_Load(object sender, EventArgs e)
        {

        }

        public virtual void Business_Init()
        {

        }
    }     
}
