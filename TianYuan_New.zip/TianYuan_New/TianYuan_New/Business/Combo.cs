﻿using DevExpress.Data.Filtering;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace TianYuan_New.Business
{
    public partial class Combo : BusinessObject
    {
        private string AC077 = string.Empty;
        private OracleParameter op_cb077 = new OracleParameter("ic_ac001", OracleDbType.Varchar2,3,null,ParameterDirection.Input);

        private Dictionary<string, string> cb002_source = new Dictionary<string, string>();  //套餐类别数据源
        private Dictionary<string, string> cb022_source = new Dictionary<string, string>();  //套餐项目类别数据源

        //private ComboSet comboSet1 = new ComboSet();
        //private DataView comboDetail = null;

        public Combo()
        {
            InitializeComponent();

            ///初始化套餐类别数据源
            cb002_source.Add("0", "服务绑定套餐");
            cb002_source.Add("1", "用户定义套餐");

            cb022_source.Add("05", "殡仪服务");
            cb022_source.Add("10", "骨灰盒");
            cb022_source.Add("11", "纸棺");
            cb022_source.Add("12", "祭品");

            comboSet2.cb01Adapter.SelectCommand.Parameters.Add(op_cb077);
        }

        public override void Business_Init()
        {
            base.Business_Init();
            AC077 = this.cdata["parm"].ToString();
            op_cb077.Value = AC077;

            comboSet2.cb01Adapter.Fill(comboSet2.Cb01);
            gridView1.FocusedRowHandle = gridView1.GetVisibleRowHandle(0);
            comboSet2.cb02Adapter.Fill(comboSet2.Cb02);

        }

        private void Combo_Load(object sender, EventArgs e)
        {

            ///绑定 “套餐类别”
            repositoryItemLookUpEdit1.DataSource = cb002_source;
            repositoryItemLookUpEdit1.PopulateColumns();
            repositoryItemLookUpEdit1.ShowHeader = false;

            ///绑定 "服务类"
            lookup_cb005.DisplayMember = "TYPEDESC";
            lookup_cb005.ValueMember = "SERVICESALESTYPE";
            lookup_cb005.DataSource = Envior.mainform.appds.CastInfo_CanBindingService;
            lookup_cb005.PopulateColumns();
            lookup_cb005.ShowHeader = false;

            ///绑定所有 类别
            lookup_cb022.DataSource = cb022_source;
            lookup_cb022.PopulateColumns();
            lookup_cb022.ShowHeader = false;


            comboSet2.v_validItemAdapter.Fill(comboSet2.v_validItem);
            lookup_cb021.DataSource = comboSet2.v_validItem;
            lookup_cb021.DisplayMember = "item_text";
            lookup_cb021.ValueMember = "item_id";


            lookup_cb021.View.OptionsView.AllowCellMerge = true;

            GridColumn col_itemid = lookup_cb021.View.Columns.AddField("item_id");
            col_itemid.Visible = false;

            GridColumn col_itemtype = lookup_cb021.View.Columns.AddField("item_type_text");
            col_itemtype.Caption = "类别";
            col_itemtype.VisibleIndex = 0;
            col_itemtype.Width = 50;
            col_itemtype.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.True;

            GridColumn col_itemtext = lookup_cb021.View.Columns.AddField("item_text");
            col_itemtext.Caption = "名称";
            col_itemtext.VisibleIndex = 1;
            col_itemtext.Width = 50;

            GridColumn col_price = lookup_cb021.View.Columns.AddField("price");
            col_price.Caption = "单价";
            col_price.VisibleIndex = 2;
            col_price.Width = 50;
            col_price.OptionsColumn.AllowSort = DevExpress.Utils.DefaultBoolean.False;
            col_price.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            col_price.DisplayFormat.FormatString = "N2";

            GridColumn col_zjf = lookup_cb021.View.Columns.AddField("zjf");
            col_zjf.Caption = "助记符";
            col_zjf.VisibleIndex = 3;
            col_zjf.Width = 50;

        }


        /// <summary>
        /// 行号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        /// <summary>
        /// 行号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView2_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        /// <summary>
        /// 新建套餐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ///////////// 新增行 ///////////////////////
            gridView1.AddNewRow();
            int rowno = gridView1.FocusedRowHandle;
            /////// 设置焦点 开始编辑 !!!
            gridView1.FocusedColumn = gridView1.Columns["CB003"];
            gridView1.ShowEditor();
        }

        /// <summary>
        /// 行验证
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            DataRowView rowdata = e.Row as DataRowView;
            if (rowdata == null) return;
            if (rowdata["CB002"] != null && rowdata["CB002"].ToString() == "0" && rowdata["CB005"] is System.DBNull)
            {
                e.Valid = false;
                e.ErrorText = "关联服务必须选择!";
            }
            else if (rowdata["CB003"] == null || string.IsNullOrEmpty(rowdata["CB003"].ToString()))
            {
                e.Valid = false;
                e.ErrorText = "套餐名称必须输入!";
            }
            else if (rowdata["CB002"] == null || rowdata["CB002"] is System.DBNull)
            {
                e.Valid = false;
                e.ErrorText = "套餐类别必须输入!";
            }
        }

        /// <summary>
        /// 编辑验证
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            //////////////////////////////  编辑单元格验证事件 /////////////////////////////    
            string colName = (sender as ColumnView).FocusedColumn.FieldName.ToUpper();
            if (colName.Equals("CB003"))
            {
                if (String.IsNullOrEmpty(e.Value.ToString()))
                {
                    e.Valid = false;
                    e.ErrorText = "套餐名称不能为空!";
                }
                else
                {
                    for (int i = 0; i < gridView1.RowCount - 1; i++)
                    {
                        if (i == (sender as ColumnView).FocusedRowHandle) continue;
                        if (gridView1.GetRowCellValue(i, "CB003") == null) continue;

                        //如果名字相同,则校验不通过!                        
                        if (String.Equals(gridView1.GetRowCellValue(i, "CB003").ToString(), e.Value.ToString()))
                        {
                            e.Valid = false;
                            e.ErrorText = "名称已经存在!";
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 新行初始化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_InitNewRow(object sender, DevExpress.XtraGrid.Views.Grid.InitNewRowEventArgs e)
        {
            //// 初始化新行时触发(当在新行中)
            GridView view = sender as GridView;
            string cb001 = Tools.GetEntityPK("CB01");
            int currow = view.FocusedRowHandle;
            view.SetRowCellValue(e.RowHandle, view.Columns["CB001"], cb001);
            view.SetRowCellValue(e.RowHandle, view.Columns["STATUS"], "1");
            view.SetRowCellValue(e.RowHandle, view.Columns["CB077"], AC077);
        }

        /// <summary>
        /// 套餐类型变化 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            if (e.Column.FieldName == "CB002")  //套餐类别
            {
                if (e.Value.ToString() == "1")
                {
                    (sender as ColumnView).SetRowCellValue(e.RowHandle, "CB005", null);
                }
            }
        }

        /// <summary>
        /// 绘制单元格 改变背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            if (e.Column.FieldName == "CB005")
            {
                object cb002 = gridView1.GetRowCellValue(e.RowHandle, "CB002");
                if (cb002 != null && cb002.ToString() == "1")
                {
                    //e.Appearance.BackColor = Color.LightGray;             
                }
            }
        }

        /// <summary>
        /// 显示编辑器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ShowingEditor(object sender, CancelEventArgs e)
        {
            ColumnView view = sender as ColumnView;
            if (view.FocusedColumn.FieldName == "CB005")
            {
                object cb002 = view.GetRowCellValue(view.FocusedRowHandle, "CB002");
                if (cb002 != null && cb002.ToString() == "1")
                {
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// 行改变事件(选择套餐)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            int rowHandle = e.FocusedRowHandle;
            string s_filter = null;
            object s_cb001 = gridView1.GetRowCellValue(rowHandle, "CB001");

            gridView2.BeginUpdate();
            gridView2.ActiveFilter.Clear();
            if (s_cb001 != null && !(s_cb001 is System.DBNull))
            {
                s_filter = "[CB001]='" + s_cb001 + "'";
            }
            else
            {
                s_filter = "[CB001]='0000000000'";
            }
            gridView2.ActiveFilter.Add(gridView2.Columns["CB001"], new ColumnFilterInfo(s_filter));
            gridView2.EndUpdate();
        }

        /// <summary>
        /// 初始化 套餐明细
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView2_InitNewRow(object sender, InitNewRowEventArgs e)
        {
            int combo_handle = gridView1.FocusedRowHandle;
            object s_cb001 = gridView1.GetRowCellValue(combo_handle, "CB001");

            if (s_cb001 != null && !(s_cb001 is System.DBNull))
            {
                gridView2.SetRowCellValue(gridView2.FocusedRowHandle, "CB001", s_cb001.ToString());
            }

            gridView2.SetRowCellValue(gridView2.FocusedRowHandle, "CB201", Tools.GetEntityPK("CB01"));
            gridView2.SetRowCellValue(gridView2.FocusedRowHandle, "CB030", 1);
        }


        private void gridView2_CellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            //if (e.Column.FieldName == "CB022")
            //{
            //    if (e.Value == null || e.Value is System.DBNull) {
            //        comboSet2.v_validItemView.RowFilter = "item_type=''";
            //    }
            //    else
            //    {
            //        comboSet2.v_validItemView.RowFilter = "item_type='" + e.Value.ToString() + "'";
            //    }
            //    gridView2.SetRowCellValue(gridView2.FocusedRowHandle, "CB021", null);
            //}
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(gridView2.GetRowCellValue(1, "CB022").ToString());
        }

        private void gridView2_ShowingEditor(object sender, CancelEventArgs e)
        {
            if (gridView2.FocusedColumn.FieldName == "CB021")
            {
                int rowHandle = gridView2.FocusedRowHandle;
                object s_cb022 = gridView2.GetRowCellValue(rowHandle, "CB022");
                if (s_cb022 == null || s_cb022 is System.DBNull)
                {
                    comboSet2.v_validItemView.RowFilter = "item_type=''";
                }
                else
                {
                    comboSet2.v_validItemView.RowFilter = "item_type='" + s_cb022.ToString() + "'";
                }
            }
        }


        private void gridView1_BeforeLeaveRow(object sender, RowAllowEventArgs e)
        {
            if (!gridView2.PostEditor() || !gridView1.UpdateCurrentRow())
            {
                e.Allow = false;
            }

        }

        /// <summary>
        /// 行校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView2_ValidateRow(object sender, ValidateRowEventArgs e)
        {
            DataRowView rowdata = e.Row as DataRowView;
            if (rowdata == null) return;

            if (rowdata["CB021"] is System.DBNull || rowdata["CB021"] == null)
            {
                e.ErrorText = "请选择项目!";
                e.Valid = false;
                return;
            }
            else if (rowdata["CB030"] is System.DBNull || rowdata["CB030"] == null)
            {
                e.ErrorText = "请输入数量!";
                e.Valid = false;
                return;

            }
            else if (decimal.Parse(rowdata["CB030"].ToString()) <= 0)
            {
                e.ErrorText = "数量必须大于0!";
                e.Valid = false;
                return;
            }
        }

        /// <summary>
        /// 明细校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView2_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            ColumnView view = sender as ColumnView;
            int rowHandle = view.FocusedRowHandle;
            string colname = view.FocusedColumn.FieldName;

            if (colname == "CB020")
            {
                if (e.Value == null || string.IsNullOrEmpty(e.Value.ToString()))
                {
                    e.ErrorText = "数量必须输入!";
                    e.Valid = false;
                }
            }
            else if (colname == "CB021")  //项目名
            {
                if (e.Value == null || string.IsNullOrWhiteSpace(e.Value.ToString())) return;
                for (int i = 0; i < view.RowCount - 1; i++)
                {
                    if (i == rowHandle) continue;
                    if (gridView2.GetRowCellValue(i, "CB021") == null || gridView2.GetRowCellValue(i, "CB021") is System.DBNull || gridView2.GetRowCellValue(i, "CB021") == null) continue;

                    //如果相同,则校验不通过!                        
                    if (String.Equals(gridView2.GetRowCellValue(i, "CB021").ToString(), e.Value.ToString()))
                    {
                        e.Valid = false;
                        e.ErrorText = "项目已经存在!";
                        return;
                    }
                }
            }

        }

        /// <summary>
        /// 单元格内行单击
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView2_RowCellClick(object sender, RowCellClickEventArgs e)
        {
            if (e.Column.Name == "ucol1")
            {
                DialogResult result = MessageBox.Show("确认删除?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (result == DialogResult.No) return;
                gridView2.DeleteRow(e.RowHandle);
            }
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ///////////// 新增行 ///////////////////////
            gridView1.AddNewRow();
            int rowno = gridView1.FocusedRowHandle;
            /////// 设置焦点 开始编辑 !!!
            gridView1.FocusedColumn = gridView1.Columns["CB003"];
            gridView1.ShowEditor();
        }

        /// <summary>
        /// 删除套餐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            /////  删除记录 
            if (rowHandle >= 0)
            {
                if (MessageBox.Show("确认要删除当前的记录吗", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    return;
                }

            }
            gridView1.SetFocusedRowCellValue("STATUS", "0");
            gridView1.UpdateCurrentRow();
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (!gridView1.PostEditor() || !gridView2.PostEditor()) return;
            if (!gridView1.UpdateCurrentRow() || !gridView2.UpdateCurrentRow()) return;

            OracleTransaction trans = SqlAssist.conn.BeginTransaction();

            try
            {
                comboSet2.cb01Adapter.Update(comboSet2.Cb01);
                comboSet2.cb02Adapter.Update(comboSet2.Cb02);

                trans.Commit();
                MessageBox.Show("保存成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ee)
            {
                trans.Rollback();
                MessageBox.Show(ee.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            gridView1.BeginUpdate();
            gridView2.BeginUpdate();

            comboSet2.Cb01.Clear();
            comboSet2.Cb02.Clear();

            comboSet2.cb01Adapter.Fill(comboSet2.Cb01);
            comboSet2.cb02Adapter.Fill(comboSet2.Cb02);

            gridView1.EndUpdate();
            gridView2.EndUpdate();
        }

        private void FilterLookup(object sender)
        {
            Text += " ! ";
            GridLookUpEdit edit = sender as GridLookUpEdit;
            GridView gridView = edit.Properties.View;
            FieldInfo fi = gridView.GetType().GetField("extraFilter", BindingFlags.NonPublic | BindingFlags.Instance);
            Text = edit.AutoSearchText;
            BinaryOperator op1 = new BinaryOperator("item_text", edit.AutoSearchText + "%", BinaryOperatorType.Like);
            BinaryOperator op2 = new BinaryOperator("zjf", edit.AutoSearchText + "%", BinaryOperatorType.Like);
            string filterCondition = new GroupOperator(GroupOperatorType.Or, new CriteriaOperator[] { op1, op2 }).ToString();
            fi.SetValue(gridView, filterCondition);

            MethodInfo mi = gridView.GetType().GetMethod("ApplyColumnsFilterEx", BindingFlags.NonPublic | BindingFlags.Instance);
            mi.Invoke(gridView, null);
        }

        private void lookup_cb021_Popup(object sender, EventArgs e)
        {
            FilterLookup(sender);
        }

        private void lookup_cb021_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            this.BeginInvoke(new System.Windows.Forms.MethodInvoker(delegate
            {
                FilterLookup(sender);
            }));
        }
    }
}
