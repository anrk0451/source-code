﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Web.UI.WebControls;
using DevExpress.XtraGrid.Views.Base;

namespace TianYuan_New.Business 
{
    public partial class DataDictionary : BusinessObject
    {
        int curIndex = 0;
        Boolean LOCK = true;

        public DataDictionary()
        {
            InitializeComponent();           
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            gridView1.AddNewRow();
            int rowno = gridView1.FocusedRowHandle;
            /////// 设置焦点 开始编辑 !!!
            gridView1.FocusedColumn = gridView1.Columns["ST003"];
            gridView1.ShowEditor();
        }

        /// <summary>
        /// 选择不同类型
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imageListBoxControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((myds1.ST01 as DataTable).GetChanges() != null && LOCK)
            {
                if (MessageBox.Show("数据已经改变,是否保存?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes){
                    if (Save())
                    {
                        curIndex = imageListBoxControl1.SelectedIndex;
                        sT01TableAdapter1.FillBy(myds1.ST01, GetCurTypeStr(curIndex));
                    }
                    else
                    {
                        LOCK = false;
                        imageListBoxControl1.SetSelected(curIndex, true);
                    }
                }
                else
                {
                    curIndex = imageListBoxControl1.SelectedIndex;
                    sT01TableAdapter1.FillBy(myds1.ST01, GetCurTypeStr(curIndex));
                }
                
            }
            else if(LOCK)
            {
                curIndex = imageListBoxControl1.SelectedIndex;
                sT01TableAdapter1.FillBy(myds1.ST01, GetCurTypeStr(curIndex));
            }
            else
            {
                LOCK = true;
            }
                
        }

        private void DataDictionary_Load(object sender, EventArgs e)
        {
            //设置初始选择
            imageListBoxControl1.SetSelected(0, true);
            curIndex = 0;

            /// 设置派序列
            gridView1.Columns["SORTID"].SortOrder = DevExpress.Data.ColumnSortOrder.Ascending;
        }

        private void imageListBoxControl1_Validating(object sender, CancelEventArgs e)
        {
 
        }

        /// <summary>
        /// 绘制行号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void gridView1_InitNewRow(object sender, DevExpress.XtraGrid.Views.Grid.InitNewRowEventArgs e)
        {
            //// 初始化新行时触发(当在新行中)
            GridView view = sender as GridView;
            string st001 = Tools.GetEntityPK("ST01");

            gridView1.SetRowCellValue(e.RowHandle, "ST002", GetCurTypeStr(curIndex));
            gridView1.SetRowCellValue(e.RowHandle, "ST001", st001);
            gridView1.SetRowCellValue(e.RowHandle, "STATUS", "1");
            gridView1.SetRowCellValue(e.RowHandle, "SORTID", Convert.ToInt32(st001));
        }

        ////保存过程 
        private Boolean Save()
        {
            if(!gridView1.PostEditor()) return false;
            if (!gridView1.UpdateCurrentRow()) return false;

            try
            {
                sT01TableAdapter1.Update(myds1.ST01);
                MessageBox.Show("保存成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        ////根据索引获取当前类别
        private String GetCurTypeStr(int index)
        {
            string result = string.Empty;
            switch (index)
            {
                case 0:
                    result = "DIEREASON";
                    break;
                case 1:
                    result = "DISTRICT";
                    break;
                case 2:
                    result = "RELATION";
                    break;
                case 3:
                    result = "DRIVER";
                    break;
            }
            return result;
        }

        

        /// <summary>
        /// 刷新数据网格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            myds1.ST01.Clear();
            sT01TableAdapter1.FillBy(myds1.ST01, GetCurTypeStr(curIndex));
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gridView1.FocusedRowHandle >= 0)
            {
                if (MessageBox.Show("确认要删除当前的记录吗", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    return;
                }

            }
            //gridView1.DeleteRow(gridView1.FocusedRowHandle);
            gridView1.SetFocusedRowCellValue("STATUS", "0");
            gridView1.UpdateCurrentRow();
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Save();
        }


        /// <summary>
        /// 项目上移
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int row = gridView1.FocusedRowHandle;
            if (row <= 0) return;

            int prior_sortId = int.Parse(gridView1.GetRowCellValue(row - 1, "SORTID").ToString());
            int cur_sortId = int.Parse(gridView1.GetRowCellValue(row, "SORTID").ToString());

            gridView1.SetRowCellValue(row, "SORTID", prior_sortId);
            gridView1.SetRowCellValue(row - 1, "SORTID", cur_sortId);
        }
        /// <summary>
        /// 下移项目
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int row = gridView1.FocusedRowHandle;
            if ((row >= gridView1.RowCount - 2) || row < 0 ) return;

            int next_sortId = int.Parse(gridView1.GetRowCellValue(row + 1, "SORTID").ToString());
            int cur_sortId = int.Parse(gridView1.GetRowCellValue(row, "SORTID").ToString());

            gridView1.SetRowCellValue(row, "SORTID", next_sortId);
            gridView1.SetRowCellValue(row + 1, "SORTID", cur_sortId);
        }


        /// <summary>
        /// 数据行校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            string value = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "ST003").ToString();
            if (String.IsNullOrEmpty(value))
            {
                e.Valid = false;
                (sender as ColumnView).SetColumnError(gridView1.Columns["ST003"], "数据项不能为空!");
            }
        }


        /// <summary>
        /// 数据校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            string colName = (sender as ColumnView).FocusedColumn.FieldName.ToUpper();
            if (colName.Equals("ST003"))       //数据项值
            {
                if (String.IsNullOrEmpty(e.Value.ToString()))
                {
                    e.Valid = false;
                    e.ErrorText = "数据项值不能为空!";
                }
                else
                {
                    for (int i = 0; i < gridView1.RowCount - 1; i++)
                    {
                        if (i == (sender as ColumnView).FocusedRowHandle) continue;
                        if (gridView1.GetRowCellValue(i, "ST003") == null) continue;

                        //如果名字相同,则校验不通过!                        
                        if (String.Equals(gridView1.GetRowCellValue(i, "ST003").ToString(), e.Value.ToString()))
                        {
                            e.Valid = false;
                            e.ErrorText = "值已经存在!";
                            break;
                        }
                    }
                }
            }
             
        }
    }
}
