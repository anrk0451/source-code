﻿using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraPrinting;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using TianYuan_New.ActionObject;
using TianYuan_New.Windows;

namespace TianYuan_New.Business
{
    public partial class FinanceDays : BusinessObject
    {
        //
        private DataTable dt_finance = new DataTable("FINANCE");
        //private string sumsql = @"select nvl(sum(fa004),0) from v_financeDay where (to_char(fa200,'yyyy/mm/dd') between :begin and :end) and fa003 like :fa003 and fa100 like :fa100";
        private OracleDataAdapter finAdapter =
            new OracleDataAdapter("select * from v_financeDay where accountId = :accountId and (to_char(fa200,'yyyy/mm/dd') between :begin and :end) and fa003 like :fa003 ", SqlAssist.conn);

        private DataTable dt_detail = new DataTable("DETAIL");
        private OracleDataAdapter deAdapter =
            new OracleDataAdapter("select * from v_findetail where sa010 = :sa010", SqlAssist.conn);
        private string accountId = string.Empty;

        OracleParameter op_begin = null;
        OracleParameter op_end = null;
        OracleParameter op_fa003 = null;
        //OracleParameter op_fa100 = null;
        OracleParameter op_accountId = new OracleParameter("accountId", OracleDbType.Varchar2, 3);
        OracleParameter op_sa010 = null;

        public FinanceDays()
        {
            InitializeComponent();
        }

        public override void Business_Init()
        {
            base.Business_Init();
            accountId = this.cdata["parm"].ToString();
            op_accountId.Value = accountId;

            this.DoSearch();
        }

        private void FinanceDays_Load(object sender, EventArgs e)
        {
            op_accountId.Direction = ParameterDirection.Input;

            op_begin = new OracleParameter("begin", OracleDbType.Varchar2, 20);
            op_begin.Direction = ParameterDirection.Input;

            op_end = new OracleParameter("end", OracleDbType.Varchar2, 20);
            op_end.Direction = ParameterDirection.Input;

            op_fa003 = new OracleParameter("fa003", OracleDbType.Varchar2, 80);
            op_fa003.Direction = ParameterDirection.Input;

            ////////// 除了管理员,只能查看自己的收费记录 //////////////
            //op_fa100 = new OracleParameter("fa100", OracleDbType.Varchar2, 10);
            //op_fa100.Direction = ParameterDirection.Input;

            //if (Envior.cur_userId == AppInfo.ROOTID)
            //{
            //    op_fa100.Value = "%";
            //}
            //else
            //{
            //    op_fa100.Value = Envior.cur_userId;
            //}


            op_sa010 = new OracleParameter("sa010", OracleDbType.Varchar2, 10);
            op_sa010.Direction = ParameterDirection.Input;

            finAdapter.SelectCommand.Parameters.AddRange(new OracleParameter[] { op_accountId,op_begin, op_end, op_fa003 });
            deAdapter.SelectCommand.Parameters.AddRange(new OracleParameter[] { op_sa010 });

            gridControl3.DataSource = dt_finance;
            gridControl2.DataSource = dt_detail;

            gridControl3.Visible = true;
 
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            gridView3.BeginUpdate();
            dt_finance.Clear();

            finAdapter.Fill(dt_finance);
            gridView3.EndUpdate();
        }


        public void DoSearch()
        {
            FinanceDaysForm frm_1 = new FinanceDaysForm();
            frm_1.cdata["BusinessObject"] = this;
            frm_1.cdata["accountId"] = accountId;
            if (frm_1.ShowDialog() == DialogResult.OK)
            {
                frm_1.Dispose();
                string s_begin = string.Empty;
                string s_end = string.Empty;
                string s_fa003 = string.Empty;

                if (this.cdata["dbegin"] == null || this.cdata["dbegin"] is System.DBNull)
                {
                    s_begin = "1900/01/01";
                }
                else
                {
                    s_begin = Convert.ToDateTime(this.cdata["dbegin"]).ToString("yyyy/MM/dd");
                }

                if (this.cdata["dend"] == null || this.cdata["dend"] is System.DBNull)
                {
                    s_end = "9999/12/31";
                }
                else
                {
                    s_end = Convert.ToDateTime(this.cdata["dend"]).ToString("yyyy/MM/dd");
                }

                if (this.cdata["FA003"] == null || string.IsNullOrEmpty(this.cdata["FA003"].ToString()))
                {
                    s_fa003 = "%";
                }
                else
                {
                    s_fa003 = this.cdata["FA003"].ToString() + "%";
                }


                op_begin.Value = s_begin;
                op_end.Value = s_end;
                op_fa003.Value = s_fa003;

                gridView3.BeginUpdate();
                dt_finance.Clear();

                finAdapter.Fill(dt_finance);

                gridCol_Fa004.SummaryItem.SummaryType = DevExpress.Data.SummaryItemType.Sum;
                gridCol_Fa004.SummaryItem.DisplayFormat = "合计 = {0:N2}";

                gridColumn5.SummaryItem.SummaryType = DevExpress.Data.SummaryItemType.Count;
                gridColumn5.SummaryItem.DisplayFormat = "共计 = {0:N0}笔";

                gridView3.EndUpdate();
            }
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.DoSearch();
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            gridView1.ShowFindPanel();
        }




        /// <summary>
        /// 检索明细
        /// </summary>
        /// <param name="rowHandle"></param>
        private void RetrieveDetail(int rowHandle)
        {
            if (rowHandle >= 0)
            {
                string s_fa001 = gridView3.GetRowCellValue(rowHandle, "FA001").ToString();
                op_sa010.Value = s_fa001;
                gridView2.BeginUpdate();
                dt_detail.Clear();
                deAdapter.Fill(dt_detail);
                gridView2.EndUpdate();
            }
        }


        /// <summary>
        /// 作废收费
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView3.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                if (MessageBox.Show("确认要作废吗?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No) return;
                string s_rc001 = gridView3.GetRowCellValue(rowHandle, "AC001").ToString();
                if (Convert.ToDecimal(gridView3.GetRowCellValue(rowHandle, "FA004")) < 0)
                {
                    MessageBox.Show("退费业务不能作废!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (gridView3.GetRowCellValue(rowHandle, "FA002").ToString() == "2")  //寄存业务
                {

                    decimal count = (decimal)SqlAssist.ExecuteScalar("select count(*) from v_rc04 where rc001='" + s_rc001 + "'", null);
                    if (count <= 1)
                    {
                        if (MessageBox.Show("此记录是唯一一次交费记录,作废此记录将删除寄存登记信息,是否继续?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No) return;
                    }
                }

                string s_fa001 = gridView3.GetRowCellValue(rowHandle, "FA001").ToString();

                int re = FireAction.FinanceRemove(s_fa001, Envior.cur_userId);
                if (re > 0)
                {
                    MessageBox.Show("作废成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dt_finance.Rows.RemoveAt(gridView3.GetDataSourceRowIndex(rowHandle));
                    if (gridView3.RowCount == 0)
                    {
                        dt_detail.Clear();
                    }
                    else
                    {
                        this.RetrieveDetail(gridView3.FocusedRowHandle);
                    }

                    //decimal sum = Convert.ToDecimal(SqlAssist.ExecuteScalar(sumsql, new OracleParameter[] { op_begin, op_end, op_fa003,op_fa100}));
                    //sb_sum.Text = "合计金额:    " + sum.ToString("##,##0.00");

                    return;
                }
            }
        }

        /// <summary>
        /// 补打收据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            
            if (Tools.GetRight(Envior.cur_userId, accountId == "1"? "04030" : "09030") == "0"  )
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            int rowHandle = gridView3.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                string s_fa002 = gridView3.GetRowCellValue(rowHandle, "FA002").ToString();
                string s_fa001 = gridView3.GetRowCellValue(rowHandle, "FA001").ToString();
                string s_ac001 = gridView3.GetRowCellValue(rowHandle, "AC001").ToString();

                if (s_fa002 == "1")      //临时性销售
                {
                    MessageBox.Show("现在打印【收据】!");
                    TempSalesAction.Print_invoice(s_fa001);
                }
                else if (s_fa002 == "0") //火化业务
                {
                    if (MessageBox.Show("要补打【收据】吗", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        FireAction.Print_invoice(s_fa001);
                    }


                    //if (gridView2.IsValidRowHandle(gridView2.LocateByValue("SA002", "06")))
                    //{
                    //    if (MessageBox.Show("要补打【火化证明】吗", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.No) return;
                    //    FireAction.Print_HHZM(s_ac001);
                    //}
                }
                else if (s_fa002 == "2")   //寄存业务 
                {
                    if (MessageBox.Show("要补打【收据】吗", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        RegisterAction.PrtRegisterInvoice(s_fa001);
                    }
                }
            }
        }

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "导出Excel";
            fileDialog.Filter = "Excel文件(*.xlsx)|*.xlsx";

            DialogResult dialogResult = fileDialog.ShowDialog(this);
            if (dialogResult == DialogResult.OK)
            {
                DevExpress.XtraPrinting.XlsxExportOptions options = new DevExpress.XtraPrinting.XlsxExportOptions();
                options.TextExportMode = TextExportMode.Text;//设置导出模式为文本
                gridControl3.ExportToXlsx(fileDialog.FileName, options);
                XtraMessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void gridView3_CustomDrawRowIndicator(object sender, RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void gridView3_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (e.FocusedRowHandle >= 0)
            {
                this.RetrieveDetail(e.FocusedRowHandle);
            }
        }
    }
}
