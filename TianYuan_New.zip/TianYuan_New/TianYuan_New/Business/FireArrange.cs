﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using DevExpress.XtraPrinting;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;

namespace TianYuan_New.Business
{
    public partial class FireArrange : BusinessObject
    {
        private string accountId = string.Empty;

        private DataTable dt_arrange = new DataTable("Arrange");
        private OracleDataAdapter arrAdapter =
            new OracleDataAdapter("select * from v_fireArrange where accountId = :accountId order by ac001", SqlAssist.conn);
        private OracleParameter op_accountId = new OracleParameter("accountId", OracleDbType.Varchar2, 3);

        public FireArrange()
        {
            InitializeComponent();
        }

        public override void Business_Init()
        {
            accountId = this.cdata["parm"].ToString();
            op_accountId.Value = accountId;

            this.RefreshData();
        }

        private void FireArrange_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = dt_arrange;
            arrAdapter.SelectCommand.Parameters.Add(op_accountId);

            //arrAdapter.Fill(dt_arrange);
        }

        /// <summary>
        /// 刷新数据
        /// </summary>
        private void RefreshData()
        {
            gridView1.BeginUpdate();
            dt_arrange.Clear();
            arrAdapter.Fill(dt_arrange);
            gridView1.EndUpdate();
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.RefreshData();
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "导出Excel";
            fileDialog.Filter = "Excel文件(*.xlsx)|*.xlsx";

            DialogResult dialogResult = fileDialog.ShowDialog(this);
            if (dialogResult == DialogResult.OK)
            {
                DevExpress.XtraPrinting.XlsxExportOptions options = new DevExpress.XtraPrinting.XlsxExportOptions();
                options.TextExportMode = TextExportMode.Text;//设置导出模式为文本
                gridControl1.ExportToXlsx(fileDialog.FileName, options);
                XtraMessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Busines(int rowHandle)
        {
            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();
            if(accountId == "1")
            {
                Envior.mainform.openBusinessObject("FireBusiness", s_ac001);
            }
            else
            {
                Envior.mainform2.openBusinessObject("FireBusiness", s_ac001);
            }         
        }

        private void gridView1_MouseDown(object sender, MouseEventArgs e)
        {
            GridHitInfo hInfo = gridView1.CalcHitInfo(new Point(e.X, e.Y));
            if (e.Button == MouseButtons.Left && e.Clicks == 2)
            {
                //判断光标是否在行范围内  
                if (hInfo.InRow)
                {
                    Busines(gridView1.FocusedRowHandle);
                }
            }
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                this.Busines(rowHandle);
            }
        }
    }
}
