﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.DataSet;
using TianYuan_New.Windows;
using TianYuan_New.Domain;
using TianYuan_New.ActionObject;
using DevExpress.XtraGrid.Views.Base;

namespace TianYuan_New.Business
{
    public partial class FireBusiness : BusinessObject
    {
        private string AC001;
        private DataTable Ac01 = new DataTable("Ac01");
        private OracleDataAdapter ac01Adapter = new OracleDataAdapter("",SqlAssist.conn);

        public DataTable Si01 { get; }  = new DataTable("Si01");
        public OracleDataAdapter si01Adapter { get; } = 
            new OracleDataAdapter("select item_type,item_id,item_text,price,sortId,zjf,accountId,1 nums from v_allvaliditem  order by item_type,sortId", SqlAssist.conn);

        private FireSalesSet salesSet = new FireSalesSet();
  
        public FireBusiness()
        {
            InitializeComponent();
        }

        private void FireBusiness_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = salesSet.Sa01;
            ac01Adapter.Requery = true;

            OracleParameter parm = new OracleParameter("ac001", OracleDbType.Varchar2, 10);
            parm.Direction = ParameterDirection.Input;            
            salesSet.sa01Adapter.SelectCommand.Parameters.Add(parm);

            //this.Business_Init();

            //与逝者关系
            lookup_ac052.Properties.DataSource = Envior.mainform.appds.St01;
            lookup_ac052.Properties.DisplayMember = "ST003";
            lookup_ac052.Properties.ValueMember = "ST001";

            //经办人
            lookup_sa100.DataSource = Envior.mainform.appds.Uc01;
            //守灵厅
            lookup_store.Properties.DataSource = this.Si01;
            //告别厅
            lookUp_gbt.Properties.DataSource = this.Si01;
  
            //服务信息
            si01Adapter.Fill(Si01);
        }

        //对象初始化
        public override void Business_Init()
        {
            //获取逝者编号
            AC001 = this.cdata["parm"].ToString();

            //填充逝者个人信息
            ac01Adapter.SelectCommand.CommandText = "select * from ac01 where ac001='" + AC001 + "'";

            Ac01.Clear();
            ac01Adapter.Fill(Ac01);

            if (Ac01.Rows.Count <= 0)
            {
                MessageBox.Show("参数传递错误!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            txtedit_ac001.EditValue = AC001;
            txtedit_ac003.EditValue = Ac01.Rows[0]["AC003"];
            txtedit_ac004.EditValue = Ac01.Rows[0]["AC004"];
            rg_ac002.EditValue = Ac01.Rows[0]["AC002"];
            txtedit_ac020.EditValue = Ac01.Rows[0]["AC020"];  //到达中心时间
            txtedit_ac050.EditValue = Ac01.Rows[0]["AC050"];  //联系人
            txtedit_ac051.EditValue = Ac01.Rows[0]["AC051"];
            lookup_ac052.EditValue = Ac01.Rows[0]["AC052"];

            this.Parent.Text = "火化业务办理" + "【" + Ac01.Rows[0]["AC003"] + "】";

            salesSet.sa01Adapter.SelectCommand.Parameters[0].Value = AC001;

            //salesSet.Sa01.Clear();
            //salesSet.sa01Adapter.Fill(salesSet.Sa01);

            ///刷新销售数据
            this.RefreshSalesData();
            
        }

        

        /// <summary>
        /// 刷新销售数据
        /// </summary>
        private void RefreshSalesData()
        {
            gridView1.BeginUpdate();
            salesSet.Sa01.Clear();
            salesSet.sa01Adapter.Fill(salesSet.Sa01);
            gridView1.EndUpdate();

            this.RefreshPanel();
        }

        /// <summary>
        /// 刷新业务显示面板
        /// </summary>
        private void RefreshPanel()
        {
            int rowHandle = int.MinValue;
            //守灵厅!
            rowHandle = gridView1.LocateByValue("SA002", "01");
            if (rowHandle >= 0)
            {
                lookup_store.EditValue = gridView1.GetRowCellValue(rowHandle, "SA004");
            }
            //冷藏柜
            rowHandle = gridView1.LocateByValue("SA002", "02");
            if (rowHandle >= 0)
            {
                lookup_store.EditValue = gridView1.GetRowCellValue(rowHandle, "SA004");
            }
            //休息室
            txtedit_xxs.EditValue = FireAction.GetRestRoomList(AC001);

            //告别厅
            rowHandle = gridView1.LocateByValue("SA002", "04");
            if (rowHandle >= 0)
            {
                lookUp_gbt.EditValue = gridView1.GetRowCellValue(rowHandle, "SA004");
            }
            //告别时间
            txtedit_ac018.EditValue = FireAction.GetGBTime(AC001);
            //火化时间
            txtedit_ac015.EditValue = FireAction.GetHHTime(AC001);

        }

        /// <summary>
        /// 结算标志转换
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomColumnDisplayText(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "SA008")
            {
                e.DisplayText = Sa01.Sa01Sa008_Mapper(e.Value.ToString());
            }
        }

        /// <summary>
        /// 守灵厅办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if(FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            //检查是否已有
            if (gridView1.LocateByValue("SA002", "01") >= 0 || gridView1.LocateByValue("SA002", "02") >= 0)
            {
                MessageBox.Show("已经办理守灵或冷藏业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FireBusiness01 frm_slt = new FireBusiness01();
            frm_slt.cdata["businessObject"] = this;
            frm_slt.cdata["AC001"] = AC001;

            if (frm_slt.ShowDialog(mainForm) == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }

        /// <summary>
        /// 冷餐柜办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //检查是否已有
            if (gridView1.LocateByValue("SA002", "01") >= 0 || gridView1.LocateByValue("SA002", "02") >= 0)
            {
                MessageBox.Show("已经办理守灵或冷藏业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            FireBusiness02 frm_lcg = new FireBusiness02();
            frm_lcg.cdata["businessObject"] = this;
            frm_lcg.cdata["AC001"] = AC001;

            if (frm_lcg.ShowDialog(mainForm) == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }

        /// <summary>
        /// 休息室办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FireBusiness03 frm_xxs = new FireBusiness03();
            frm_xxs.cdata["businessObject"] = this;
            frm_xxs.cdata["AC001"] = AC001;

            if (frm_xxs.ShowDialog(mainForm) == DialogResult.OK)
            {
                List<string> itemIdList = this.cdata["xxs"] as List<string>;
                int result = 0;
                foreach(string s in itemIdList)
                {
                    result = FireAction.FireSales_03(AC001,
                                                     s,                                                   
                                                     Envior.cur_userId
                    ); 
                }
                RefreshSalesData();
            }
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        /// <summary>
        /// 告别办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //检查是否已有
            int row = gridView1.LocateByValue("SA002", "04");
            if (row >= 0 )
            {
                if(gridView1.GetRowCellValue(row,"SA008").ToString() == "1")  //已经结算
                {
                    MessageBox.Show("告别已经办理且已结算!","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }
                if(MessageBox.Show("已经办理告别业务,是否替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No )
                    return;
            }

            FireBusiness04 frm_gbt = new FireBusiness04();
            frm_gbt.cdata["businessObject"] = this;
            frm_gbt.cdata["AC001"] = AC001;

            if (frm_gbt.ShowDialog(mainForm) == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }
        /// <summary>
        /// 灵车办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //检查是否已有
            int row = gridView1.LocateByValue("SA002", "07");
            if (row >= 0)
            {
                if (gridView1.GetRowCellValue(row, "SA008").ToString() == "1")  //已经结算
                {
                    MessageBox.Show("灵车已经办理且已结算!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (MessageBox.Show("已经办理灵车业务,是否替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }
            FireBusiness07 frm_lc = new FireBusiness07();
            frm_lc.cdata["businessObject"] = this;
            frm_lc.cdata["AC001"] = AC001;

            if (frm_lc.ShowDialog(mainForm) == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }

        /// <summary>
        /// 火化办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem7_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //检查是否已有
            int row = gridView1.LocateByValue("SA002", "06");
            if (row >= 0)
            {
                if (gridView1.GetRowCellValue(row, "SA008").ToString() == "1")  //已经结算
                {
                    MessageBox.Show("火化已经办理且已结算!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (MessageBox.Show("已经办理火化业务,是否替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }
            FireBusiness06 frm_hh = new FireBusiness06();
            frm_hh.cdata["businessObject"] = this;
            frm_hh.cdata["AC001"] = AC001;

            if (frm_hh.ShowDialog(mainForm) == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }
        /// <summary>
        /// 服务商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FireBusinessMisc frm_misc = new FireBusinessMisc();
            frm_misc.cdata["businessObject"] = this;
            frm_misc.cdata["accountId"] = FireAction.GetAccountIdByAc001(AC001);

            if(frm_misc.ShowDialog() == DialogResult.OK)
            {
                List<string> itemId_list = this.cdata["itemIdList"] as List<string>;
                List<string> itemType_list = this.cdata["itemTypeList"] as List<string>;
                List<decimal> price_list = this.cdata["priceList"] as List<decimal>;
                List<int> nums_list = this.cdata["numsList"] as List<int>;
                int re = 0;
                
                for(int i = 0; i < itemId_list.Count ; i++)
                {
                    if(itemType_list[i] == "10" || itemType_list[i] == "11")
                    {
                        re = gridView1.LocateByValue("SA002",itemType_list[i]);
                        if (re > 0)
                        {
                            //如果已经办理 谷类或纸类并且已经结算,则跳过
                            if (gridView1.GetRowCellValue(re, "SA008").ToString() == "1")
                                continue;
                            else
                            {
                                if(itemType_list[i] == "10")
                                {
                                    if (MessageBox.Show("已经选择【骨灰盒】,是否要替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) continue;
                                }else if(itemId_list[i] == "11")
                                {
                                    if (MessageBox.Show("已经选择【纸棺】,是否要替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) continue;
                                } 
                            }
                        }
                    }

                    re = gridView1.LocateByValue("SA004", itemId_list[i]);
                    if (re >= 0)
                    {
                        if (MessageBox.Show("【" + gridView1.GetRowCellValue(re,"SA003").ToString() + "】已经存在,要继续选择吗?", 
                            "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No) continue;
                    }
                    re = FireAction.FireSales_Misc(AC001,
                                                   itemId_list[i],
                                                   nums_list[i],
                                                   Envior.cur_userId
                    );
                    if (re < 0) return;
                }
                RefreshSalesData();
            }
        }

        private void gridView1_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        {
            if (e.Action == CollectionChangeAction.Add)
            {
                int row = gridView1.FocusedRowHandle;
                if(gridView1.GetRowCellValue(row,"SA008").ToString() == "1")
                {
                    MessageBox.Show("已结算数据不能修改!","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    gridView1.UnselectRow(row);
                }
            }else if(e.Action == CollectionChangeAction.Refresh && gridView1.SelectedRowsCount > 0)
            {
                gridView1.BeginUpdate();
                for(int i = 0; i < gridView1.RowCount; i++)
                {
                    if(gridView1.GetRowCellValue(i,"SA008").ToString() == "1")
                    {
                        gridView1.UnselectRow(i);
                    }
                }
                gridView1.EndUpdate();
            }
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem17_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            string accountId = FireAction.GetAccountIdByAc001(AC001);
            if (Tools.GetRight(Envior.cur_userId, accountId == "1" ? "01070":"07070") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (gridView1.SelectedRowsCount == 0)
            {
                MessageBox.Show("请现在选择记录!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;    
            }

            string sa001;
            int re;

            if(MessageBox.Show("确认要删除吗?","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2) == DialogResult.No)  return;

            foreach(int i in gridView1.GetSelectedRows())
            {
                sa001 = gridView1.GetRowCellValue(i, "SA001").ToString();
                re = FireAction.FireBusinessRemove(sa001);
                if (re < 0) return;
            }

            this.RefreshSalesData();
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem15_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            RefreshSalesData();
        }
        /// <summary>
        /// 应用套餐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem14_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (FireAction.FireIsSettled(AC001) == "1")
            {
                MessageBox.Show("已经办理火化且结算完成,不能继续办理业务!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ComboSelect frm_combo = new ComboSelect();
            frm_combo.cdata["businessObject"] = this;
            frm_combo.cdata["AC001"] = AC001;
            if(frm_combo.ShowDialog() == DialogResult.OK)
            {
                RefreshSalesData();
            }
        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            int row = -1;
            if ((row = (sender as ColumnView).FocusedRowHandle) >= 0)
            {                
                this.SalesEdit(row);
            }
                
        }

        /// <summary>
        /// 业务项目编辑
        /// </summary>
        /// <param name="rowIndex"></param>
        private void SalesEdit(int rowIndex)
        {
            if (gridView1.GetRowCellValue(rowIndex, "SA008").ToString() == "1")
            {
                MessageBox.Show("结算完成的记录不能修改!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //权限检查
            string accountId = FireAction.GetAccountIdByAc001(AC001);
            string s_right = Tools.GetRight(Envior.cur_userId,accountId == "1"? "01060" :"07060");
            if (s_right == "0" || (s_right == "1" && gridView1.GetRowCellValue(rowIndex, "SA100").ToString() != Envior.cur_userId))
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            string sa001 = gridView1.GetRowCellValue(rowIndex, "SA001").ToString();
            int index = gridView1.GetDataSourceRowIndex(rowIndex);
            FireSalesEdit frm_edit = new FireSalesEdit();

            frm_edit.cdata["DATAROW"] = salesSet.Sa01.Rows[index];

            if(frm_edit.ShowDialog() == DialogResult.OK)
            {
                this.RefreshSalesData();
            }
        }

        private void barButtonItem11_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if(rowHandle >=0)
                this.SalesEdit(rowHandle);
        }

        /// <summary>
        /// 结算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem13_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            string accountId = FireAction.GetAccountIdByAc001(AC001);
            if (Tools.GetRight(Envior.cur_userId, accountId == "1" ? "01080":"07080") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (gridView1.SelectedRowsCount == 0)
            {
                MessageBox.Show("请选择要结算的记录!","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            List<int> rowList = new List<int>();
            foreach(int i in gridView1.GetSelectedRows())
            {
                if(Convert.ToDecimal(gridView1.GetRowCellValue(i,"PRICE")) == 0)
                {
                    MessageBox.Show("结算的项目尚未输入价格!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }
                rowList.Add(gridView1.GetDataSourceRowIndex(i));
            }

            FireSettle frm_settle = new FireSettle();
            frm_settle.cdata["salesSet"] = salesSet;
            frm_settle.cdata["AC001"] = AC001;
            frm_settle.cdata["rowList"] = rowList;

            if(frm_settle.ShowDialog() == DialogResult.OK)
            {
                this.RefreshSalesData();
            }

        }

         
    }
}
