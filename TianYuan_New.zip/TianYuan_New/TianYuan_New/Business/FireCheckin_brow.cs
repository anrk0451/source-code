﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Windows;
using TianYuan_New.DataSet;
using TianYuan_New.Domain;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Business 
{
    public partial class FireCheckin_brow : BusinessObject
    {
        private string AC077 = string.Empty;
        private XtraForm mform = null;

        CheckinSet checkinSet = new CheckinSet();
        private DataView ac005_source;   //死亡原因 数据源
        private DataView ac052_source;   //与逝者关系

        private DataTable shadow_dt;
        private OracleDataAdapter adapter = new OracleDataAdapter("",SqlAssist.conn);

        public FireCheckin_brow()
        {
            InitializeComponent();
        }

        public override void Business_Init()
        {
            AC077 = this.cdata["parm"].ToString();
            if (AC077 == "1")
                mform = Envior.mainform;
            else
                mform = Envior.mainform2;

            //装入数据
            DataFilter(combo_list.EditValue.ToString());
        }

        private void FireCheckin_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = checkinSet.Ac01;   // checkinSet.Ac01;

            checkinSet.st01Adapter.Fill(checkinSet.St01);

            DataRow newrow = checkinSet.St01.NewRow();
            newrow["ST001"] = AppInfo.NewStItemId;
            newrow["ST003"] = "......";
            newrow["ST002"] = "%";
            newrow["SORTID"] = 99999;
            newrow.EndEdit();
            checkinSet.St01.Rows.Add(newrow);

 
            shadow_dt = checkinSet.Ac01.Clone();

            //死亡原因
            ac005_source = new DataView(checkinSet.St01);
            ac005_source.RowFilter = "ST002='DIEREASON'";
            lookup_ac005.DataSource = ac005_source;
            lookup_ac005.DisplayMember = "ST003";
            lookup_ac005.ValueMember = "ST001";

            //与逝者关系
            ac052_source = new DataView(checkinSet.St01);
            ac052_source.RowFilter = "ST002='RELATION'";
            lookup_ac052.DataSource = ac052_source;
            lookup_ac052.ValueMember = "ST001";
            lookup_ac052.DisplayMember = "ST003";

            //操作员
            lookup_ac100.DataSource = checkinSet.Uc01;
            lookup_ac100.ValueMember = "UC001";
            lookup_ac100.DisplayMember = "UC003";
            checkinSet.uc01Adapter.Fill(checkinSet.Uc01);

            
        }
 

        /// <summary>
        /// 进灵登记
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></pa
        /// ram>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, AC077 == "1"?"01010":"07010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            FireCheckin form_checkin = new FireCheckin();
            form_checkin.cdata["action"] = "add";
            form_checkin.cdata["dataset"] = checkinSet;
            form_checkin.cdata["parent"] = this;
            form_checkin.cdata["AC077"] = AC077;

            if(form_checkin.ShowDialog(mform) == DialogResult.OK)
            {
                string s_ac001 = this.cdata["AC001"].ToString();
                adapter.SelectCommand.CommandText = "select * from ac01 where ac001='" + s_ac001 + "'";
                adapter.Fill(shadow_dt);
                checkinSet.Ac01.Merge(shadow_dt);
            }
            
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.RefreshData();            
        }

        /// <summary>
        /// 列 值-文字 映射
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomColumnDisplayText(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "AC002")
            {
                e.DisplayText = Ac01.Ac01Ac002_Mapper(e.Value.ToString());
            }
        }

        /// <summary>
        /// 绘制行号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        /// <summary>
        /// 记录过滤选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combo_list_EditValueChanged(object sender, EventArgs e)
        {
            if (combo_list.EditValue != null && !string.IsNullOrWhiteSpace(combo_list.EditValue.ToString()))
            {
                DataFilter(combo_list.EditValue.ToString());
            }
        }

        private void DataFilter(string action)
        {
            switch (action)
            {
                case "今日登记":
                    checkinSet.ac01Adapter.SelectCommand.CommandText = "select * from ac01 where ac077 = '" + AC077 + "' and trunc(ac200) = trunc(sysdate) and status <> '0' ";
                    break;
                case "近三日登记":
                    checkinSet.ac01Adapter.SelectCommand.CommandText = "select * from ac01 where ac077 = '" + AC077 + "' and (trunc(sysdate) - trunc(ac200)) <=2 and status <> '0' ";
                    break;
                case "一个月内登记":
                    checkinSet.ac01Adapter.SelectCommand.CommandText = "select * from ac01 where  ac077 = '" + AC077 + "' and (trunc(sysdate) - trunc(ac200)) <=30 and status <> '0' ";
                    break;
            }
            gridView1.BeginUpdate();
            checkinSet.Ac01.Clear();
            checkinSet.ac01Adapter.Fill(checkinSet.Ac01);
            gridView1.EndUpdate();
        }

        /// <summary>
        /// 编辑逝者信息
        /// </summary>
        public void ac01_edit(int rowHandle)
        {
            if (rowHandle < 0) return;
 
            //权限检查
            string s_right = Tools.GetRight(Envior.cur_userId, AC077 =="1"? "01020":"07020");
            if(s_right == "0" || (s_right == "1" && gridView1.GetRowCellValue(rowHandle,"AC100").ToString() != Envior.cur_userId))
            {
                MessageBox.Show("权限不足!","提示",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            } 
 
            DataRow rowdata = checkinSet.Ac01.Rows[gridView1.GetDataSourceRowIndex(rowHandle)];

            FireCheckin fireCheckin = new FireCheckin();
            fireCheckin.cdata["action"] = "edit";
            fireCheckin.cdata["rowdata"] = rowdata;
            fireCheckin.cdata["dataset"] = checkinSet;
            fireCheckin.cdata["parent"] = this;
            fireCheckin.cdata["AC077"] = AC077;

            if(fireCheckin.ShowDialog(mainForm) == DialogResult.OK)
            {
                fireCheckin.Dispose();
                string s_ac001 = this.cdata["AC001"].ToString();
                adapter.SelectCommand.CommandText = "select * from ac01 where ac001='" + s_ac001 + "'";
                adapter.Fill(shadow_dt);
                checkinSet.Ac01.Merge(shadow_dt);
            }

        }

        private void gridView1_MouseDown(object sender, MouseEventArgs e)
        {
            GridHitInfo hInfo = gridView1.CalcHitInfo(new Point(e.X, e.Y));
            if (e.Button == MouseButtons.Left && e.Clicks == 2)
            {
                //判断光标是否在行范围内  
                if (hInfo.InRow)
                {
                    ac01_edit(gridView1.FocusedRowHandle);
                }
            }
        }


        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                ac01_edit(rowHandle);
            }
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle; ;
            if (rowHandle < 0) return;

            //权限检查
            string s_right = Tools.GetRight(Envior.cur_userId, AC077 =="1"? "01030":"07030");
            if (s_right == "0" || (s_right == "1" && gridView1.GetRowCellValue(rowHandle, "AC100").ToString() != Envior.cur_userId))
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
 
            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();
            if (MessageBox.Show("确认要删除登记信息吗?", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Cancel) return;

            if(FireAction.RemoveFireCheckin(s_ac001,Envior.cur_userId) > 0)
            {
                this.RefreshData();
            }

        }

        //业务办理
        private void barButtonItem10_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId,AC077=="1"? "01050":"07050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle < 0) return;

            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();

            if(AC077 == "1")
            {
               (mform as MainForm).openBusinessObject("FireBusiness", s_ac001);
            }
            else
            {
                (mform as Main_2nd).openBusinessObject("FireBusiness", s_ac001);
            }
          
        }

        /// <summary>
        /// 刷新数据
        /// </summary>
        private void RefreshData()
        {
            DataFilter(combo_list.EditValue.ToString());
        }
        
    }
    }
