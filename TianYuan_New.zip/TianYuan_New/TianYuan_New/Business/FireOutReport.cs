﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Windows;
using Oracle.ManagedDataAccess.Client;
using DevExpress.XtraPrinting;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Business
{
    public partial class FireOutReport : BusinessObject
    {
        private string accountId = string.Empty;
        private DataTable dt_out = new DataTable();
        private OracleDataAdapter outAdapter =
            new OracleDataAdapter("select * from v_Checkout where (to_char(ac015,'yyyy/mm/dd') between :begin and :end) and ac003 like :ac003 and ac007 like :ac007  and accountId = :accountId",SqlAssist.conn);

        OracleParameter op_begin = null;
        OracleParameter op_end = null;
        OracleParameter op_ac003 = null;
        OracleParameter op_ac007 = null;
        OracleParameter op_accountId = null;
 
        public FireOutReport()
        {
            InitializeComponent();
        }

        public override void Business_Init()
        {
            base.Business_Init();
            accountId = this.cdata["parm"].ToString();
        }

        private void FireOutReport_Load(object sender, EventArgs e)
        {
            //this.DisplayCondition();
            op_begin = new OracleParameter("begin", OracleDbType.Varchar2, 20);
            op_begin.Direction = ParameterDirection.Input;

            op_end = new OracleParameter("end", OracleDbType.Varchar2, 20);
            op_end.Direction = ParameterDirection.Input;

            op_ac003 = new OracleParameter("ac003", OracleDbType.Varchar2, 20);
            op_ac003.Direction = ParameterDirection.Input;

            op_ac007 = new OracleParameter("ac007", OracleDbType.Varchar2, 20);
            op_ac007.Direction = ParameterDirection.Input;

            op_accountId = new OracleParameter("accountId", OracleDbType.Varchar2, 3);
            op_accountId.Direction = ParameterDirection.Input;

            outAdapter.SelectCommand.Parameters.AddRange(new OracleParameter[] { op_begin, op_end, op_ac003,op_ac007,op_accountId});
            gridControl1.DataSource = dt_out;

        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.DisplayCondition();
        }

        /// <summary>
        /// 显示查询条件窗口
        /// </summary>
        private void DisplayCondition()
        {
            FireOutReportForm frm_out = new FireOutReportForm();
            frm_out.cdata["BusinessObject"] = this;
            if(frm_out.ShowDialog() == DialogResult.OK)
            {
                frm_out.Dispose();
                string s_begin = string.Empty;
                string s_end = string.Empty;
                string s_ac003 = string.Empty;
                string s_ac007 = string.Empty;

                if (this.cdata["dbegin"] == null || this.cdata["dbegin"] is System.DBNull)
                {
                    s_begin = "1900/01/01";
                }
                else
                {
                    s_begin = Convert.ToDateTime(this.cdata["dbegin"]).ToString("yyyy/MM/dd");
                }

                if (this.cdata["dend"] == null || this.cdata["dend"] is System.DBNull)
                {
                    s_end = "9999/12/31";
                }
                else
                {
                    s_end = Convert.ToDateTime(this.cdata["dend"]).ToString("yyyy/MM/dd");
                }

                if (this.cdata["AC003"] == null || string.IsNullOrEmpty(this.cdata["AC003"].ToString()))
                {
                    s_ac003 = "%";
                }
                else
                {
                    s_ac003 = this.cdata["RC003"].ToString() + "%";
                }

                s_ac007 = this.cdata["AC007"].ToString();

                op_begin.Value = s_begin;
                op_end.Value = s_end;
                op_ac003.Value = s_ac003;
                op_ac007.Value = s_ac007;
                op_accountId.Value = accountId;

                gridView1.BeginUpdate();
                dt_out.Clear();
                outAdapter.Fill(dt_out);
                gridView1.EndUpdate();

            }
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.RefreshData();
        }

        /// <summary>
        /// 刷新数据过程
        /// </summary>
        private void RefreshData()
        {
            gridView1.BeginUpdate();
            dt_out.Clear();
            outAdapter.Fill(dt_out);
            gridView1.EndUpdate();
        }

        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "导出Excel";
            fileDialog.Filter = "Excel文件(*.xlsx)|*.xlsx";

            DialogResult dialogResult = fileDialog.ShowDialog(this);
            if (dialogResult == DialogResult.OK)
            {
                DevExpress.XtraPrinting.XlsxExportOptions options = new DevExpress.XtraPrinting.XlsxExportOptions();
                options.TextExportMode = TextExportMode.Text;//设置导出模式为文本
                gridControl1.ExportToXlsx(fileDialog.FileName, options);
                XtraMessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e) =>
            //显示查找对话框
            gridView1.ShowFindPanel();


        /// <summary>
        /// 已出灵数据修改
        /// </summary>
        /// <param name="rowHandle"></param>
        private void Edit(int rowHandle)
        {
            FireOutEdit frm_edit = new FireOutEdit();
            frm_edit.cdata["AC001"] = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();
            frm_edit.cdata["BusinessObject"] = this;
            if(frm_edit.ShowDialog() == DialogResult.OK)
            {
                frm_edit.Dispose();
                this.RefreshData();
            }
        }
 

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                this.Edit(rowHandle);
            }
        }

        private void gridView1_MouseDown(object sender, MouseEventArgs e)
        {
            //GridHitInfo hInfo = gridView1.CalcHitInfo(new Point(e.X, e.Y));
            //if (e.Button == MouseButtons.Left && e.Clicks == 2)
            //{
            //    MessageBox.Show("test");
            //    //判断光标是否在行范围内  
            //    if (hInfo.InRow)
            //    {
            //        MessageBox.Show("test2");
            //        Edit(gridView1.FocusedRowHandle);
            //    }
            //}
        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            if(gridView1.FocusedRowHandle >= 0)
            {
                this.Edit(gridView1.FocusedRowHandle);
            }
        }

        /// <summary>
        /// 业务办理记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem7_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle < 0) return;

            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();

            if(accountId == "1")
            {
                Envior.mainform.openBusinessObject("FireBusiness", s_ac001);
            }
            else
            {
                Envior.mainform2.openBusinessObject("FireBusiness", s_ac001);
            }
        }

        /// <summary>
        /// 补打火化证明
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, accountId == "1"? "01100":"07100") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle < 0) return;

            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "AC001").ToString();
            if(MessageBox.Show("现在打印【火化证明】吗?","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                FireAction.Print_HHZM(s_ac001);
            }
                
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }
    }
}
