﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Windows;
using TianYuan_New.ActionObject;
using Oracle.ManagedDataAccess.Client;
using DevExpress.XtraPrinting;
using DevExpress.XtraReports.UI;
using DevExpress.Data;

namespace TianYuan_New.Business
{
    /// <summary>
    /// 财务类别统计
    /// </summary>
    public partial class ItemStat : BusinessObject
    {
        private DataTable dt_cs = new DataTable();
        private OracleDataAdapter csAdapter =
            new OracleDataAdapter("select * from v_itemStat ",SqlAssist.conn);

        private string s_begin = string.Empty;
        private string s_end = string.Empty;
        private string[] classArry;
        private string accountId = string.Empty;
        private int times = 0;   //收款笔数


        public ItemStat()
        {
            InitializeComponent();
        }

        private void ItemStat_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = dt_cs;
        }

        public override void Business_Init()
        {
            base.Business_Init();
            accountId = this.cdata["parm"].ToString();
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            ClassStatForm frm_stat = new ClassStatForm();
            frm_stat.cdata["BusinessObject"] = this;
            frm_stat.cdata["accountId"] = accountId;

            if (frm_stat.ShowDialog() == DialogResult.OK)
            {
                frm_stat.Dispose();

                classArry = this.cdata["class"] as string[];

                if (this.cdata["dbegin"] == null || this.cdata["dbegin"] is System.DBNull)
                {
                    s_begin = "1900/01/01";
                }
                else
                {
                    s_begin = Convert.ToDateTime(this.cdata["dbegin"]).ToString("yyyy/MM/dd");
                }

                if (this.cdata["dend"] == null || this.cdata["dend"] is System.DBNull)
                {
                    s_end = "9999/12/31";
                }
                else
                {
                    s_end = Convert.ToDateTime(this.cdata["dend"]).ToString("yyyy/MM/dd");
                }

                this.RefreshData();
                 
            }
        }

        /// <summary>
        /// 刷新数据
        /// </summary>
        private void RefreshData( )
        {
            int re = FireAction.ClassStat(accountId,s_begin,s_end,classArry,Envior.cur_userId);
            if (re > 0)
            {
                gridView1.BeginUpdate();
                dt_cs.Clear();
                csAdapter.Fill(dt_cs);

                gridColumn3.SummaryItem.SummaryType = DevExpress.Data.SummaryItemType.Sum;
                gridColumn3.SummaryItem.DisplayFormat = "合计 = {0:N2}";

                //times = Convert.ToInt32(SqlAssist.ExecuteScalar("select count(distinct settleId) from cs_report", null));

                gridView1.EndUpdate();

                ////////汇总合计 ///////
                //decimal sum = Convert.ToDecimal(SqlAssist.ExecuteScalar("select nvl(sum(je),0) from V_CLASSSTAT", null));
                //sb_sum.Text = "合计金额:   " + sum.ToString("###,##0.00");

            }
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.RefreshData();
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "导出Excel";
            fileDialog.Filter = "Excel文件(*.xlsx)|*.xlsx";

            DialogResult dialogResult = fileDialog.ShowDialog(this);
            if (dialogResult == DialogResult.OK)
            {
                DevExpress.XtraPrinting.XlsxExportOptions options = new DevExpress.XtraPrinting.XlsxExportOptions();
                options.TextExportMode = TextExportMode.Text;//设置导出模式为文本
                gridControl1.ExportToXlsx(fileDialog.FileName, options);
                XtraMessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ItemStat_Resize(object sender, EventArgs e)
        {
            //splitContainerControl1.SplitterPosition = splitContainerControl1.Height - 75;
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            MyReport report = new MyReport();
            report.DataSource = dt_cs;

            report.Parameters[0].Value = Convert.ToDateTime(this.cdata["dbegin"]).ToString("yyyy/MM/dd");
            report.Parameters[1].Value = Convert.ToDateTime(this.cdata["dend"]).ToString("yyyy/MM/dd");
            report.Parameters[2].Value = times;

            using (ReportPrintTool printTool = new ReportPrintTool(report))
            {
                //printTool.ShowPreviewDialog();
                // Invoke the Print dialog.
                
                printTool.PrintDialog();
                // Send the report to the default printer.
                // printTool.Print();
                

            }
        }

        private void gridView1_CustomDrawRowIndicator_1(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void gridView1_CustomSummaryCalculate(object sender, DevExpress.Data.CustomSummaryEventArgs e)
        {
            if (e.IsTotalSummary)
            {
                switch (e.SummaryProcess)
                {                     
                    case CustomSummaryProcess.Finalize:
                        times = Convert.ToInt32(SqlAssist.ExecuteScalar("select count(distinct settleId) from cs_report", null));
                        e.TotalValue = times;
                        break;
                }
            }
        }
    }
}
