﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.DataSet;
using TianYuan_New.Windows;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using TianYuan_New.ActionObject;
using DevExpress.XtraPrinting;

namespace TianYuan_New.Business
{
    public partial class Register_brow : BusinessObject
    {
        private RegisterSet registerSet = new RegisterSet();

        public Register_brow()
        {
            InitializeComponent();
            
            //自定义字典项
            registerSet.st01Adapter.Fill(registerSet.St01);
            DataRow newrow = registerSet.St01.NewRow();
            newrow["ST001"] = AppInfo.NewStItemId;
            newrow["ST003"] = "......";
            newrow["ST002"] = "%";
            newrow["SORTID"] = 99999;
            newrow.EndEdit();
            registerSet.St01.Rows.Add(newrow);
        }

        private void Register_brow_Load(object sender, EventArgs e)
        {
            ///// 检索 寄存附品
            registerSet.jcfpAdapter.Fill(registerSet.Jcfp);
            gridControl1.DataSource = registerSet.Rc01;


            //装入数据
            DataFilter(combo_list.EditValue.ToString());
            
        }
 

        /// <summary>
        /// 过滤数据
        /// </summary>
        /// <param name="action"></param>
        private void DataFilter(string action)
        {
            switch (action)
            {
                case "今日登记":
                    registerSet.rc01Adapter.SelectCommand.CommandText = "select * from v_register where trunc(rc140) = trunc(sysdate)  ";
                    break;
                case "近三日登记":
                    registerSet.rc01Adapter.SelectCommand.CommandText = "select * from v_register where (trunc(sysdate) - trunc(rc140)) <=2  ";
                    break;
                case "一个月内登记":
                    registerSet.rc01Adapter.SelectCommand.CommandText = "select * from v_register where (trunc(sysdate) - trunc(rc140)) <=30  ";
                    break;
                case "条件查询":
                    RegisterSearch frm_search = new RegisterSearch();
                    frm_search.cdata["parent"] = this;

                    if(frm_search.ShowDialog() == DialogResult.OK)
                    {
                        registerSet.rc01Adapter.SelectCommand.CommandText = "select * from v_register where 1=1 " + this.cdata["sql"].ToString() ;
                    }
                    break;
            }
            gridView1.BeginUpdate();
            registerSet.Rc01.Clear();
            registerSet.rc01Adapter.Fill(registerSet.Rc01);
            gridView1.EndUpdate();
        }

        /// <summary>
        /// 条件查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem19_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            RegisterSearch frm_search = new RegisterSearch();
            frm_search.cdata["parent"] = this;

            if (frm_search.ShowDialog() == DialogResult.OK)
            {
                registerSet.rc01Adapter.SelectCommand.CommandText = "select * from v_register where 1=1 " + this.cdata["sql"].ToString();
                frm_search.Dispose();
            }
            gridView1.BeginUpdate();
            registerSet.Rc01.Clear();
            registerSet.rc01Adapter.Fill(registerSet.Rc01);
            gridView1.EndUpdate();
        }

        /// <summary>
        /// 外来寄存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem12_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Register regform = new Register();
            regform.cdata["RegisterSet"] = registerSet;
            regform.cdata["source"] = "1";  
            if(regform.ShowDialog() == DialogResult.OK)
            {
                regform.Dispose();
                this.RefreshData();
            }
        }

        private void gridView1_CustomDrawRowIndicator_1(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void combo_list_EditValueChanged(object sender, EventArgs e)
        {
            if (combo_list.EditValue != null && !string.IsNullOrWhiteSpace(combo_list.EditValue.ToString()))
            {
                DataFilter(combo_list.EditValue.ToString());
            }
        }

        /// <summary>
        /// 本馆火化寄存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            FireToRegister frm_fromFire = new FireToRegister();
            frm_fromFire.cdata["BusinessObject"] = this;
            if(frm_fromFire.ShowDialog() == DialogResult.OK)
            {
                string s_ac001 = this.cdata["AC001"].ToString();
                frm_fromFire.Dispose();

                Register regform = new Register();
                regform.cdata["RegisterSet"] = registerSet;
                regform.cdata["source"] = "0";
                regform.cdata["AC001"] = s_ac001;
                if(regform.ShowDialog() == DialogResult.OK)
                {
                    regform.Dispose();
                    this.RefreshData();
                }
            }
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //DataFilter(combo_list.EditValue.ToString());
            this.RefreshData();
        }

        /// <summary>
        /// 刷新数据
        /// </summary>
        private void RefreshData()
        {
            gridView1.BeginUpdate();
            registerSet.Rc01.Clear();
            registerSet.rc01Adapter.Fill(registerSet.Rc01);
            gridView1.EndUpdate();
        }

        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="rowHandle"></param>
        private void EditData(int rowHandle)
        {
            string s_ac001 = gridView1.GetRowCellValue(rowHandle, "RC001").ToString();

            Register_edit frm_edit = new Register_edit();
            frm_edit.cdata["RegisterSet"] = registerSet;
            frm_edit.cdata["AC001"] = s_ac001;
            if(frm_edit.ShowDialog() == DialogResult.OK)
            {
                this.RefreshData();
            }
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if(rowHandle >= 0)
            {
                this.EditData(rowHandle);
            }
        }

        private void gridView1_MouseDown(object sender, MouseEventArgs e)
        {
            GridHitInfo hInfo = gridView1.CalcHitInfo(new Point(e.X, e.Y));
            if (e.Button == MouseButtons.Left && e.Clicks == 2)
            {
                //判断光标是否在行范围内  
                if (hInfo.InRow)
                {
                    EditData(gridView1.FocusedRowHandle);
                }
            }
        }

        /// <summary>
        /// 位置变更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem13_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                RegisterMove frm_move = new RegisterMove();
                frm_move.cdata["RC001"] = gridView1.GetRowCellValue(rowHandle,"RC001");
                if(frm_move.ShowDialog() == DialogResult.OK)
                {
                    this.RefreshData();
                    frm_move.Dispose();
                }
            }
        }
 
        /// <summary>
        /// 寄存缴费
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem10_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                RegisterPay frm_pay = new RegisterPay();
                frm_pay.cdata["RC001"] = gridView1.GetRowCellValue(rowHandle,"RC001");
                if(frm_pay.ShowDialog() == DialogResult.OK)
                {
                    this.RefreshData();
                    frm_pay.Dispose();
                }
            }
        }

        /// <summary>
        /// 补打寄存证
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem14_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if(rowHandle >= 0)
            {
                string s_rc001 = gridView1.GetRowCellValue(rowHandle, "RC001").ToString();
                int commandNum = PrtServAction.GenNewCommandNum();
                PrtServAction.SendPrtCommand(Envior.prtConnId,
                                             Envior.mainform.Handle.ToInt32(),
                                             commandNum,
                                             "Register_Cert_BD",
                                             s_rc001,
                                             null
                    );
            }
            
        }

        /// <summary>
        /// 打印缴费记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem15_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                string s_rc001 = gridView1.GetRowCellValue(rowHandle, "RC001").ToString();
                PrintPayRec frm_payrec = new PrintPayRec();
                frm_payrec.cdata["RC001"] = s_rc001;
                if (frm_payrec.ShowDialog() == DialogResult.OK)
                {
                    frm_payrec.Dispose();
                }
            }
        }


        /// <summary>
        /// 打印骨灰安置卡
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem16_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                string s_rc001 = gridView1.GetRowCellValue(rowHandle, "RC001").ToString();
                int commandNum = PrtServAction.GenNewCommandNum();
                PrtServAction.SendPrtCommand(Envior.prtConnId,
                                             Envior.mainform.Handle.ToInt32(),
                                             commandNum,
                                             "Register_SettleCard",
                                             s_rc001,
                                             null
                    );
            }
        }

        /// <summary>
        /// 寄存迁出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem11_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int rowHandle = gridView1.FocusedRowHandle;
            if (rowHandle >= 0)
            {
                string s_rc001 = gridView1.GetRowCellValue(rowHandle, "RC001").ToString();
                RegisterOut frm_out = new RegisterOut();
                frm_out.cdata["RC001"] = s_rc001;

                if(frm_out.ShowDialog() == DialogResult.OK)
                {
                    frm_out.Dispose();
                    this.RefreshData();
                }
            }
        }

        /// <summary>
        /// 原始登记
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem17_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            RegisterOri frm_ori = new RegisterOri();
            frm_ori.cdata["RegisterSet"] = registerSet;
            if(frm_ori.ShowDialog() == DialogResult.OK)
            {
                frm_ori.Dispose();
                this.RefreshData();
            }
        }


        ///导出excel文件 
        private void barButtonItem18_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.Title = "导出Excel";
            fileDialog.Filter = "Excel文件(*.xlsx)|*.xlsx";

            DialogResult dialogResult = fileDialog.ShowDialog(this);
            if (dialogResult == DialogResult.OK)
            {
                DevExpress.XtraPrinting.XlsxExportOptions options = new DevExpress.XtraPrinting.XlsxExportOptions();
                options.TextExportMode = TextExportMode.Text;//设置导出模式为文本


                gridControl1.ExportToXlsx(fileDialog.FileName, options);
                XtraMessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        
        
    }
}
