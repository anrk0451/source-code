﻿namespace TianYuan_New.Business
{
    partial class ServiceGoods
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions1 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServiceGoods));
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions2 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions3 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions4 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions5 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions6 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions7 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions8 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions9 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions10 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions imageListBoxItemImageOptions11 = new DevExpress.XtraEditors.Controls.ImageListBoxItemImageOptions();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            this.imageListBoxControl1 = new DevExpress.XtraEditors.ImageListBoxControl();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.sI01BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myds1 = new TianYuan_New.Myds();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colPRICE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colSI001 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSI002 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSI003 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSI005 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSORTID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSTATUS = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSI088 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gI01BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myds2 = new TianYuan_New.Myds();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colGI001 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGI002 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGI003 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGI005 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPRICE1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colSORTID1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSTATUS1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGI088 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.sI01TableAdapter1 = new TianYuan_New.MydsTableAdapters.SI01TableAdapter();
            this.gI01TableAdapter1 = new TianYuan_New.MydsTableAdapters.GI01TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.imageListBoxControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sI01BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myds1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gI01BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myds2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            this.SuspendLayout();
            // 
            // imageListBoxControl1
            // 
            this.imageListBoxControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.imageListBoxControl1.Dock = System.Windows.Forms.DockStyle.Left;
            imageListBoxItemImageOptions1.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions1.Image")));
            imageListBoxItemImageOptions2.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions2.Image")));
            imageListBoxItemImageOptions3.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions3.Image")));
            imageListBoxItemImageOptions4.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions4.Image")));
            imageListBoxItemImageOptions5.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions5.Image")));
            imageListBoxItemImageOptions6.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions6.Image")));
            imageListBoxItemImageOptions7.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions7.Image")));
            imageListBoxItemImageOptions8.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions8.Image")));
            imageListBoxItemImageOptions9.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions9.Image")));
            imageListBoxItemImageOptions10.Image = ((System.Drawing.Image)(resources.GetObject("imageListBoxItemImageOptions10.Image")));
            imageListBoxItemImageOptions11.Image = global::TianYuan_New.Properties.Resources.columns_32x32;
            this.imageListBoxControl1.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageListBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("守灵厅", "", imageListBoxItemImageOptions1, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("冷藏柜", "", imageListBoxItemImageOptions2, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("休息室", "", imageListBoxItemImageOptions3, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("告别厅", "", imageListBoxItemImageOptions4, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("火化标准", "", imageListBoxItemImageOptions5, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("灵车标准", "", imageListBoxItemImageOptions6, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("殡仪服务", "", imageListBoxItemImageOptions7, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("骨灰盒", "", imageListBoxItemImageOptions8, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("纸棺", "", imageListBoxItemImageOptions9, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("祭品", "", imageListBoxItemImageOptions10, null),
            new DevExpress.XtraEditors.Controls.ImageListBoxItem("寄存附品", "", imageListBoxItemImageOptions11, null)});
            this.imageListBoxControl1.Location = new System.Drawing.Point(0, 0);
            this.imageListBoxControl1.Name = "imageListBoxControl1";
            this.imageListBoxControl1.Size = new System.Drawing.Size(195, 609);
            this.imageListBoxControl1.TabIndex = 1;
            this.imageListBoxControl1.SelectedIndexChanged += new System.EventHandler(this.imageListBoxControl1_SelectedIndexChanged);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.gridControl1);
            this.panelControl1.Controls.Add(this.gridControl2);
            this.panelControl1.Controls.Add(this.barDockControlLeft);
            this.panelControl1.Controls.Add(this.barDockControlRight);
            this.panelControl1.Controls.Add(this.barDockControlBottom);
            this.panelControl1.Controls.Add(this.barDockControlTop);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(195, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(854, 609);
            this.panelControl1.TabIndex = 2;
            // 
            // gridControl1
            // 
            this.gridControl1.DataSource = this.sI01BindingSource;
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode1.RelationName = "Level1";
            this.gridControl1.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.gridControl1.Location = new System.Drawing.Point(2, 58);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.MenuManager = this.barManager1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit2,
            this.repositoryItemTextEdit1});
            this.gridControl1.Size = new System.Drawing.Size(850, 549);
            this.gridControl1.TabIndex = 16;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // sI01BindingSource
            // 
            this.sI01BindingSource.DataMember = "SI01";
            this.sI01BindingSource.DataSource = this.myds1;
            this.sI01BindingSource.Sort = "";
            // 
            // myds1
            // 
            this.myds1.DataSetName = "Myds";
            this.myds1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gridView1
            // 
            this.gridView1.ActiveFilterString = "[STATUS] <> \'0\'";
            this.gridView1.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridView1.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gridView1.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gridView1.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10.8F);
            this.gridView1.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseImage = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colPRICE,
            this.colSI001,
            this.colSI002,
            this.colSI003,
            this.colSI005,
            this.colSORTID,
            this.colSTATUS,
            this.colSI088,
            this.gridColumn1});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.IndicatorWidth = 48;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsCustomization.AllowFilter = false;
            this.gridView1.OptionsCustomization.AllowSort = false;
            this.gridView1.OptionsFilter.AllowFilterEditor = false;
            this.gridView1.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.EnableAppearanceOddRow = true;
            this.gridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView1.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.PaintStyleName = "Skin";
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colSORTID, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridView1.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.gridView1_CustomDrawRowIndicator);
            this.gridView1.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridView1_InitNewRow);
            this.gridView1.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView1_CellValueChanged);
            this.gridView1.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridView1_ValidateRow);
            this.gridView1.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridView1_ValidatingEditor);
            // 
            // colPRICE
            // 
            this.colPRICE.Caption = "单价";
            this.colPRICE.ColumnEdit = this.repositoryItemTextEdit1;
            this.colPRICE.DisplayFormat.FormatString = "N2";
            this.colPRICE.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colPRICE.FieldName = "PRICE";
            this.colPRICE.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("colPRICE.ImageOptions.Image")));
            this.colPRICE.Name = "colPRICE";
            this.colPRICE.Visible = true;
            this.colPRICE.VisibleIndex = 1;
            this.colPRICE.Width = 100;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.EditFormat.FormatString = "##,##0.00";
            this.repositoryItemTextEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEdit1.Mask.EditMask = "n2";
            this.repositoryItemTextEdit1.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // colSI001
            // 
            this.colSI001.FieldName = "SI001";
            this.colSI001.Name = "colSI001";
            this.colSI001.OptionsColumn.AllowShowHide = false;
            // 
            // colSI002
            // 
            this.colSI002.FieldName = "SI002";
            this.colSI002.Name = "colSI002";
            this.colSI002.OptionsColumn.AllowShowHide = false;
            // 
            // colSI003
            // 
            this.colSI003.Caption = "服务项目名称";
            this.colSI003.FieldName = "SI003";
            this.colSI003.Name = "colSI003";
            this.colSI003.Visible = true;
            this.colSI003.VisibleIndex = 0;
            this.colSI003.Width = 180;
            // 
            // colSI005
            // 
            this.colSI005.FieldName = "SI005";
            this.colSI005.Name = "colSI005";
            this.colSI005.OptionsColumn.AllowShowHide = false;
            // 
            // colSORTID
            // 
            this.colSORTID.FieldName = "SORTID";
            this.colSORTID.Name = "colSORTID";
            this.colSORTID.OptionsColumn.AllowShowHide = false;
            // 
            // colSTATUS
            // 
            this.colSTATUS.FieldName = "STATUS";
            this.colSTATUS.Name = "colSTATUS";
            this.colSTATUS.OptionsColumn.AllowShowHide = false;
            // 
            // colSI088
            // 
            this.colSI088.Caption = "助记符";
            this.colSI088.FieldName = "SI088";
            this.colSI088.Name = "colSI088";
            this.colSI088.Visible = true;
            this.colSI088.VisibleIndex = 2;
            this.colSI088.Width = 120;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "gridColumn1";
            this.gridColumn1.FieldName = "SI077";
            this.gridColumn1.Name = "gridColumn1";
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this.panelControl1;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem2,
            this.barButtonItem1,
            this.barButtonItem3,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonItem7});
            this.barManager1.MaxItemId = 8;
            // 
            // bar1
            // 
            this.bar1.BarName = "工具";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem2, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem1, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem3, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem4, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem5, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.barButtonItem6, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem7)});
            this.bar1.Offset = 1;
            this.bar1.OptionsBar.AllowQuickCustomization = false;
            this.bar1.OptionsBar.DrawBorder = false;
            this.bar1.Text = "工具";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "新建";
            this.barButtonItem2.Id = 1;
            this.barButtonItem2.ImageOptions.Image = global::TianYuan_New.Properties.Resources.addfile_32x32;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "删除";
            this.barButtonItem1.Id = 2;
            this.barButtonItem1.ImageOptions.Image = global::TianYuan_New.Properties.Resources.cancel_32x32;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "上移";
            this.barButtonItem3.Id = 3;
            this.barButtonItem3.ImageOptions.Image = global::TianYuan_New.Properties.Resources.moveup_32x32;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "下移";
            this.barButtonItem4.Id = 4;
            this.barButtonItem4.ImageOptions.Image = global::TianYuan_New.Properties.Resources.movedown_32x32;
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "保存";
            this.barButtonItem5.Id = 5;
            this.barButtonItem5.ImageOptions.Image = global::TianYuan_New.Properties.Resources.saveas_32x32;
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "刷新";
            this.barButtonItem6.Id = 6;
            this.barButtonItem6.ImageOptions.Image = global::TianYuan_New.Properties.Resources.convert_32x32;
            this.barButtonItem6.Name = "barButtonItem6";
            this.barButtonItem6.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem6_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "pp";
            this.barButtonItem7.Id = 7;
            this.barButtonItem7.Name = "barButtonItem7";
            this.barButtonItem7.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barButtonItem7.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem7_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(2, 2);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(850, 56);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(2, 607);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(850, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(2, 58);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 549);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(852, 58);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 549);
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            this.repositoryItemTextEdit2.NullValuePrompt = "请输入角色名";
            this.repositoryItemTextEdit2.NullValuePromptShowForEmptyValue = true;
            // 
            // gridControl2
            // 
            this.gridControl2.DataSource = this.gI01BindingSource;
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode2.RelationName = "Level1";
            this.gridControl2.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode2});
            this.gridControl2.Location = new System.Drawing.Point(2, 58);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.MenuManager = this.barManager1;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit4,
            this.repositoryItemTextEdit3,
            this.repositoryItemTextEdit5});
            this.gridControl2.Size = new System.Drawing.Size(850, 549);
            this.gridControl2.TabIndex = 21;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            this.gridControl2.Visible = false;
            // 
            // gI01BindingSource
            // 
            this.gI01BindingSource.DataMember = "GI01";
            this.gI01BindingSource.DataSource = this.myds2;
            this.gI01BindingSource.Sort = "";
            // 
            // myds2
            // 
            this.myds2.DataSetName = "Myds";
            this.myds2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gridView2
            // 
            this.gridView2.ActiveFilterString = "[STATUS] <> \'0\'";
            this.gridView2.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView2.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridView2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gridView2.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gridView2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10.8F);
            this.gridView2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseImage = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colGI001,
            this.colGI002,
            this.colGI003,
            this.colGI005,
            this.colPRICE1,
            this.colSORTID1,
            this.colSTATUS1,
            this.colGI088,
            this.gridColumn2});
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Count, "GI001", this.colGI003, "")});
            this.gridView2.IndicatorWidth = 48;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsCustomization.AllowFilter = false;
            this.gridView2.OptionsCustomization.AllowSort = false;
            this.gridView2.OptionsFilter.AllowFilterEditor = false;
            this.gridView2.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridView2.OptionsView.ColumnAutoWidth = false;
            this.gridView2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView2.OptionsView.EnableAppearanceOddRow = true;
            this.gridView2.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView2.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gridView2.OptionsView.ShowFooter = true;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView2.PaintStyleName = "Skin";
            this.gridView2.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colSORTID1, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridView2.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.gridView2_CustomDrawRowIndicator);
            this.gridView2.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridView2_InitNewRow);
            this.gridView2.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView2_CellValueChanged);
            this.gridView2.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridView2_ValidateRow);
            this.gridView2.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridView2_ValidatingEditor);
            // 
            // colGI001
            // 
            this.colGI001.FieldName = "GI001";
            this.colGI001.Name = "colGI001";
            this.colGI001.OptionsColumn.AllowShowHide = false;
            // 
            // colGI002
            // 
            this.colGI002.FieldName = "GI002";
            this.colGI002.Name = "colGI002";
            this.colGI002.OptionsColumn.AllowShowHide = false;
            // 
            // colGI003
            // 
            this.colGI003.Caption = "项目名称";
            this.colGI003.FieldName = "GI003";
            this.colGI003.Name = "colGI003";
            this.colGI003.Visible = true;
            this.colGI003.VisibleIndex = 0;
            this.colGI003.Width = 180;
            // 
            // colGI005
            // 
            this.colGI005.FieldName = "GI005";
            this.colGI005.Name = "colGI005";
            this.colGI005.OptionsColumn.AllowShowHide = false;
            // 
            // colPRICE1
            // 
            this.colPRICE1.Caption = "单价";
            this.colPRICE1.ColumnEdit = this.repositoryItemTextEdit5;
            this.colPRICE1.DisplayFormat.FormatString = "N2";
            this.colPRICE1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colPRICE1.FieldName = "PRICE";
            this.colPRICE1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("colPRICE1.ImageOptions.Image")));
            this.colPRICE1.Name = "colPRICE1";
            this.colPRICE1.Visible = true;
            this.colPRICE1.VisibleIndex = 1;
            this.colPRICE1.Width = 100;
            // 
            // repositoryItemTextEdit5
            // 
            this.repositoryItemTextEdit5.AutoHeight = false;
            this.repositoryItemTextEdit5.DisplayFormat.FormatString = "N2";
            this.repositoryItemTextEdit5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEdit5.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEdit5.Mask.EditMask = "N2";
            this.repositoryItemTextEdit5.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit5.Name = "repositoryItemTextEdit5";
            // 
            // colSORTID1
            // 
            this.colSORTID1.FieldName = "SORTID";
            this.colSORTID1.Name = "colSORTID1";
            this.colSORTID1.OptionsColumn.AllowShowHide = false;
            // 
            // colSTATUS1
            // 
            this.colSTATUS1.FieldName = "STATUS";
            this.colSTATUS1.Name = "colSTATUS1";
            this.colSTATUS1.OptionsColumn.AllowShowHide = false;
            // 
            // colGI088
            // 
            this.colGI088.Caption = "助记符";
            this.colGI088.FieldName = "GI088";
            this.colGI088.Name = "colGI088";
            this.colGI088.Visible = true;
            this.colGI088.VisibleIndex = 2;
            this.colGI088.Width = 120;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "gridColumn2";
            this.gridColumn2.FieldName = "GI077";
            this.gridColumn2.Name = "gridColumn2";
            // 
            // repositoryItemTextEdit4
            // 
            this.repositoryItemTextEdit4.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemTextEdit4.AutoHeight = false;
            this.repositoryItemTextEdit4.Name = "repositoryItemTextEdit4";
            this.repositoryItemTextEdit4.NullValuePrompt = "请输入角色名";
            this.repositoryItemTextEdit4.NullValuePromptShowForEmptyValue = true;
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AutoHeight = false;
            this.repositoryItemTextEdit3.EditFormat.FormatString = "##,##0.00";
            this.repositoryItemTextEdit3.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemTextEdit3.Mask.EditMask = "n2";
            this.repositoryItemTextEdit3.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // sI01TableAdapter1
            // 
            this.sI01TableAdapter1.ClearBeforeFill = true;
            // 
            // gI01TableAdapter1
            // 
            this.gI01TableAdapter1.ClearBeforeFill = true;
            // 
            // ServiceGoods
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.imageListBoxControl1);
            this.Margin = new System.Windows.Forms.Padding(3);
            this.Name = "ServiceGoods";
            this.Size = new System.Drawing.Size(1049, 609);
            this.Load += new System.EventHandler(this.ServiceGoods_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.imageListBoxControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sI01BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myds1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gI01BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myds2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.ImageListBoxControl imageListBoxControl1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private System.Windows.Forms.BindingSource sI01BindingSource;
        private Myds myds1;
        private MydsTableAdapters.SI01TableAdapter sI01TableAdapter1;
        private DevExpress.XtraGrid.Columns.GridColumn colPRICE;
        private DevExpress.XtraGrid.Columns.GridColumn colSI001;
        private DevExpress.XtraGrid.Columns.GridColumn colSI002;
        private DevExpress.XtraGrid.Columns.GridColumn colSI003;
        private DevExpress.XtraGrid.Columns.GridColumn colSI005;
        private DevExpress.XtraGrid.Columns.GridColumn colSORTID;
        private DevExpress.XtraGrid.Columns.GridColumn colSTATUS;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private System.Windows.Forms.BindingSource gI01BindingSource;
        private Myds myds2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit4;
        private MydsTableAdapters.GI01TableAdapter gI01TableAdapter1;
        private DevExpress.XtraGrid.Columns.GridColumn colGI001;
        private DevExpress.XtraGrid.Columns.GridColumn colGI002;
        private DevExpress.XtraGrid.Columns.GridColumn colGI003;
        private DevExpress.XtraGrid.Columns.GridColumn colGI005;
        private DevExpress.XtraGrid.Columns.GridColumn colPRICE1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit5;
        private DevExpress.XtraGrid.Columns.GridColumn colSORTID1;
        private DevExpress.XtraGrid.Columns.GridColumn colSTATUS1;
        private DevExpress.XtraGrid.Columns.GridColumn colGI088;
        private DevExpress.XtraGrid.Columns.GridColumn colSI088;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
    }
}
