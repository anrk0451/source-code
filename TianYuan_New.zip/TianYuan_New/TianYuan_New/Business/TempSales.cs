﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using DevExpress.XtraGrid.Columns;
using TianYuan_New.Windows;
using TianYuan_New.ActionObject;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Base;

namespace TianYuan_New.Business
{
    /// <summary>
    /// 临时性销售对象
    /// </summary>
    public partial class TempSales : BusinessObject
    {
        public DataTable Si01 { get; }  = new DataTable("AllValidItem");
        private DataTable dt_sa01 = new DataTable("SA01");
        private string accountId = string.Empty;

        private OracleDataAdapter si01Adapter = 
            new OracleDataAdapter("select item_type,item_id,item_text,price,sortId,zjf,1 nums,accountId from v_allvaliditem where item_type in ('10','11','12','05') order by item_type,sortId", SqlAssist.conn);
        private OracleDataAdapter sa01Adapter =
            new OracleDataAdapter("select * from sa01 where 1<0",SqlAssist.conn);

        public TempSales()
        {
            InitializeComponent();
        }

        public override void Business_Init()
        {
            base.Business_Init();
            accountId = this.cdata["parm"].ToString();
        }

        private void TempSales_Load(object sender, EventArgs e)
        {
            ////设置下拉数据窗口
            si01Adapter.Fill(Si01);

            gridControl1.DataSource = dt_sa01;
            sa01Adapter.Fill(dt_sa01); 
        }


        /// <summary>
        /// 绘制行号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomDrawRowIndicator_1(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }


        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            FireBusinessMisc frm_misc = new FireBusinessMisc();
            frm_misc.cdata["businessObject"] = this;
            frm_misc.cdata["accountId"] = accountId;

            if (frm_misc.ShowDialog() == DialogResult.OK)
            {
                List<string> itemId_list = this.cdata["itemIdList"] as List<string>;
                List<string> itemType_list = this.cdata["itemTypeList"] as List<string>;
                List<decimal> price_list = this.cdata["priceList"] as List<decimal>;
                List<int> nums_list = this.cdata["numsList"] as List<int>;
                int re = 0;

                for (int i = 0; i < itemId_list.Count; i++)
                {
                    if (itemType_list[i] == "10" || itemType_list[i] == "11")
                    {
                        re = gridView1.LocateByValue("SA002", itemType_list[i]);
                        if (re > 0)
                        {
                            
                            if (itemType_list[i] == "10")
                            {
                                if (MessageBox.Show("已经选择【骨灰盒】,是否要替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) continue;
                            }
                            else if (itemId_list[i] == "11")
                            {
                                if (MessageBox.Show("已经选择【纸棺】,是否要替换?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) continue;
                            }
                            gridView1.DeleteRow(re);
                        }
                    }

                    re = gridView1.LocateByValue("SA004", itemId_list[i]);
                    if (re >= 0)
                    {
                        if (MessageBox.Show("【" + gridView1.GetRowCellValue(re, "SA003").ToString() + "】已经存在,要替换吗?",
                            "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No) continue;
                        gridView1.DeleteRow(re);
                    }

                    DataRow dr = dt_sa01.Rows.Add();
                    dr["SA003"] = TempSalesAction.GetItemFullName(itemId_list[i]);
                    dr["SA002"] = itemType_list[i];
                    dr["SA004"] = itemId_list[i];
                    dr["PRICE"] = price_list[i];
                    dr["SA005"] = "1";
                    dr["NUMS"] = nums_list[i];
                    dr["SA007"] = price_list[i] * nums_list[i];

                    dr.EndEdit();
                }
                //RefreshSalesData();
            }
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gridView1.FocusedRowHandle >= 0)
            {
                EditItem(gridView1.FocusedRowHandle);
            }
        }

        /// <summary>
        /// 修改销售记录
        /// </summary>
        /// <param name="rowHandle"></param>
        private void EditItem(int rowHandle)
        {
            FireSalesEdit frm_modi = new FireSalesEdit();
            frm_modi.cdata["DATAROW"] = dt_sa01.Rows[gridView1.GetDataSourceRowIndex(rowHandle)];
            frm_modi.ShowDialog();
        }

        /// <summary>
        /// 删除销售记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gridView1.SelectedRowsCount ==0)
            {
                MessageBox.Show("请先选择要删除的记录!","提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            for (int i= gridView1.RowCount; i >= 0; i--)
            {
                if (gridView1.IsRowSelected(i))
                {
                    gridView1.DeleteRow(i);
                }
            }
        }

        /// <summary>
        /// 结算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if(gridView1.RowCount == 0)
            {
                MessageBox.Show("没选择项目!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            ///检查是否有价格为0 的项目
            for(int i = 0; i < gridView1.RowCount; i++)
            {
                if(Convert.ToDecimal(gridView1.GetRowCellValue(i,"PRICE")) <=0)
                {
                    MessageBox.Show("尚有未输入价格的项目!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    gridView1.SelectRow(i);
                    return;
                }
            }

            string s_cuname;

            if (string.IsNullOrEmpty(textEdit1.Text))
            {
                textEdit1.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                textEdit1.ErrorText = "请输入交款单位!";
                return;
            }
            else
            {
                s_cuname = textEdit1.EditValue.ToString();
            }

            List<string> itemId_List = new List<string>();
            List<string> itemType_List = new List<string>();
            List<decimal> prict_List = new List<decimal>();
            List<decimal> nums_List = new List<decimal>();
            for(int i=0;i< gridView1.RowCount; i++)
            {
                itemId_List.Add(gridView1.GetRowCellValue(i, "SA004").ToString());
                itemType_List.Add(gridView1.GetRowCellValue(i, "SA002").ToString());
                prict_List.Add(decimal.Parse(gridView1.GetRowCellValue(i, "PRICE").ToString()));
                nums_List.Add(decimal.Parse(gridView1.GetRowCellValue(i, "NUMS").ToString()));
            }
            string settleId = Tools.GetEntityPK("FA01");
            int re = TempSalesAction.TempSalesSettle(
                        accountId,s_cuname, settleId, itemId_List.ToArray(), itemType_List.ToArray(), prict_List.ToArray(), nums_List.ToArray(), Envior.cur_userId);
            if (re > 0)
            {
                if (MessageBox.Show("办理成功!现在打印收据吗?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    //打印收据
                    Print_invoice(settleId);                     
                }
                textEdit1.Text = "";
                dt_sa01.Clear();
            }
            
        }

        /// <summary>
        /// 打印收据
        /// </summary>
        /// <param name="settleId"></param>
        private void Print_invoice(string settleId)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         this.Handle.ToInt32(),
                                         commandNum,
                                         "TempSales_invoice",
                                         settleId,
                                         null
                );
        }

        /// <summary>
        /// 消息响应
        /// </summary>
        /// <param name="m"></param>
        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 10001:
                    int commandNum = m.WParam.ToInt32();
                    string responseText = PrtServAction.GetResponseText(commandNum);
                    MessageBox.Show(responseText,"提示",MessageBoxButtons.OK,MessageBoxIcon.Stop);
                    break;
                default:
                    base.DefWndProc(ref m);///调用基类函数处理非自定义消息。
                    break;
            }
        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            int row = -1;
            if ((row = (sender as ColumnView).FocusedRowHandle) >= 0)
            {
                this.EditItem(row);
            }
        }
    }
}
