﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OracleSugar;
using System.Configuration;
namespace TianYuan_New.Dao
{
    /// <summary>
    /// 数据库处理类
    /// </summary>
    public class SugarDao
    {
        //禁止实例化
        private SugarDao(){}
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;  
            }
        }
        public static SqlSugarClient GetInstance()
        {
            var db = new SqlSugarClient(ConnectionString);
            db.IsEnableLogEvent = true;//启用日志事件
            db.LogEventStarting = (sql, par) => { Console.WriteLine(sql + " " + par + "\r\n"); };
            return db;
        }
    }
}
