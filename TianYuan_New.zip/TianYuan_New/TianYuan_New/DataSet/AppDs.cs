﻿using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    /// <summary>
    /// 系统级DataSet(启动时装入)
    /// </summary>
    public class AppDs:BaseDs
    {
        public DataTable CastInfo { get; set; }
        public DataTable St01 { get; }
        public DataTable Uc01 { get; }

        public DataView CastInfo_AllService { get; set; }
        public DataView CastInfo_CanBindingService { get; }

        public DataView St01_e { get; }  //编辑版

        public OracleDataAdapter castInfoAdapter { get; set; }
        public OracleDataAdapter st01Adapter { get; }
        public OracleDataAdapter uc01Adapter { get; }

        private OracleCommandBuilder builder = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        public AppDs()
        {
          

            ///1.CASTINFO 服务商品类信息
            DataColumn SERVICESALESTYPE = new DataColumn("SERVICESALESTYPE", typeof(string));  //类别编号
            SERVICESALESTYPE.Unique = true;
            DataColumn TYPEDESC = new DataColumn("TYPEDESC", typeof(string));                  //类别名称

            CastInfo = new DataTable("CASTINFO");
            CastInfo.Columns.AddRange(new DataColumn[]
                    {SERVICESALESTYPE,TYPEDESC  });
            CastInfo.PrimaryKey = new DataColumn[] { SERVICESALESTYPE};                        //设置主键
            this.Tables.Add(CastInfo);

            /////////////////////////////////////////////////////////////////////////////////////////////
            castInfoAdapter = new OracleDataAdapter("select * from castinfo", SqlAssist.conn);
            builder = new OracleCommandBuilder(castInfoAdapter);

            CastInfo_AllService = new DataView(CastInfo);
            CastInfo_AllService.RowFilter = "ServiceSalesType <= '08' ";

            CastInfo_CanBindingService = new DataView(CastInfo);
            CastInfo_CanBindingService.RowFilter = "ServiceSalesType <= '08' and ServiceSalesType <> '05' ";

            ///2.数据字典表
            DataColumn col_st001 = new DataColumn("ST001", typeof(string));  // 数据字典编号
            DataColumn col_st002 = new DataColumn("ST002", typeof(string));  // 数据字典类别
            DataColumn col_st003 = new DataColumn("ST003", typeof(string));  // 数据字典值
            DataColumn col_sortId = new DataColumn("SORTID", typeof(int));   // 排序号
            DataColumn col_status = new DataColumn("STATUS", typeof(int));   // 状态

            St01 = new DataTable("St01");
            St01.Columns.AddRange(new DataColumn[]
                {col_st001,col_st002,col_st003,col_sortId,col_status});
            St01.PrimaryKey = new DataColumn[] { col_st001 };                //设置主键
            this.Tables.Add(St01);

            st01Adapter = new OracleDataAdapter("select * from st01 order by st002,sortId", SqlAssist.conn);

            St01_e = new DataView(St01);
            St01_e.RowFilter = "Status = '1'";

            ///3.操作员表
            Uc01 = new DataTable("Uc01");
            uc01Adapter = new OracleDataAdapter("select * from uc01", SqlAssist.conn);
            this.Tables.Add(Uc01);

        }


}
}
