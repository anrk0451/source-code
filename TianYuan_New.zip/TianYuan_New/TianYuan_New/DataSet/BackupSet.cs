﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace TianYuan_New.DataSet
{
    [Serializable]
    class BackupSet : BaseDs
    {
        private DataTable dt_rc01 = new DataTable("RC01");
        private OracleDataAdapter rc01Adapter = new OracleDataAdapter("select * from rc01", SqlAssist.conn);

        private DataTable dt_ac01 = new DataTable("A01");
        private OracleDataAdapter ac01Adapter = new OracleDataAdapter("select * from ac01", SqlAssist.conn);

        private DataTable dt_bi01 = new DataTable("BI01");
        private OracleDataAdapter bi01Adapter = new OracleDataAdapter("select * from bi01", SqlAssist.conn);

        private DataTable dt_fa01 = new DataTable("FA01");
        private OracleDataAdapter fa01Adapter = new OracleDataAdapter("select * from fa01", SqlAssist.conn);

        private DataTable dt_fa02 = new DataTable("FA02");
        private OracleDataAdapter fa02Adapter = new OracleDataAdapter("select * from fa02", SqlAssist.conn);
        public BackupSet()
        {
            this.Tables.Add(dt_rc01);
            this.Tables.Add(dt_ac01);
            this.Tables.Add(dt_bi01);
            this.Tables.Add(dt_fa01);
            this.Tables.Add(dt_fa02);

            rc01Adapter.Fill(dt_rc01);
            rc01Adapter.Fill(dt_ac01);
            bi01Adapter.Fill(dt_bi01);
            fa01Adapter.Fill(dt_fa01);
            fa02Adapter.Fill(dt_fa02);

        }

        public void Backup(string fname)
        {
            this.RemotingFormat = SerializationFormat.Binary;
            FileStream fs = new FileStream(fname, FileMode.Create);
            BinaryFormatter bFormat = new BinaryFormatter();
            bFormat.Serialize(fs, this);
            fs.Close();
            this.Clear();
        }
    }
}
