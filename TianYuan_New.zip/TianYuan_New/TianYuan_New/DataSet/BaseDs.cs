﻿
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TianYuan_New.DataSet
{
    public class BaseDs : System.Data.DataSet
    {


    }
}
