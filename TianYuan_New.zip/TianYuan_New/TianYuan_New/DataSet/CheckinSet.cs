﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    /// <summary>
    /// 进灵登记数据集
    /// </summary>
    class CheckinSet:BaseDs
    {
        public DataTable St01 { get;}                   //数据字典
        public DataTable Ac01 { get; }                  //逝者信息
        public DataTable Uc01 { get; }                  //操作员

        public OracleDataAdapter st01Adapter {get;}
        public OracleDataAdapter ac01Adapter { get; }
        public OracleDataAdapter uc01Adapter { get; }

        public CheckinSet()
        {
            //1.St01
            DataColumn col_st001 = new DataColumn("ST001", typeof(string));  // 数据字典编号
            DataColumn col_st002 = new DataColumn("ST002", typeof(string));  // 数据字典类别
            DataColumn col_st003 = new DataColumn("ST003", typeof(string));  // 数据字典值
            DataColumn col_sortId = new DataColumn("SORTID", typeof(int));   // 排序号

            St01 = new DataTable("St01");
            St01.Columns.AddRange(new DataColumn[]
                {col_st001,col_st002,col_st003,col_sortId});
            St01.PrimaryKey = new DataColumn[] { col_st001 };                //设置主键
            this.Tables.Add(St01);

            st01Adapter = new OracleDataAdapter("select * from st01 where status = '1' order by st002,sortId", SqlAssist.conn);

            //2.Ac01
            DataColumn col_ac001 = new DataColumn("AC001", typeof(string));   // 逝者编号
            col_ac001.Unique = true;
            col_ac001.AllowDBNull = false;
            DataColumn col_ac003 = new DataColumn("AC003", typeof(string));   // 逝者姓名
            DataColumn col_ac002 = new DataColumn("AC002", typeof(string));   // 性别 0-男 1-女 2-不详
            DataColumn col_ac004 = new DataColumn("AC004", typeof(int));      // 年龄
            DataColumn col_ac014 = new DataColumn("AC014", typeof(string));      // 身份证号
            DataColumn col_ac010 = new DataColumn("AC010", typeof(DateTime)); // 死亡时间
            DataColumn col_ac015 = new DataColumn("AC015", typeof(DateTime)); // 火化时间
            DataColumn col_ac005 = new DataColumn("AC005", typeof(string));   // 死亡原因
            DataColumn col_ac007 = new DataColumn("AC007", typeof(string));   // 所属区县
            DataColumn col_ac008 = new DataColumn("AC008", typeof(string));   // 详细地址
            DataColumn col_ac009 = new DataColumn("AC009", typeof(string));   // 接灵地址
            DataColumn col_ac020 = new DataColumn("AC020", typeof(DateTime)); // 到达中心时间
            DataColumn col_ac018 = new DataColumn("AC018", typeof(DateTime)); // 告别时间
            DataColumn col_ac019 = new DataColumn("AC019", typeof(DateTime)); // 开光时间
            DataColumn col_ac022 = new DataColumn("AC022", typeof(string));   // 主持人
            DataColumn col_ac050 = new DataColumn("AC050", typeof(string));   // 联系人
            DataColumn col_ac051 = new DataColumn("AC051", typeof(string));   // 联系电话
            DataColumn col_ac052 = new DataColumn("AC052", typeof(string));   // 与逝者关系
            DataColumn col_ac055 = new DataColumn("AC055", typeof(string));   // 联系地址
            DataColumn col_ac060 = new DataColumn("AC060", typeof(string));   // 接灵司机
            DataColumn col_ac100 = new DataColumn("AC100", typeof(string));   // 登记经办人
            DataColumn col_ac200 = new DataColumn("AC200", typeof(DateTime)); // 登记时间
            DataColumn col_ac110 = new DataColumn("AC110", typeof(string));   // 最后修改人
            DataColumn col_ac220 = new DataColumn("AC220", typeof(DateTime)); // 最后修改日期
            DataColumn col_ac099 = new DataColumn("AC099", typeof(string));   // 备注
            DataColumn col_status = new DataColumn("STATUS", typeof(string)); // 当前状态  1-正常 0-删除




            Ac01 = new DataTable("Ac01");
            Ac01.Columns.AddRange(new DataColumn[] {col_ac001,col_ac003,col_ac002,col_ac004,col_ac014,col_ac010,col_ac015,col_ac005,col_ac007,col_ac008,col_ac009,col_ac020,
                col_ac018,col_ac019,col_ac022,col_ac050,col_ac051,col_ac052,col_ac055,col_ac060,col_ac100,col_ac200,col_ac110,col_ac220,col_ac099,col_status
            });
            Ac01.PrimaryKey = new DataColumn[] { col_ac001 };                 //设置主键
            this.Tables.Add(Ac01);
            ac01Adapter = new OracleDataAdapter("select * from ac01 where status <> '0' and ac077 = '1' ", SqlAssist.conn);
 

            //3.Uc01
            DataColumn col_uc001 = new DataColumn("UC001", typeof(string));  // 操作员编号
            DataColumn col_uc003 = new DataColumn("UC003", typeof(string));  // 操作员姓名
            Uc01 = new DataTable("Uc01");
            Uc01.Columns.AddRange(new DataColumn[] { col_uc001, col_uc003 });
            this.Tables.Add(Uc01);
            uc01Adapter = new OracleDataAdapter("select * from uc01", SqlAssist.conn);

        }

    }
}
