﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    /// <summary>
    /// 套餐类
    /// </summary>
    class ComboSet:BaseDs
    {
        public DataTable Cb01 { get; set; }
        public DataTable Cb02 { get; set; }
        public DataTable v_validItem { get; }
        public DataView v_validItemView { get; }
 


        public OracleDataAdapter cb01Adapter { get; set; }
        public OracleDataAdapter cb02Adapter { get; set; }
        public OracleDataAdapter v_validItemAdapter { get; }

        private OracleCommandBuilder builder = null;
        //构造函数
        public ComboSet()
        {
            ///1.Cb01
            DataColumn CB001 = new DataColumn("CB001", typeof(string));  //套餐编号
            CB001.AllowDBNull = false;
            CB001.Unique = true;

            DataColumn CB002 = new DataColumn("CB002", typeof(string));    //套餐类别 0-服务套餐 1-用户定义套餐
        
            DataColumn CB003 = new DataColumn("CB003", typeof(string));    //套餐名称
            CB003.AllowDBNull = false;

            DataColumn CB005 = new DataColumn("CB005", typeof(string));    //关联服务类别
            DataColumn CB077 = new DataColumn("CB077", typeof(string));    //帐套编号
            DataColumn STATUS = new DataColumn("STATUS", typeof(string));  //0-删除 1-正常

            Cb01 = new DataTable("Cb01");
            Cb01.Columns.AddRange(new DataColumn[]
                {CB001,CB002,CB003,CB005,STATUS,CB077});
            Cb01.PrimaryKey = new DataColumn[] { CB001 };  //设置主键
            this.Tables.Add(Cb01);
            /////////////////////////////////////////////////////////////////////////////////////////////
            cb01Adapter = new OracleDataAdapter("select * from cb01 where status = '1' and cb077 = :cb077", SqlAssist.conn);
            builder = new OracleCommandBuilder(cb01Adapter);

            ///2.Cb02

            DataColumn CB201 = new DataColumn("CB201", typeof(string));
            CB201.AllowDBNull = false;
            CB201.Unique = true;

            DataColumn CB001_2 = new DataColumn("CB001", typeof(string));
            CB001_2.AllowDBNull = true;
            DataColumn CB021 = new DataColumn("CB021", typeof(string));    //服务或商品编号
            CB021.AllowDBNull = true;
            DataColumn CB022 = new DataColumn("CB022", typeof(string));    //服务类别 
            CB022.AllowDBNull = true;

            DataColumn CB030 = new DataColumn("CB030", typeof(decimal));   //数量
            CB030.AllowDBNull = false;

            Cb02 = new DataTable("Cb02");
            Cb02.Columns.AddRange(new DataColumn[]
                {CB201,CB001_2,CB021, CB022,CB030});
            Cb02.PrimaryKey = new DataColumn[] { CB201 };  //设置主键
            this.Tables.Add(Cb02);

            cb02Adapter = new OracleDataAdapter("select * from cb02 ", SqlAssist.conn);
            builder = new OracleCommandBuilder(cb02Adapter);

            ///3.v_allvaliditem
            DataColumn item_id = new DataColumn("item_id", typeof(string));
            DataColumn item_type = new DataColumn("item_type", typeof(string));
            DataColumn item_type_text = new DataColumn("item_type_text", typeof(string));
            DataColumn item_text = new DataColumn("item_text", typeof(string));
            DataColumn price = new DataColumn("price", typeof(decimal));
            DataColumn sortId = new DataColumn("sortId", typeof(int));
            DataColumn zjf = new DataColumn("zjf", typeof(string));
            v_validItem = new DataTable("v_validItem");
            v_validItem.Columns.AddRange(new DataColumn[]
                {item_id,item_text,item_type,item_type_text,price,sortId,zjf});
            this.Tables.Add(v_validItem);
            v_validItemAdapter = new OracleDataAdapter("select * from v_allvaliditem where item_type in ('05','10','11','12','13') order by item_type,sortId ", SqlAssist.conn);

            v_validItemView = new DataView(v_validItem);

            
        }
    }
}
