﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    //销售 Dataset
    class FireSalesSet :BaseDs
    {
        public DataTable Sa01 { get; }                   //销售表
        public OracleDataAdapter sa01Adapter { get; }

        public FireSalesSet()
        {
            //1.Sa01 
            DataColumn col_sa001 = new DataColumn("SA001", typeof(string));  // 销售流水号
            col_sa001.AllowDBNull = false;

            DataColumn col_ac001 = new DataColumn("AC001", typeof(string));  // 逝者编号
            DataColumn col_sa002 = new DataColumn("SA002", typeof(string));  // 服务或商品类别
            DataColumn col_sa003 = new DataColumn("SA003", typeof(string));  // 服务或商品名称
            DataColumn col_sa004 = new DataColumn("SA004", typeof(string));  // 服务或商品编号
            DataColumn col_sa005 = new DataColumn("SA005", typeof(string));  // 销售类别 0-火化业务 1-临时性销售 2骨灰寄存
            DataColumn col_price = new DataColumn("PRICE", typeof(decimal)); // 销售单价
            DataColumn col_nums = new DataColumn("NUMS", typeof(decimal));   // 数量
            DataColumn col_sa007= new DataColumn("SA007", typeof(decimal));  // 销售金额
            DataColumn col_sa006 = new DataColumn("SA006", typeof(decimal)); // 原始单价
            DataColumn col_sa008 = new DataColumn("SA008", typeof(string));  // 结算状态 0-未结算 1-已结算 2-退费
            DataColumn col_sa010 = new DataColumn("SA010", typeof(string));  // 结算流水号
            DataColumn col_status = new DataColumn("STATUS", typeof(string));// 状态 0-删除 1-正常
            DataColumn col_sa100 = new DataColumn("SA100", typeof(string));  // 经办人
            DataColumn col_sa200 = new DataColumn("SA200", typeof(DateTime));// 经办日期

            Sa01 = new DataTable("Sa01");
            Sa01.Columns.AddRange(new DataColumn[]
                {col_sa001,col_ac001,col_sa002,col_sa003,col_sa004,col_sa005,col_price,col_nums,col_sa007,col_sa006,col_sa008,
                col_sa010,col_status,col_sa100,col_sa200});
            Sa01.PrimaryKey = new DataColumn[] { col_sa001 };                //设置主键
            this.Tables.Add(Sa01);

            sa01Adapter = new OracleDataAdapter("select * from sa01 where sa005 = '0' and status = '1' and ac001 = :ac001 order by sa002,sa001", SqlAssist.conn);
            sa01Adapter.Requery = true;
        }
    }
}
