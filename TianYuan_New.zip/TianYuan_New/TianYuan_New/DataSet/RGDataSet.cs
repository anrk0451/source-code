﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    /// <summary>
    /// 寄存结构Dataset
    /// </summary>
    class RGDataSet:BaseDs
    {
        public DataTable Bi01 { get; set; }
        public DataTable Rg01 { get; set; }
        public OracleDataAdapter bi01Adapter { get; set; }


        /// <summary>
        /// 构造函数
        /// </summary>
        public RGDataSet()
        {
            ///1.Bi01
            DataColumn BI001 = new DataColumn("BI001", typeof(string));  //号位编号
            BI001.Unique = true;

            DataColumn RG001 = new DataColumn("RG001", typeof(string));  //架编号
            DataColumn BI020 = new DataColumn("BI020", typeof(string));  //寄存室编号
            DataColumn BI030 = new DataColumn("BI030", typeof(string));  //寄存楼编号
            DataColumn BI002 = new DataColumn("BI002", typeof(int));     //号位数字编号
            DataColumn BI003 = new DataColumn("BI003", typeof(string));  //号位文字描述
            DataColumn BI005 = new DataColumn("BI005", typeof(int));     //层数
            DataColumn BI007 = new DataColumn("BI007", typeof(string));  //价格锁 0-否 1-是
            DataColumn BI008 = new DataColumn("BI008", typeof(int));     //列数
            DataColumn BI009 = new DataColumn("BI009", typeof(decimal)); //价格
            DataColumn BI010 = new DataColumn("BI010", typeof(string));  //寄存逝者编号
            DataColumn STATUS = new DataColumn("STATUS", typeof(string));//状态 0-未用 1-占用 9-空闲

            Bi01 = new DataTable("Bi01");
            Bi01.Columns.AddRange(new DataColumn[]
                {BI001,RG001,BI020,BI030,BI002,BI003,BI005,BI007,BI008,BI009,BI010,STATUS});
            Bi01.PrimaryKey = new DataColumn[] { BI001 };  //设置主键
            this.Tables.Add(Bi01);
            /////////////////////////////////////////////////////////////////////////////////////////////

            bi01Adapter = new OracleDataAdapter("select * from bi01", SqlAssist.conn);
            OracleCommandBuilder builder = new OracleCommandBuilder(bi01Adapter);



        }

    }
}
