﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.DataSet
{
    /// <summary>
    /// 寄存登记 数据集
    /// </summary>
    class RegisterSet : BaseDs
    {
        public DataTable St01 { get; }                   //数据字典
        public DataTable Rc01 { get; }                   //寄存信息
        public DataTable Jcfp { get; }                   //寄存附品
        public DataTable Sa01 { get; }                   //销售记录
        public DataTable Cb02 { get; }                   //寄存套餐

        public OracleDataAdapter st01Adapter { get; }
        public OracleDataAdapter rc01Adapter { get; }
        public OracleDataAdapter jcfpAdapter { get; }
        public OracleDataAdapter sa01Adapter { get; }
        public OracleDataAdapter cb02Adapter { get; }

        public RegisterSet()
        {
            //1.St01
            DataColumn col_st001 = new DataColumn("ST001", typeof(string));  // 数据字典编号
            DataColumn col_st002 = new DataColumn("ST002", typeof(string));  // 数据字典类别
            DataColumn col_st003 = new DataColumn("ST003", typeof(string));  // 数据字典值
            DataColumn col_sortId = new DataColumn("SORTID", typeof(int));   // 排序号

            St01 = new DataTable("St01");
            St01.Columns.AddRange(new DataColumn[]
                {col_st001,col_st002,col_st003,col_sortId});
            St01.PrimaryKey = new DataColumn[] { col_st001 };                //设置主键
            this.Tables.Add(St01);

            st01Adapter = new OracleDataAdapter("select * from st01 where status = '1' and st002 = 'RELATION' order by st002,sortId", SqlAssist.conn);

            //2.Rc01
            Rc01 = new DataTable("Rc01");
            rc01Adapter = new OracleDataAdapter("select * from rc01 where status = '1' and trunc(rc200) = trunc(sysdate) order by rc001 desc", SqlAssist.conn);

            //3.Jcfp 寄存附品
            Jcfp = new DataTable("Jcfp");
            jcfpAdapter = new OracleDataAdapter("select * from V_ALLVALIDITEM where item_type = '13'", SqlAssist.conn);

            //4.Sa01
            Sa01 = new DataTable("Sa01");
            sa01Adapter = new OracleDataAdapter("select * from sa01 where 1<0",SqlAssist.conn);

            //5.Cb02
            Cb02 = new DataTable("Cb02");
            cb02Adapter = new OracleDataAdapter(@"select * from cb02 where cb001 in (select cb001 from cb01 where cb002 = '0' and cb005 = '08' and status = '1') order by cb022",
                                                    SqlAssist.conn);
        }
    }
}
