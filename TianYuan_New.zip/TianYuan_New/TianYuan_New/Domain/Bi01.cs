﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 寄存号位
    /// </summary>
    class Bi01
    {
        public string bi001 { get; set; }  //号位编号
        public string rg001 { get; set; }  //寄存架编号
        public string rg020 { get; set; }  //寄存室编号
        public string rg030 { get; set; }  //寄存楼编号
        public int bi002 { get; set; }     //号位数字编号
        public string bi003 { get; set; }  //号位描述
        public int bi005 { get; set; }     //层数
        public string bi007 { get; set; }  //价格锁 0-否 1-是
        public int bi008 { get; set; }     //列数
        public decimal bi009 { get; set; } //定价
        public string bi010 { get; set; }  //逝者编号
        public string status { get; set; } //状态 0-删除 1-占用 9-空闲 2-弃用
    }
}
