﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{   ////业务与对象映射表
    class Bo01
    {
        public string bo001 { get; set; }   //业务编号
        public string bo003 { get; set; }   //业务名称
        public string bo004 { get; set; }   //业务对象类型 w-窗口 x-xtratabpage对象
    }
}
