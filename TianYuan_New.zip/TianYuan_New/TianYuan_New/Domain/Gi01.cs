﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 商品信息
    /// </summary>
    class Gi01
    {
        public string gi001 { get; set; }  //商品编号
        public string gi002 { get; set; }  //类别
        public string gi003 { get; set; }  //项目名称
        public decimal price { get; set; } //单价
        public string gi005 { get; set; }  //发票分类编码
        public int sortId { get; set; }    //排序号
        public string gi088 { get; set; }  //助记符
        public string status { get; set; } //状态 0-删除 1-正常
    }
}
