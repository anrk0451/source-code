﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 层信息
    /// </summary>
    class Ly01
    {
        public string ly001 { get; set; }  //层编号
        public string rg001 { get; set; }  //架编号
        public int ly002 { get; set; }     //层号
        public decimal price { get; set; } //定价
    }
}
