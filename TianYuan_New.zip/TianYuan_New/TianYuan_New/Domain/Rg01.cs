﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{   ///寄存结构
    class Rg01
    {
        public string rg001 { get; set; }    //寄存单元编号
        public string rg002 { get; set; }    //类型 0-顶级节点 1-寄存堂 2-寄存室 3-排
        public string rg003 { get; set; }    //结构单元描述
        public string rg009 { get; set; }    //父节点编号
        public int rg010 { get; set; }       //单元起始编号
        public int rg011 { get; set; }       //单元截至编号
        public int rg020 { get; set; }       //层数
        public int rg021 { get; set; }       //每层号位数
        public string status { get; set; }   //状态 0-删除 1-正常

        public static string GenSuggestName(string level,string parent)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_GenSuggestName", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 200);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_level = new OracleParameter("Level", OracleDbType.Varchar2, 3);
            op_level.Direction = ParameterDirection.Input;
            op_level.Size = 3;
            op_level.Value = level;

            OracleParameter op_parent= new OracleParameter("Parent", OracleDbType.Varchar2, 10);
            op_parent.Direction = ParameterDirection.Input;
            op_parent.Size = 10;
            op_parent.Value = parent;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_level);
                cmd.Parameters.Add(op_parent);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }
    }
}
