﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TianYuan_New.Dao;
using TianYuan_New.Domain;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 系统角色对象 
    /// </summary>
    class Ro01
    {
        public string ro001 { get; set; }    //角色Id
        public string ro003 { get; set; }    //角色名称
        public string ro004 { get; set; }    //角色描述
        public string status { get; set; }   //当前状态
         
    }
}
