﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    //服务项目信息
    class Si01
    {
        public string si001 { get; set; }  //服务项目编号
        public string si002 { get; set; }  //服务类别
        public string si003 { get; set; }  //服务项目名称
        public decimal price { get; set; } //单价
        public string si005 { get; set; }  //发票分类编码
        public int sortId { get; set; }    //排序号
        public string si088 { get; set; }  //助记符 
        public string status { get; set; } //状态 0-删除 1-正常
    }
}
