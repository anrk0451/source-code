﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 数据字典项
    /// </summary>
    class St01
    {
        public string st001 { get; set; }   //数据字典项编号
        public string st002 { get; set; }   //类别
        public string st003 { get; set; }   //数据字典值
        public int sortId { get; set; }     //排序号
        public string status { get; set; }  //当前状态
    }
}
