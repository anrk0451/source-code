﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Windows.Forms;

namespace TianYuan_New.Domain
{
    /// <summary>
    /// 操作员表 uc01
    /// </summary>
    enum Uc01_status{
        NORMAL,
        REMOVED,
        FREEZE
    }
    class Uc01
    {

        //操作员编号
        public string uc001 { get; set; }
        //操作员代码
        public string uc002 { get; set; }
        //操作员姓名
        public string uc003 { get; set; }
        //密码(加密)
        public string uc004 { get; set; }
        //状态
        public string status { get; set; }

        public static string Uc01Status_Mapper(string value)
        {
            if (value == "1")
                return "正常";
            else if (value == "2")
                return "冻结";
            else if (value == "0")
                return "已删除";
            else
                return "";
        }


        /// <summary>
        /// 判断 uc002(用户代码)是否有效!
        /// </summary>
        /// <param name="uc001"></param>
        /// <returns></returns>
        public static Boolean Valid_uc002(string uc001,string uc002)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_ValidUc002 ", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2,10);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_uc001 = new OracleParameter("Uc001", OracleDbType.Varchar2, 10);
            op_uc001.Direction = ParameterDirection.Input;
            op_uc001.Size = 10;
            op_uc001.Value = uc001;

            OracleParameter op_uc002 = new OracleParameter("Uc002", OracleDbType.Varchar2, 20);
            op_uc002.Direction = ParameterDirection.Input;
            op_uc002.Size = 20;
            op_uc002.Value = uc002;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_uc001);
                cmd.Parameters.Add(op_uc002);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

            //MessageBox.Show(returnValue.Value.ToString());

            if (int.Parse(returnValue.Value.ToString()) > 0)
                return false;
            else
                return true;

        }


        //// 获取用户所属角色列表 
        public static string GetRolesList(string uc001)
        {
            OracleCommand cmd = new OracleCommand("pkg_business.fun_getRolesList", SqlAssist.conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            OracleParameter returnValue = new OracleParameter("result", OracleDbType.Varchar2, 200);
            returnValue.Direction = ParameterDirection.ReturnValue;

            OracleParameter op_uc001 = new OracleParameter("Uc001", OracleDbType.Varchar2, 10);
            op_uc001.Direction = ParameterDirection.Input;
            op_uc001.Size = 10;
            op_uc001.Value = uc001;

            try
            {
                cmd.Parameters.Add(returnValue);
                cmd.Parameters.Add(op_uc001);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

            return returnValue.Value.ToString();
        }
    }    
}
