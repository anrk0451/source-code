﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianYuan_New.Domain
{
    class Ur_Mapper
    {
        public string uc001 { get; set; }   //操作员编号
        public string ro001 { get; set; }   //角色ID
    }
}
