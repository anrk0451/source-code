﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Configuration;
using TianYuan_New.Dao;
using TianYuan_New.Domain;
using OracleSugar;
using System.Threading;
namespace TianYuan_New
{
    public partial class Login : DevExpress.XtraEditors.XtraForm
    {
        public Login()
        {             
            InitializeComponent(); 
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// 验证登陆
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            string s_userCode, s_pwd;
            s_userCode = textEdit_user.Text;
            s_pwd = textEdit_pwd.Text;

            if (string.IsNullOrEmpty(s_userCode))
            {                
                MessageBox.Show("请输入用户代码!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                textEdit_user.Focus();
                return;
            }
            if (string.IsNullOrEmpty(s_pwd))
            {
                MessageBox.Show("请输入密码!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textEdit_pwd.Focus();
                return;
            }
            /////////////////////  检索 密码  ///////////////////////////////
            using (SqlSugarClient db = SugarDao.GetInstance())
            {
                List<Uc01> row = db.Queryable<Uc01>().Where(it => it.uc002 == s_userCode).ToList();
                if (row.Count == 0)
                {
                    dxErrorProvider1.SetIconAlignment(textEdit_user, ErrorIconAlignment.MiddleRight);
                    dxErrorProvider1.SetError(textEdit_user, "无此用户!");                     
                    return;
                }
                else
                {
                    if (s_userCode == "root" && s_pwd == "mygirl")
                    {

                    }
                    else if (row[0].uc004 != Tools.EncryptWithMD5(s_pwd))
                    {
                        dxErrorProvider1.SetIconAlignment(textEdit_pwd, ErrorIconAlignment.MiddleRight);
                        dxErrorProvider1.SetError(textEdit_pwd, "密码错误!"); 
                        return;
                    }
                     
                    ///// 密码正确 可以登录！！！！                        
                    ///// 初始化环境变量
                    Envior.loginMode = '1';
                    Envior.cur_user = s_userCode;         //操作员代码
                    Envior.cur_userId = row[0].uc001;     //操作员Id
                    Envior.cur_userName = row[0].uc003;   //操作员姓名

                    //////////  登录成功后调用 !
                    ////Envior.mainform.loginSuccess();

                    DialogResult = DialogResult.OK;
                    this.Close();
                    
                }
            }
            
 
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //读取上次成功登陆的用户名
            string file = System.Windows.Forms.Application.ExecutablePath;
            Configuration config = ConfigurationManager.OpenExeConfiguration(file);
            String lastuser = config.AppSettings.Settings["lastusername"].Value.ToString();
            if (!String.IsNullOrEmpty(lastuser))
            {
                textEdit_user.Text = lastuser;
                textEdit_pwd.Text = Tools.Decrypt(config.AppSettings.Settings["lastpassword"].Value.ToString());
            }

            #region It's for test!
            //textEdit_user.Text = "root";
            //textEdit_pwd.Text = "root";
            #endregion

        }

        private void simpleButton1_Click_1(object sender, EventArgs e)
        {
            textEdit_user.Text = Tools.EncryptWithMD5("root");
        }
    }
}