﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraBars;
using TianYuan_New.Business;
using DevExpress.XtraSplashScreen;
using System.Threading;
using TianYuan_New.Domain;
using OracleSugar;
using TianYuan_New.Dao;
using DevExpress.XtraTab;
using System.Runtime.Remoting;
using DevExpress.XtraTab.ViewInfo;
using TianYuan_New.DataSet;
using Oracle.ManagedDataAccess.Client;
using System.Runtime.InteropServices;
using System.Diagnostics;
using TianYuan_New.ActionObject;
using TianYuan_New.Windows;
using System.Configuration;
using System.IO;
using Oracle.ManagedDataAccess.Types;

namespace TianYuan_New
{

    public partial class MainForm : DevExpress.XtraBars.Ribbon.RibbonForm
    {

        [DllImport("user32.dll", EntryPoint = "FindWindow")]
        private extern static IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);

        //追踪已经打开的Tab页
        private Dictionary<string, Bo01> businessTab = null;
        private Dictionary<string, XtraTabPage> openedTabPage = new Dictionary<string, XtraTabPage>();
        Process printprocess = new Process();
 

        public AppDs appds { get; set; }

         
        public MainForm()
        {          
            InitializeComponent();
            Envior.mainform = this;

            //启动打印服务进程
            //printprocess.StartInfo.FileName = @"G:\\TEMP\\pbnative\\pbnative.exe";
            printprocess.StartInfo.FileName = @"pbnative.exe";
            printprocess.Start();

            ///////  显示闪屏  ///////
            SplashScreenManager.ShowForm(typeof(SplashScreen1));
            Thread.Sleep(2000);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //显示应用标题信息
            this.Text = AppInfo.AppTitle;
            //使用单位
            barStaticItem_unit.Caption = AppInfo.UnitName;

            SplashScreenManager.CloseForm();

            ////////  显示登录窗口  //////////
            Login login = new Login();
            if(login.ShowDialog(this) == DialogResult.OK)
            {
                /////////////////////  成功登陆后处理   ///////////////////
                barStaticItem_ver.Caption = AppInfo.AppVersion; ;
                barStaticItem_username.Caption = Envior.cur_userName;

                //// 读取业务对象映射 /////
                using (SqlSugarClient db = SugarDao.GetInstance())
                {
                    List<Bo01> row = db.Queryable<Bo01>().Where(it => it.bo004 == "x").ToList();
                    businessTab = row.ToDictionary(key => key.bo001, value => value);
                }

                //// 装入系统 DataSet
                appds = new AppDs();
                appds.castInfoAdapter.Fill(appds.CastInfo);
                appds.st01Adapter.Fill(appds.St01);
                appds.uc01Adapter.Fill(appds.Uc01);
 
                this.ConnectPrtServ();
                login.Dispose();
            }

            
        }

        private void ribbon_Click(object sender, EventArgs e)
        {

        }

        private void accordionControlElement2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if(appds != null) appds.Dispose();
            SqlAssist.DisConnect();

            //关闭关联的打印进程
            if(!printprocess.HasExited) printprocess.Kill();
        }

        private void barHeaderItem1_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void barButtonItem1_ItemClick(object sender, ItemClickEventArgs e)
        {
            openBusinessObject("FireCheckin_brow");
        }

        /// <summary>
        /// 打开业务对象(如果没有则创建)
        /// </summary>
        public void openBusinessObject(string bo001)
        {
            openBusinessObject(bo001, null);
        }

        /// <summary>
        /// 打开业务对象(如果没有则创建)
        /// </summary>
        public void openBusinessObject(string bo001,object parm)
        {
            if (openedTabPage.ContainsKey(bo001))
            {
                xtraTabControl1.SelectedTabPage = openedTabPage[bo001];
                if(parm != null)
                {
                    foreach(Control control in openedTabPage[bo001].Controls)
                    {
                        if(control is BusinessObject)
                        {
                            ((BusinessObject)control).cdata["parm"] = parm;
                            ((BusinessObject)control).Business_Init();
                            return;
                        }
                    }
                }
            }
            else //如果尚未打开，则new
            {
                XtraTabPage newPage = new XtraTabPage();
                newPage.Text = businessTab[bo001].bo003;
                newPage.Tag = bo001;


                BusinessObject bo = (BusinessObject)Activator.CreateInstance(Type.GetType("TianYuan_New.Business." + bo001));
                bo.Dock = DockStyle.Fill;
                bo.mainForm = this;
                bo.Parent = newPage;
                bo.cdata.Add("parm",parm);
                
                newPage.Controls.Add(bo);
 
                xtraTabControl1.TabPages.Add(newPage);
                xtraTabControl1.SelectedTabPage = newPage;

                bo.Business_Init();

                ////////登记已打开 Tabpage ////////
                openedTabPage.Add(bo001, newPage);

            }
        }


        /// <summary>
        /// / 进灵登记
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement8_Click(object sender, EventArgs e)
        {
            //权限检查
            if(Tools.GetRight(Envior.cur_userId,"01040") == "0")
            {
                MessageBox.Show("权限不足!","提示",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                return;
            }
            //一套账
            openBusinessObject("FireCheckin_brow","1");  
        }

        /// <summary>
        /// 角色管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement6_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Envior.cur_userId != AppInfo.ROOTID)
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("Roles");
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            ClosePageButtonEventArgs arg = e as ClosePageButtonEventArgs;

            XtraTabPage curPage = (XtraTabPage)arg.Page;
            ///////// 清除页面追踪 ////////
            openedTabPage.Remove(curPage.Tag.ToString());

            curPage.Dispose();
            
            
        }

        /// <summary>
        /// 操作员管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement5_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Envior.cur_userId != AppInfo.ROOTID)
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("Operators");
        }
        
        /// <summary>
        /// 数据项维护
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement15_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05030") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("DataDictionary");
        }

        //商品服务及定价维护
        private void accordionControlElement16_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ServiceGoods","1");
        }

        //寄存室结构维护
        private void accordionControlElement18_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05060") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RegisterStructure");
        }

        //套餐维护
        private void accordionControlElement17_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("Combo","1");
        }


        /// <summary>
        /// 测试 zip 功能
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, ItemClickEventArgs e)
        {
            //string zipfile = "c:\\temp\\temp.zip";
            //string target = "c:\\temp\\zipfile";
            //if (Tools.UnZip(zipfile, target))
            //{
            //    MessageBox.Show("解压缩成功!"); 
            //}
        }

        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 10001:
                    int commandNum = m.WParam.ToInt32();
                    string responseText = PrtServAction.GetResponseText(commandNum);
                    MessageBox.Show(responseText, "提示", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;
                default:
                    base.DefWndProc(ref m);///调用基类函数处理非自定义消息。
                    break;
            }
        }

        /// <summary>
        /// 连接打印服务
        /// </summary>
        private void ConnectPrtServ()
        {
            IntPtr hwnd = FindWindow(null, "prtserv");
            if (hwnd != IntPtr.Zero)
            {
                Envior.printable = true;
                Envior.prtservHandle = hwnd;
                int prtConnId = SqlAssist.ExecuteScalar("select seq_prtserv.nextval from dual", null).ObjToInt();

                ////建立连接
                PrtServAction.Connect(prtConnId, hwnd.ToInt32(), this.Handle.ToInt32());
                Envior.prtConnId = prtConnId;

                ////给打印服务窗口发消息 建立连接
                SendMessage(hwnd, 0x2710, 0, prtConnId);
            }
            else
            {
                Envior.printable = false;
                MessageBox.Show("没有找到打印服务进程,不能打印!","提示",MessageBoxButtons.OK,MessageBoxIcon.Stop);
            }
        }
        /// <summary>
        /// 临时性销售
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement10_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "01090") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("TempSales","1");
        }

        //火化业务办理
        private void accordionControlElement9_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "01050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            FireSearch frm_fireSearch = new FireSearch();
            frm_fireSearch.cdata["mainForm"] = this;
            frm_fireSearch.ShowDialog();
        }

        //寄存办理
        private void accordionControlElement12_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "02010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("Register_brow");
        }

        //寄存室数据
        private void accordionControlElement13_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RegisterData");
        }

        //欠费数据统计
        private void accordionControlElement14_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RegisterDebtReport");
        }

        /// <summary>
        /// 迁出数据查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement25_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03060") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RegOutSearch");
        }

        /// <summary>
        /// 原始登记查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement26_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03070") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RegOriSearch");
        }
        /// <summary>
        /// 出灵数据查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement27_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireOutReport","1");
        }

        /// <summary>
        /// 现存遗体查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement28_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03020") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireHaving","1");
        }

        /// <summary>
        /// 当日火化安排
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement29_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "03030") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireArrange","1");
        }

        /// <summary>
        /// 每日收费明细
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement20_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "04010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FinanceDays","1");
        }

        //服务商品类别统计
        private void accordionControlElement21_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "04040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ClassStat","1");
        }

        //服务商品单项统计
        private void accordionControlElement30_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "04050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ItemStat","1");
        }

        //收款作废查询
        private void accordionControlElement23_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "04060") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FinanceRemoveReport","1");
        }

        /// <summary>
        /// 二套帐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barItem_2nd_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "07001") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (Envior.mainform2 == null)
            {
                Main_2nd frm_2nd = new Main_2nd(businessTab);
                Envior.mainform2 = frm_2nd;  
                frm_2nd.Show();
            }
            else
            {
                Envior.mainform2.TopMost = true;
            }
            
        }

        private void barButtonItem3_ItemClick(object sender, ItemClickEventArgs e)
        {
            Modify_Pwd frm_modify_pwd = new Modify_Pwd();
            frm_modify_pwd.ShowDialog();
        }

        /// <summary>
        /// 系统升级
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05020") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            Upgrade_frm frm_1 = new Upgrade_frm();
            frm_1.ShowDialog();

            //string sql = "insert into test(col1,col3) values('456',:f)";
            //OracleCommand cmd = new OracleCommand(sql, SqlAssist.conn);
            //FileStream fs = File.OpenRead("c:\\temp\\test.wmv");

            //SplashScreenManager.ShowDefaultWaitForm("请等待", "上传中....");
  
            //byte[] b = new byte[fs.Length];
            //fs.Read(b, 0, b.Length);
            //fs.Close();
  
            //cmd.Parameters.Add("f", OracleDbType.Blob,b.Length).Value = b;

            //cmd.ExecuteNonQuery();

            //SplashScreenManager.CloseDefaultWaitForm();
        }

        /// <summary>
        /// 数据恢复
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem5_ItemClick(object sender, ItemClickEventArgs e)
        {
            MessageBox.Show("此功能仅限开发商使用!","提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
            return;

            //SplashScreenManager.ShowDefaultWaitForm("请等待", "上传中....");

            //string sql = "select col3 from test where col1='456'";//从数据库取
            //OracleCommand cmd = new OracleCommand(sql, SqlAssist.conn);
 
            //OracleDataReader dr = cmd.ExecuteReader(CommandBehavior.SequentialAccess);
            //int bufferSize = 10240;

            //if (dr.Read())
            //{
            //    string path = "F:\\temp\\test.wmv";//需要预先在项目文件夹中建立此目录
            //    FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
            //    byte[] buf = new byte[bufferSize];
            //    long bytesRead = 0;
            //    long startIndex = 0;

            //    //LargePhoto的数据比较大，因此分批次读出，分别写入文件
            //    while((bytesRead = dr.GetBytes(0, startIndex, buf, 0, bufferSize)) > 0)
            //   {
            //      fs.Write(buf, 0, (int)bytesRead);
            //      startIndex += bytesRead;
            //    };
            //    fs.Flush();
            //    fs.Close();

            //    SplashScreenManager.CloseDefaultWaitForm();
            //}
        }

        /// <summary>
        /// 数据备份
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem4_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "05010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            saveFileDialog1.Filter = "bin files(*.bin)|*.bin|All files (*.*)|*.*";
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                SplashScreenManager.ShowDefaultWaitForm("正在备份", "请稍候....");
                string fname;
                fname = saveFileDialog1.FileName;
                BackupSet bset = new BackupSet();
                bset.Backup(fname);
                SplashScreenManager.CloseDefaultWaitForm();
                MessageBox.Show("备份成功!","提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
           }
        }

        /// <summary>
        /// 权限分配
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement7_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Envior.cur_userId != AppInfo.ROOTID)
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("RightGrant");
        }

        //重新登录
        private void barButtonItem1_ItemClick_1(object sender, ItemClickEventArgs e)
        {
            ////////  显示登录窗口  //////////
            Login login = new Login();
            if (login.ShowDialog(this) == DialogResult.OK)
            {
                /////////////////////  成功登陆后处理   ///////////////////
                
            }
        }

        /// <summary>
        /// 价格改动查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void accordionControlElement24_Click(object sender, EventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "04070") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
    }
}