﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraBars;
using TianYuan_New.Domain;
using DevExpress.XtraTab;
using TianYuan_New.Business;
using DevExpress.XtraTab.ViewInfo;
using TianYuan_New.Windows;

namespace TianYuan_New
{
    public partial class Main_2nd : DevExpress.XtraEditors.XtraForm
    {
        //追踪已经打开的Tab页
        private Dictionary<string, Bo01> businessTab = null;
        private Dictionary<string, XtraTabPage> openedTabPage = new Dictionary<string, XtraTabPage>();

        public Main_2nd()
        {
            InitializeComponent();
        }
        
        public Main_2nd(object parm)
        {
            businessTab = parm as Dictionary<string, Bo01>;
            InitializeComponent();
        }
         

        /// <summary>
        /// 打开业务对象(如果没有则创建)
        /// </summary>
        public void openBusinessObject(string bo001)
        {
            openBusinessObject(bo001, null);
        }

        /// <summary>
        /// 打开业务对象(如果没有则创建)
        /// </summary>
        public void openBusinessObject(string bo001, object parm)
        {
            if (openedTabPage.ContainsKey(bo001))
            {
                xtraTabControl1.SelectedTabPage = openedTabPage[bo001];
                if (parm != null)
                {
                    foreach (Control control in openedTabPage[bo001].Controls)
                    {
                        if (control is BusinessObject)
                        {
                            ((BusinessObject)control).cdata["parm"] = parm;
                            ((BusinessObject)control).Business_Init();
                            return;
                        }
                    }
                }
            }
            else //如果尚未打开，则new
            {
                XtraTabPage newPage = new XtraTabPage();
                newPage.Text = businessTab[bo001].bo003;
                newPage.Tag = bo001;


                BusinessObject bo = (BusinessObject)Activator.CreateInstance(Type.GetType("TianYuan_New.Business." + bo001));
                bo.Dock = DockStyle.Fill;
                bo.mainForm = this;
                bo.Parent = newPage;
                bo.cdata.Add("parm", parm);
                
                newPage.Controls.Add(bo);

                xtraTabControl1.TabPages.Add(newPage);
                xtraTabControl1.SelectedTabPage = newPage;

                bo.Business_Init();

                ////////登记已打开 Tabpage ////////
                openedTabPage.Add(bo001, newPage);

            }
        }


        /// <summary>
        /// 服务及商品定价维护
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem6_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "10040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ServiceGoods", "2");
        }

        /// <summary>
        /// 商品服务套餐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem7_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "10050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("Combo", "2");
        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            ClosePageButtonEventArgs arg = e as ClosePageButtonEventArgs;
            XtraTabPage curPage = (XtraTabPage)arg.Page;
            ///////// 清除页面追踪 ////////
            openedTabPage.Remove(curPage.Tag.ToString());
            curPage.Dispose();
        }

        /// <summary>
        /// 进灵登记
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem2_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "07040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            //二套账
            openBusinessObject("FireCheckin_brow", "2");
        }

        /// <summary>
        /// 临时性销售
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem3_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "07090") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("TempSales", "2");
        }

        private void barButtonItem4_ItemClick(object sender, ItemClickEventArgs e)
        {
            //二套账
            openBusinessObject("FireCheckin_brow", "2");
        }

        /// <summary>
        /// 火化业务办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem5_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "07050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            FireSearch frm_fireSearch = new FireSearch();
            frm_fireSearch.cdata["mainForm"] = this;
            frm_fireSearch.ShowDialog();
        }

        /// <summary>
        /// 出灵数据查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem8_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "08010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireOutReport", "2");
        }

        /// <summary>
        /// 现存遗体查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem9_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "08020") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireHaving", "2");
        }

        /// <summary>
        /// 当日火化安排
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem10_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "08030") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FireArrange", "2");
        }

        //每日收费明细
        private void barButtonItem11_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "09010") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FinanceDays","2");
        }

        /// <summary>
        /// 类别统计
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem12_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "09040") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ClassStat", "2");
        }

        /// <summary>
        /// 单项统计
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem13_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "09050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ItemStat", "2");
        }

        /// <summary>
        /// 火化业务
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void barButtonItem17_ItemClick(object sender, ItemClickEventArgs e)
        {
            FireSearch frm_fireSearch = new FireSearch();
            frm_fireSearch.cdata["mainForm"] = this;
            frm_fireSearch.ShowDialog();
        }

        private void barButtonItem18_ItemClick(object sender, ItemClickEventArgs e)
        {
            openBusinessObject("TempSales", "2");
        }

        private void barButtonItem19_ItemClick(object sender, ItemClickEventArgs e)
        {
            openBusinessObject("FinanceDays", "2");
        }

        //作废统计
        private void barButtonItem14_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "09060") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("FinanceRemoveReport", "2");
        }

        private void barButtonItem15_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void barButtonItem21_ItemClick(object sender, ItemClickEventArgs e)
        {
            //权限检查
            if (Tools.GetRight(Envior.cur_userId, "09050") == "0")
            {
                MessageBox.Show("权限不足!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            openBusinessObject("ItemStat", "2");
        }
    }
}