﻿namespace TianYuan_New
{


    partial class Myds
    {
        partial class RG01DataTable
        {
        }

        partial class ST01DataTable
        {
        }
    }
}
