﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class ClassStatForm : MyDialog
    {
        private DataTable dt_cast = new DataTable();
        private OracleDataAdapter castAdapter =
            new OracleDataAdapter("select * from castinfo",SqlAssist.conn);

        private BusinessObject bo = null;
        private string accountId = string.Empty;

        public ClassStatForm()
        {
            InitializeComponent();
        }

        private void ClassStatForm_Load(object sender, EventArgs e)
        {
            checkedListBoxControl1.DataSource = dt_cast;
            checkedListBoxControl1.ValueMember = "SERVICESALESTYPE";
            checkedListBoxControl1.DisplayMember = "TYPEDESC";
            castAdapter.Fill(dt_cast);

            bo = this.cdata["BusinessObject"] as BusinessObject;
            accountId = this.cdata["accountId"].ToString();

            dateEdit2.EditValue = DateTime.Today;
            dateEdit1.EditValue = DateTime.Today.AddMonths(-1);

            if (accountId == "1")
            {
                if(Tools.GetRight(Envior.cur_userId,"03080") == "0")
                {
                    dateEdit1.EditValue = DateTime.Today;
                    dateEdit1.Enabled = false;
                    dateEdit2.Enabled = false;
                }
            }
            else
            {
                if (Tools.GetRight(Envior.cur_userId, "09080") == "0")
                {
                    dateEdit1.EditValue = DateTime.Today;
                    dateEdit1.Enabled = false;
                    dateEdit2.Enabled = false;
                }
            }
            

            checkedListBoxControl1.CheckAll();

        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b_ok_Click(object sender, EventArgs e)
        {
            bo.cdata["dbegin"] = dateEdit1.EditValue;
            bo.cdata["dend"] = dateEdit2.EditValue;
            List<string> classList = new List<string>();


            foreach (DataRowView item in checkedListBoxControl1.CheckedItems)
            {
                classList.Add(item["SERVICESALESTYPE"].ToString());
            }

            if(classList.Count <= 0)
            {
                MessageBox.Show("请至少选择一个类别!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            bo.cdata["class"] = classList.ToArray();

            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}