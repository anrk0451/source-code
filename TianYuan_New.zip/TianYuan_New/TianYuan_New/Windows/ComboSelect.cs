﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    public partial class ComboSelect : MyDialog
    {
        private string AC001;
        private FireBusiness01 bo;
        private DataTable cb01 = new DataTable();
        private OracleDataAdapter cb01Adapter = new OracleDataAdapter("select * from cb01 where cb002 = '1' and status = '1' and cb077 = :cb077", SqlAssist.conn);
        public ComboSelect()
        {
            InitializeComponent();
        }

        private void ComboSelect_Load(object sender, EventArgs e)
        {
            bo = this.cdata["businessObject"] as FireBusiness01;
            AC001 = this.cdata["AC001"].ToString();

            OracleParameter op_cb077 = new OracleParameter("cb077", OracleDbType.Varchar2, 3);
            op_cb077.Direction = ParameterDirection.Input;
            op_cb077.Value = FireAction.GetAccountIdByAc001(AC001);
            cb01Adapter.SelectCommand.Parameters.Add(op_cb077);
 
            cb01Adapter.Fill(cb01);
            ck.checklist.DataSource = cb01;
            ck.checklist.ValueMember = "CB001";
            ck.checklist.DisplayMember = "CB003";

        }

        private void sb_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void sb_ok_Click(object sender, EventArgs e)
        {
            if(ck.checklist.CheckedItemsCount == 0)
            {
                MessageBox.Show("请先选择项目!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            string cb001 = ck.checklist.SelectedValue.ToString();
            int result = FireAction.ApplyUserCombo(AC001,
                                                   cb001,
                                                   Envior.cur_userId
            );
            if (result > 0)
            {
                DialogResult = DialogResult.OK;
                this.Dispose();
            }
        }
    }
}