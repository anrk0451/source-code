﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class FinanceDaysForm : MyDialog
    {
        private FinanceDays bo = null;
        private string accountId = string.Empty;

        public FinanceDaysForm()
        {
            InitializeComponent();
        }

        private void FinanceDaysForm_Load(object sender, EventArgs e)
        {
            bo = this.cdata["BusinessObject"] as FinanceDays;
            accountId = this.cdata["accountId"].ToString();

            dateEdit2.EditValue = DateTime.Today;
            dateEdit1.EditValue = DateTime.Today;

            if(accountId == "1")
            {
                if (Tools.GetRight(Envior.cur_userId, "03080") == "0")
                {
                    dateEdit1.Enabled = false;
                    dateEdit2.Enabled = false;
                }
            }
            else
            {
                if (Tools.GetRight(Envior.cur_userId, "09080") == "0")
                {
                    dateEdit1.Enabled = false;
                    dateEdit2.Enabled = false;
                }
            }
        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            bo.cdata["dbegin"] = dateEdit1.EditValue;
            bo.cdata["dend"] = dateEdit2.EditValue;
            bo.cdata["FA003"] = textEdit1.EditValue;

            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}