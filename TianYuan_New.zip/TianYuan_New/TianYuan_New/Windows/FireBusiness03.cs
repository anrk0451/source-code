﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    /// <summary>
    /// 休息室
    /// </summary>
    public partial class FireBusiness03 : MyDialog
    {
        DataView dv_xxs;
        FireBusiness bo;
        string AC001 = string.Empty;
        string accountId = string.Empty;

        public FireBusiness03()
        {
            InitializeComponent();
        }

        private void FireBusiness03_Load(object sender, EventArgs e)
        {
            bo = this.cdata["businessObject"] as FireBusiness;
            AC001 = this.cdata["AC001"].ToString();
            accountId = FireAction.GetAccountIdByAc001(AC001);

            dv_xxs = new DataView(bo.Si01);
            dv_xxs.RowFilter = "item_type='03' and accountId='" + accountId + "'" ;
            gridControl1.DataSource = dv_xxs;

        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            int[] handle_arry = gridView1.GetSelectedRows();
            if(handle_arry.Length == 0)
            {
                MessageBox.Show("请先选择项目", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<string> itemIdList = new List<string>();
            foreach(int r in handle_arry)
            {
                itemIdList.Add(gridView1.GetRowCellValue(r,"ITEM_ID").ToString());
            }

            bo.cdata["xxs"] = itemIdList;
            DialogResult = DialogResult.OK;
            this.Dispose();
        }
    }
}