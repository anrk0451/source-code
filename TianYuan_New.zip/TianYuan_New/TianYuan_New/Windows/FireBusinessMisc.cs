﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;
using DevExpress.XtraGrid.Views.Base;

namespace TianYuan_New.Windows
{
    public partial class FireBusinessMisc : MyDialog
    {
        BusinessObject bo;
        string accountId = string.Empty;

        public FireBusinessMisc()
        {
            InitializeComponent();
        }

        private void FireBusinessMisc_Load(object sender, EventArgs e)
        {
            if(this.cdata["businessObject"] is FireBusiness)
                bo = this.cdata["businessObject"] as FireBusiness;
            else if(this.cdata["businessObject"] is TempSales)
                bo = this.cdata["businessObject"] as TempSales;

            accountId = this.cdata["accountId"].ToString();

            if(bo is FireBusiness)
            {
                gridControl1.DataSource = (bo as FireBusiness).Si01;
                gridControl2.DataSource = (bo as FireBusiness).Si01;
                gridControl3.DataSource = (bo as FireBusiness).Si01;
                gridControl4.DataSource = (bo as FireBusiness).Si01;
            }else if(bo is TempSales)
            {
                gridControl1.DataSource = (bo as TempSales).Si01;
                gridControl2.DataSource = (bo as TempSales).Si01;
                gridControl3.DataSource = (bo as TempSales).Si01;
                gridControl4.DataSource = (bo as TempSales).Si01;
            }
 
            gridView1.ActiveFilterString = "item_type = '05' and accountId = '" + accountId + "'";
            gridView2.ActiveFilterString = "item_type = '10' and accountId = '" + accountId + "'";
            gridView3.ActiveFilterString = "item_type = '11' and accountId = '" + accountId + "'";
            gridView4.ActiveFilterString = "item_type = '12' and accountId = '" + accountId + "'" ;
        }

        

        private void sb_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }
        /// <summary>
        /// 非绑定列-数量赋初始值
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomUnboundColumnData(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDataEventArgs e)
        {
            if(e.Column.FieldName == "NUMS" && e.IsGetData)
            {
                e.Value = 1;
            }
        }

        /// <summary>
        /// 选择并返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>     
        private void sb_ok_Click_1(object sender, EventArgs e)
        {
            List<string> itemId_list = new List<string>();
            List<string> itemType_list = new List<string>();
            List<decimal> price_list = new List<decimal>();
            List<int> nums_list = new List<int>();

            if (!gridView1.PostEditor()) return;
            if (!gridView1.UpdateCurrentRow()) return;
            if (!gridView4.PostEditor()) return;
            if (!gridView4.UpdateCurrentRow()) return;


            Int32[] selectedRowHandles = gridView1.GetSelectedRows();
            for (int i = 0; i < selectedRowHandles.Length; i++)
            {
                int selectedRowHandle = selectedRowHandles[i];
                if (selectedRowHandle >= 0)
                {
                    itemId_list.Add(gridView1.GetRowCellValue(selectedRowHandle, "ITEM_ID").ToString());
                    itemType_list.Add(gridView1.GetRowCellValue(selectedRowHandle, "ITEM_TYPE").ToString());
                    price_list.Add(decimal.Parse(gridView1.GetRowCellValue(selectedRowHandle, "PRICE").ToString()));
                    nums_list.Add(int.Parse(gridView1.GetRowCellValue(selectedRowHandle, "NUMS").ToString()));
                }
            }

            selectedRowHandles = gridView2.GetSelectedRows();
            for (int i = 0; i < selectedRowHandles.Length; i++)
            {
                int selectedRowHandle = selectedRowHandles[i];
                if (selectedRowHandle >= 0)
                {
                    itemId_list.Add(gridView2.GetRowCellValue(selectedRowHandle, "ITEM_ID").ToString());
                    itemType_list.Add(gridView2.GetRowCellValue(selectedRowHandle, "ITEM_TYPE").ToString());
                    price_list.Add(decimal.Parse(gridView2.GetRowCellValue(selectedRowHandle, "PRICE").ToString()));
                    nums_list.Add(int.Parse(gridView2.GetRowCellValue(selectedRowHandle, "NUMS").ToString()));
                }
            }

            selectedRowHandles = gridView3.GetSelectedRows();
            for (int i = 0; i < selectedRowHandles.Length; i++)
            {
                int selectedRowHandle = selectedRowHandles[i];
                if (selectedRowHandle >= 0)
                {
                    itemId_list.Add(gridView3.GetRowCellValue(selectedRowHandle, "ITEM_ID").ToString());
                    itemType_list.Add(gridView3.GetRowCellValue(selectedRowHandle, "ITEM_TYPE").ToString());
                    price_list.Add(decimal.Parse(gridView3.GetRowCellValue(selectedRowHandle, "PRICE").ToString()));
                    nums_list.Add(int.Parse(gridView3.GetRowCellValue(selectedRowHandle, "NUMS").ToString()));
                }
            }

            selectedRowHandles = gridView4.GetSelectedRows();
            for (int i = 0; i < selectedRowHandles.Length; i++)
            {
                int selectedRowHandle = selectedRowHandles[i];
                if (selectedRowHandle >= 0)
                {
                    itemId_list.Add(gridView4.GetRowCellValue(selectedRowHandle, "ITEM_ID").ToString());
                    itemType_list.Add(gridView4.GetRowCellValue(selectedRowHandle, "ITEM_TYPE").ToString());
                    price_list.Add(decimal.Parse(gridView4.GetRowCellValue(selectedRowHandle, "PRICE").ToString()));
                    nums_list.Add(int.Parse(gridView4.GetRowCellValue(selectedRowHandle, "NUMS").ToString()));
                }
            }
            if (itemId_list.Count == 0)
            {
                MessageBox.Show("请选择记录!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bo.cdata["itemIdList"] = itemId_list;
            bo.cdata["priceList"] = price_list;
            bo.cdata["numsList"] = nums_list;
            bo.cdata["itemTypeList"] = itemType_list;

            DialogResult = DialogResult.OK;
            this.Dispose();
        }

        private void gridView1_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            string colName = (sender as ColumnView).FocusedColumn.FieldName.ToUpper();
            if(colName == "NUMS")
            {
                if(e.Value == null || e.Value is System.DBNull)
                {
                    e.Valid = false;
                    e.ErrorText = "请输入数量!";
                    return;
                }else if(int.Parse(e.Value.ToString()) <=0)
                {
                    e.Valid = false;
                    e.ErrorText = "数量必须大于0！";
                    return;
                }
            }
        }

        private void gridView4_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            string colName = (sender as ColumnView).FocusedColumn.FieldName.ToUpper();
            if (colName == "NUMS")
            {
                if (e.Value == null || e.Value is System.DBNull)
                {
                    e.Valid = false;
                    e.ErrorText = "请输入数量!";
                    return;
                }
                else if (int.Parse(e.Value.ToString()) <= 0)
                {
                    e.Valid = false;
                    e.ErrorText = "数量必须大于0！";
                    return;
                }
            }
        }

      

        private void gridView2_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        {
            if(e.Action == CollectionChangeAction.Add && gridView2.SelectedRowsCount > 1)
            {
                int row = e.ControllerRow;
                gridView2.BeginUpdate();
                gridView2.ClearSelection();
                gridView2.SelectRow(row);
                gridView2.EndUpdate();
            }
        }
 

        private void gridView3_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        {
            if (e.Action == CollectionChangeAction.Add && gridView3.SelectedRowsCount > 1)
            {
                int row = e.ControllerRow;
                gridView3.BeginUpdate();
                gridView3.ClearSelection();
                gridView3.SelectRow(row);
                gridView3.EndUpdate();
            }
        }
    }
}