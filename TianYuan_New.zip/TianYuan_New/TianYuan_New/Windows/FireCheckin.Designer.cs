﻿namespace TianYuan_New.Windows
{
    partial class FireCheckin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac003 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.rg_ac002 = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac004 = new DevExpress.XtraEditors.TextEdit();
            this.txtedit_ac014 = new DevExpress.XtraEditors.TextEdit();
            this.txtEdit_ac009 = new DevExpress.XtraEditors.TextEdit();
            this.dateEdit_ac010 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.lookUp_ac005 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUp_ac007 = new DevExpress.XtraEditors.LookUpEdit();
            this.txtEdit_ac008 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac050 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.lookUp_ac052 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac051 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac055 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.lookUp_ac060 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.mem_ac099 = new DevExpress.XtraEditors.MemoEdit();
            this.b_exit = new DevExpress.XtraEditors.SimpleButton();
            this.b_ok = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.dateEdit_ac020 = new DevExpress.XtraEditors.DateEdit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac003.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_ac002.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac004.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_ac014.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac009.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac010.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac010.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac005.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac007.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac008.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac050.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac052.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac051.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac055.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac060.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_ac099.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac020.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac020.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(33, 50);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(68, 18);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "逝者姓名*";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(33, 92);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(60, 18);
            this.labelControl4.TabIndex = 6;
            this.labelControl4.Text = "身份证号";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(33, 133);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(60, 18);
            this.labelControl5.TabIndex = 7;
            this.labelControl5.Text = "接灵地点";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(33, 175);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(60, 18);
            this.labelControl6.TabIndex = 9;
            this.labelControl6.Text = "死亡时间";
            // 
            // labelControl8
            // 
            this.labelControl8.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl8.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl8.LineVisible = true;
            this.labelControl8.Location = new System.Drawing.Point(33, 218);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(38, 18);
            this.labelControl8.TabIndex = 13;
            this.labelControl8.Text = "户籍*";
            // 
            // txtEdit_ac003
            // 
            this.txtEdit_ac003.Location = new System.Drawing.Point(120, 46);
            this.txtEdit_ac003.Name = "txtEdit_ac003";
            this.txtEdit_ac003.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_ac003.TabIndex = 14;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(277, 50);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(38, 18);
            this.labelControl2.TabIndex = 15;
            this.labelControl2.Text = "性别*";
            // 
            // rg_ac002
            // 
            this.rg_ac002.EditValue = "0";
            this.rg_ac002.Location = new System.Drawing.Point(333, 46);
            this.rg_ac002.Name = "rg_ac002";
            this.rg_ac002.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rg_ac002.Properties.Appearance.Options.UseBackColor = true;
            this.rg_ac002.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rg_ac002.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("0", "男"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("1", "女"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("2", "未知")});
            this.rg_ac002.Size = new System.Drawing.Size(165, 24);
            this.rg_ac002.TabIndex = 16;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(530, 50);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(38, 18);
            this.labelControl3.TabIndex = 17;
            this.labelControl3.Text = "年龄*";
            // 
            // txtEdit_ac004
            // 
            this.txtEdit_ac004.Location = new System.Drawing.Point(580, 46);
            this.txtEdit_ac004.Name = "txtEdit_ac004";
            this.txtEdit_ac004.Properties.Mask.BeepOnError = true;
            this.txtEdit_ac004.Properties.Mask.EditMask = "n0";
            this.txtEdit_ac004.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_ac004.Size = new System.Drawing.Size(85, 24);
            this.txtEdit_ac004.TabIndex = 18;
            this.txtEdit_ac004.Validating += new System.ComponentModel.CancelEventHandler(this.textEdit2_Validating);
            // 
            // txtedit_ac014
            // 
            this.txtedit_ac014.Location = new System.Drawing.Point(120, 89);
            this.txtedit_ac014.Name = "txtedit_ac014";
            this.txtedit_ac014.Size = new System.Drawing.Size(545, 24);
            this.txtedit_ac014.TabIndex = 19;
            this.txtedit_ac014.Validating += new System.ComponentModel.CancelEventHandler(this.txtedit_ac014_Validating);
            // 
            // txtEdit_ac009
            // 
            this.txtEdit_ac009.Location = new System.Drawing.Point(120, 130);
            this.txtEdit_ac009.Name = "txtEdit_ac009";
            this.txtEdit_ac009.Size = new System.Drawing.Size(545, 24);
            this.txtEdit_ac009.TabIndex = 20;
            // 
            // dateEdit_ac010
            // 
            this.dateEdit_ac010.EditValue = null;
            this.dateEdit_ac010.Location = new System.Drawing.Point(120, 172);
            this.dateEdit_ac010.Name = "dateEdit_ac010";
            this.dateEdit_ac010.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit_ac010.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit_ac010.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit_ac010.Size = new System.Drawing.Size(122, 24);
            this.dateEdit_ac010.TabIndex = 21;
            this.dateEdit_ac010.Validating += new System.ComponentModel.CancelEventHandler(this.dateEdit_ac010_Validating);
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(277, 175);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(68, 18);
            this.labelControl7.TabIndex = 22;
            this.labelControl7.Text = "死亡原因*";
            // 
            // lookUp_ac005
            // 
            this.lookUp_ac005.Location = new System.Drawing.Point(358, 172);
            this.lookUp_ac005.Name = "lookUp_ac005";
            this.lookUp_ac005.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUp_ac005.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST001", "编号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST003", "值"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SORTID", "排序号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.Ascending, DevExpress.Utils.DefaultBoolean.Default)});
            this.lookUp_ac005.Properties.LookAndFeel.SkinName = "DevExpress Dark Style";
            this.lookUp_ac005.Properties.NullText = "";
            this.lookUp_ac005.Properties.ShowHeader = false;
            this.lookUp_ac005.Size = new System.Drawing.Size(114, 24);
            this.lookUp_ac005.TabIndex = 23;
            this.lookUp_ac005.EditValueChanged += new System.EventHandler(this.lookUp_ac005_EditValueChanged);
            // 
            // lookUp_ac007
            // 
            this.lookUp_ac007.Location = new System.Drawing.Point(120, 214);
            this.lookUp_ac007.Name = "lookUp_ac007";
            this.lookUp_ac007.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUp_ac007.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST001", "编号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST003", "值"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SORTID", "排序号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default)});
            this.lookUp_ac007.Properties.NullText = "";
            this.lookUp_ac007.Properties.ShowHeader = false;
            this.lookUp_ac007.Size = new System.Drawing.Size(122, 24);
            this.lookUp_ac007.TabIndex = 25;
            this.lookUp_ac007.EditValueChanged += new System.EventHandler(this.lookUp_ac007_EditValueChanged);
            // 
            // txtEdit_ac008
            // 
            this.txtEdit_ac008.Location = new System.Drawing.Point(247, 213);
            this.txtEdit_ac008.Name = "txtEdit_ac008";
            this.txtEdit_ac008.Size = new System.Drawing.Size(417, 24);
            this.txtEdit_ac008.TabIndex = 26;
            // 
            // labelControl9
            // 
            this.labelControl9.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl9.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl9.LineVisible = true;
            this.labelControl9.Location = new System.Drawing.Point(33, 262);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(53, 18);
            this.labelControl9.TabIndex = 26;
            this.labelControl9.Text = "联系人*";
            // 
            // txtEdit_ac050
            // 
            this.txtEdit_ac050.Location = new System.Drawing.Point(120, 259);
            this.txtEdit_ac050.Name = "txtEdit_ac050";
            this.txtEdit_ac050.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_ac050.TabIndex = 27;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(262, 262);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(75, 18);
            this.labelControl10.TabIndex = 28;
            this.labelControl10.Text = "与逝者关系";
            // 
            // lookUp_ac052
            // 
            this.lookUp_ac052.Location = new System.Drawing.Point(358, 259);
            this.lookUp_ac052.Name = "lookUp_ac052";
            this.lookUp_ac052.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUp_ac052.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST001", "编号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST003", "值"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SORTID", "排序号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.Ascending, DevExpress.Utils.DefaultBoolean.Default)});
            this.lookUp_ac052.Properties.NullText = "";
            this.lookUp_ac052.Properties.ShowHeader = false;
            this.lookUp_ac052.Size = new System.Drawing.Size(114, 24);
            this.lookUp_ac052.TabIndex = 29;
            this.lookUp_ac052.EditValueChanged += new System.EventHandler(this.lookUp_ac052_EditValueChanged);
            // 
            // labelControl11
            // 
            this.labelControl11.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl11.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl11.LineVisible = true;
            this.labelControl11.Location = new System.Drawing.Point(33, 303);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(68, 18);
            this.labelControl11.TabIndex = 30;
            this.labelControl11.Text = "联系电话*";
            // 
            // txtEdit_ac051
            // 
            this.txtEdit_ac051.Location = new System.Drawing.Point(120, 299);
            this.txtEdit_ac051.Name = "txtEdit_ac051";
            this.txtEdit_ac051.Size = new System.Drawing.Size(545, 24);
            this.txtEdit_ac051.TabIndex = 31;
            // 
            // labelControl12
            // 
            this.labelControl12.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl12.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl12.LineVisible = true;
            this.labelControl12.Location = new System.Drawing.Point(33, 345);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(60, 18);
            this.labelControl12.TabIndex = 32;
            this.labelControl12.Text = "联系地址";
            // 
            // txtEdit_ac055
            // 
            this.txtEdit_ac055.Location = new System.Drawing.Point(120, 339);
            this.txtEdit_ac055.Name = "txtEdit_ac055";
            this.txtEdit_ac055.Size = new System.Drawing.Size(545, 24);
            this.txtEdit_ac055.TabIndex = 33;
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(515, 175);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(30, 18);
            this.labelControl13.TabIndex = 34;
            this.labelControl13.Text = "司机";
            // 
            // lookUp_ac060
            // 
            this.lookUp_ac060.Location = new System.Drawing.Point(555, 172);
            this.lookUp_ac060.Name = "lookUp_ac060";
            this.lookUp_ac060.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUp_ac060.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST001", "编号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST003", "值"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SORTID", "排序号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.Ascending, DevExpress.Utils.DefaultBoolean.Default)});
            this.lookUp_ac060.Properties.NullText = "";
            this.lookUp_ac060.Properties.ShowHeader = false;
            this.lookUp_ac060.Size = new System.Drawing.Size(110, 24);
            this.lookUp_ac060.TabIndex = 24;
            this.lookUp_ac060.EditValueChanged += new System.EventHandler(this.lookUp_ac060_EditValueChanged);
            // 
            // labelControl14
            // 
            this.labelControl14.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl14.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl14.LineVisible = true;
            this.labelControl14.Location = new System.Drawing.Point(33, 388);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(30, 18);
            this.labelControl14.TabIndex = 36;
            this.labelControl14.Text = "备注";
            // 
            // mem_ac099
            // 
            this.mem_ac099.Location = new System.Drawing.Point(120, 386);
            this.mem_ac099.Name = "mem_ac099";
            this.mem_ac099.Size = new System.Drawing.Size(545, 96);
            this.mem_ac099.TabIndex = 37;
            // 
            // b_exit
            // 
            this.b_exit.Appearance.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b_exit.Appearance.ForeColor = System.Drawing.Color.SlateGray;
            this.b_exit.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_exit.Appearance.Options.UseBackColor = true;
            this.b_exit.Appearance.Options.UseForeColor = true;
            this.b_exit.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.b_exit.Location = new System.Drawing.Point(602, 503);
            this.b_exit.Name = "b_exit";
            this.b_exit.Size = new System.Drawing.Size(63, 31);
            this.b_exit.TabIndex = 40;
            this.b_exit.Text = "退出";
            // 
            // b_ok
            // 
            this.b_ok.Appearance.BackColor = System.Drawing.Color.Lime;
            this.b_ok.Appearance.ForeColor = System.Drawing.Color.White;
            this.b_ok.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_ok.Appearance.Options.UseBackColor = true;
            this.b_ok.Appearance.Options.UseForeColor = true;
            this.b_ok.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_ok.Location = new System.Drawing.Point(426, 503);
            this.b_ok.Name = "b_ok";
            this.b_ok.Size = new System.Drawing.Size(170, 31);
            this.b_ok.TabIndex = 39;
            this.b_ok.Text = "确定";
            this.b_ok.Click += new System.EventHandler(this.b_ok_Click);
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(485, 262);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(60, 18);
            this.labelControl15.TabIndex = 40;
            this.labelControl15.Text = "到达时间";
            // 
            // dateEdit_ac020
            // 
            this.dateEdit_ac020.EditValue = null;
            this.dateEdit_ac020.Location = new System.Drawing.Point(555, 259);
            this.dateEdit_ac020.Name = "dateEdit_ac020";
            this.dateEdit_ac020.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit_ac020.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit_ac020.Size = new System.Drawing.Size(110, 24);
            this.dateEdit_ac020.TabIndex = 30;
            this.dateEdit_ac020.Validating += new System.ComponentModel.CancelEventHandler(this.dateedit_ac020_Validating);
            // 
            // FireCheckin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.b_exit;
            this.ClientSize = new System.Drawing.Size(698, 553);
            this.Controls.Add(this.dateEdit_ac020);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.b_exit);
            this.Controls.Add(this.b_ok);
            this.Controls.Add(this.mem_ac099);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.lookUp_ac060);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.txtEdit_ac055);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.txtEdit_ac051);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.lookUp_ac052);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.txtEdit_ac050);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.txtEdit_ac008);
            this.Controls.Add(this.lookUp_ac007);
            this.Controls.Add(this.lookUp_ac005);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.dateEdit_ac010);
            this.Controls.Add(this.txtEdit_ac009);
            this.Controls.Add(this.txtedit_ac014);
            this.Controls.Add(this.txtEdit_ac004);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.rg_ac002);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtEdit_ac003);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl1);
            this.LookAndFeel.SkinName = "DevExpress Dark Style";
            this.Name = "FireCheckin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "进灵登记";
            this.Load += new System.EventHandler(this.FireCheckin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac003.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_ac002.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac004.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_ac014.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac009.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac010.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac010.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac005.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac007.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac008.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac050.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac052.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac051.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac055.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_ac060.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_ac099.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac020.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit_ac020.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac003;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.RadioGroup rg_ac002;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac004;
        private DevExpress.XtraEditors.TextEdit txtedit_ac014;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac009;
        private DevExpress.XtraEditors.DateEdit dateEdit_ac010;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LookUpEdit lookUp_ac005;
        private DevExpress.XtraEditors.LookUpEdit lookUp_ac007;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac008;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac050;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LookUpEdit lookUp_ac052;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac051;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac055;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LookUpEdit lookUp_ac060;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.MemoEdit mem_ac099;
        private DevExpress.XtraEditors.SimpleButton b_exit;
        private DevExpress.XtraEditors.SimpleButton b_ok;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.DateEdit dateEdit_ac020;
    }
}