﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.DataSet;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using TianYuan_New.Domain;
using OracleSugar;
using TianYuan_New.Dao;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class FireCheckin : MyDialog
    {
        private CheckinSet checkinSet;
        private DataView ac005_source;   //死亡原因 数据源
        private DataView ac052_source;   //与逝者关系
        private DataView ac060_source;   //灵车司机
        private DataView ac007_source;   //户籍(区县)
        private BusinessObject parentObject;
        private string ac077;            //账套标识 

        public FireCheckin()
        {
            InitializeComponent();
        }
 
        /// <summary>
        /// 窗体 Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FireCheckin_Load(object sender, EventArgs e)
        {
            checkinSet = this.cdata["dataset"] as CheckinSet;
            parentObject = this.cdata["parent"] as BusinessObject;
            ac077 = this.cdata["AC077"].ToString();
           
            ///// 装入字典数据 ///////////////////////////////////////////////////////////////
            //checkinSet.st01Adapter.Fill(checkinSet.St01);

            ac005_source = new DataView(checkinSet.St01);
            ac005_source.RowFilter = "ST002='DIEREASON' or ST002='%'";
            lookUp_ac005.Properties.DataSource = ac005_source;
            lookUp_ac005.Properties.ValueMember = "ST001";
            lookUp_ac005.Properties.DisplayMember = "ST003";
            ac005_source.Sort = "SORTID ASC";


            //DataRowView newrow = ac005_source.AddNew();
            //newrow["ST001"] = AppInfo.NewStItemId;
            //newrow["ST003"] = "......";
            //newrow["ST002"] = "%";
            //newrow["SORTID"] = 99999;
            //newrow.EndEdit();


            ac052_source = new DataView(checkinSet.St01);
            ac052_source.RowFilter = "ST002='RELATION' or ST002='%'";
            lookUp_ac052.Properties.DataSource = ac052_source;
            lookUp_ac052.Properties.ValueMember = "ST001";
            lookUp_ac052.Properties.DisplayMember = "ST003";
            ac052_source.Sort = "SORTID ASC";

            ac060_source = new DataView(checkinSet.St01);
            ac060_source.RowFilter = "ST002='DRIVER' or ST002='%'";
            lookUp_ac060.Properties.DataSource = ac060_source;
            lookUp_ac060.Properties.ValueMember = "ST001";
            lookUp_ac060.Properties.DisplayMember = "ST003";
            ac060_source.Sort = "SORTID ASC";

            ac007_source = new DataView(checkinSet.St01);
            ac007_source.RowFilter = "ST002='DISTRICT'";
            lookUp_ac007.Properties.DataSource = ac007_source;
            lookUp_ac007.Properties.ValueMember = "ST001";
            lookUp_ac007.Properties.DisplayMember = "ST003";
            ac007_source.Sort = "SORTID ASC";
            //////////////////////////////////////////////////////////////////////////////////
            /// 如果是编辑模式 装入数据
            if(this.cdata["action"].ToString() == "edit")
            {
                this.Text = "登记信息修改";
                DataRow row = this.cdata["rowdata"] as DataRow;
                txtEdit_ac003.EditValue = row["AC003"];
                rg_ac002.EditValue = row["AC002"];
                txtEdit_ac004.EditValue = row["AC004"];
                txtedit_ac014.EditValue = row["AC014"];
                txtEdit_ac009.EditValue = row["AC009"];
                dateEdit_ac010.EditValue = row["AC010"];
                lookUp_ac005.EditValue = row["AC005"];
                lookUp_ac060.EditValue = row["AC060"];
                lookUp_ac007.EditValue = row["AC007"];
                txtEdit_ac008.EditValue = row["AC008"];
                txtEdit_ac050.EditValue = row["AC050"];
                lookUp_ac052.EditValue = row["AC052"];
                dateEdit_ac020.EditValue = row["AC020"];
                txtEdit_ac051.EditValue = row["AC051"];
                txtEdit_ac055.EditValue = row["AC055"];
                mem_ac099.EditValue = row["AC099"];
                dateEdit_ac020.Enabled = false;
            }
            else
            {
                dateEdit_ac020.EditValue = System.DateTime.Now;
            }

            
        }
        /// <summary>
        /// 所属区县 自定义
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lookUp_ac007_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac007.EditValue == null || lookUp_ac007.EditValue is System.DBNull) return;

            if (lookUp_ac007.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if (newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("DISTRICT", this.cdata["newitem"].ToString());
                    lookUp_ac007.EditValue = newDictId;
                }
                else
                {
                    lookUp_ac007.EditValue = System.DBNull.Value;
                }
            }
        }

        /// <summary>
        /// 选择自定义字典值 死亡原因
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lookUp_ac005_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac005.EditValue == null || lookUp_ac005.EditValue is System.DBNull) return;
            if (lookUp_ac005.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if(newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("DIEREASON", this.cdata["newitem"].ToString());
                    lookUp_ac005.EditValue = newDictId;
                }
                else
                {
                    lookUp_ac005.EditValue = System.DBNull.Value;
                }
            }
        }

        /// <summary>
        /// 选择自定义字典值 与逝者关系
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lookUp_ac052_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac052.EditValue == null || lookUp_ac052.EditValue is System.DBNull) return;
            if (lookUp_ac052.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if (newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("RELATION", this.cdata["newitem"].ToString());
                    lookUp_ac052.EditValue = newDictId;
                }
                else
                {
                    lookUp_ac052.EditValue = System.DBNull.Value; 
                }
            }
        }

        /// <summary>
        /// 灵车司机
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lookUp_ac060_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac060.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if (newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("DRIVER", this.cdata["newitem"].ToString());
                    lookUp_ac060.EditValue = newDictId;
                }
                else
                {
                    lookUp_ac060.EditValue = System.DBNull.Value;
                }
            }
        }

        /// <summary>
        /// 生成新的数据字典值
        /// </summary>
        /// <param name="dictType"></param>
        /// <param name="dictValue"></param>
        /// 返回值: 新字典Id
        private string GenNewDictValue(string dictType, string dictValue)
       {
            OracleParameter op_dictId = new OracleParameter("dictId", OracleDbType.Varchar2, 10);
            op_dictId.Direction = ParameterDirection.Input;
            op_dictId.Size = 10;
            op_dictId.Value = Tools.GetEntityPK("ST01");

            OracleParameter op_dictType = new OracleParameter("dictType", OracleDbType.Varchar2, 50);
            op_dictType.Direction = ParameterDirection.Input;
            op_dictType.Size = 50;
            op_dictType.Value = dictType;


            OracleParameter op_dictValue = new OracleParameter("dictValue", OracleDbType.Varchar2, 50);
            op_dictValue.Direction = ParameterDirection.Input;
            op_dictValue.Size = 50;
            op_dictValue.Value = dictValue;

            object sortId = SqlAssist.ExecuteScalar("select max(sortId)+1 from st01 where status = '1' and st002='" + dictType + "'", null);
            if (sortId is System.DBNull)
                sortId = 1;
            else
                sortId = int.Parse(sortId.ToString());

            OracleParameter op_sortId = new OracleParameter("sortId", OracleDbType.Int16);
            op_sortId.Direction = ParameterDirection.Input;
            op_sortId.Value = sortId;

            string sql = "insert into st01(st001,st002,st003,sortId,status) values(:dictId,:dictTye,:dictValue,:sortId,'1')";
            
            SqlAssist.ExecuteNonQuery(sql, new OracleParameter[] { op_dictId, op_dictType, op_dictValue, op_sortId });

            DataRowView newrow = null;
            if (dictType == "DIEREASON")
            {
                newrow = ac005_source.AddNew();                 
            }else if(dictType == "RELATION")
            {
                newrow = ac052_source.AddNew();
            }else if(dictType == "DRIVER")
            {
                newrow = ac060_source.AddNew();
            }
            newrow["ST001"] = op_dictId.Value.ToString();
            newrow["ST003"] = op_dictValue.Value.ToString();
            newrow["ST002"] = op_dictType.Value.ToString();
            newrow["SORTID"] = int.Parse(op_sortId.Value.ToString());
            newrow.EndEdit();

            return op_dictId.Value.ToString();
        }
 
        /// <summary>
        /// 身份证号校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtedit_ac014_Validating(object sender, CancelEventArgs e)
        {
            string s_idcard = txtedit_ac014.Text.Trim();
            if (string.IsNullOrWhiteSpace(s_idcard)) return;

            if(s_idcard.Length != 15 && s_idcard.Length != 18)
            {
                txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtedit_ac014.ErrorText = "身份证号位数错误!";
                e.Cancel = true;
            }else if(s_idcard.Length == 15)
            {
                if (!Tools.CheckIDCard15(s_idcard))
                {
                    txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtedit_ac014.ErrorText = "身份证号错误!";
                    e.Cancel = true;
                }
            }else if(s_idcard.Length == 18)
            {
                if (!Tools.CheckIDCard18(s_idcard))
                {
                    txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtedit_ac014.ErrorText = "身份证号错误!";
                    e.Cancel = true;
                }
            }

        }

        /// <summary>
        /// 年龄校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textEdit2_Validating(object sender, CancelEventArgs e)
        {
            string s_ac004 = txtEdit_ac004.Text.Trim();
            if (string.IsNullOrWhiteSpace(s_ac004)) return;

            int i;
            if(int.TryParse(s_ac004,out i))
            {
                if (i < 0)
                {
                    txtEdit_ac004.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtEdit_ac004.ErrorText = "年龄不能小于0!";
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// 死亡时间 校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dateEdit_ac010_Validating(object sender, CancelEventArgs e)
        {
            if (dateEdit_ac010.EditValue == null) return;
            if(DateTime.Compare((DateTime)dateEdit_ac010.EditValue,System.DateTime.Now) > 0)
            {
                dateEdit_ac010.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                dateEdit_ac010.ErrorText = "死亡时间不能大于系统当前时间!";
                e.Cancel = true;
            }
        }
        /// <summary>
        /// 到达时间 校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dateedit_ac020_Validating(object sender, CancelEventArgs e)
        {
            if (dateEdit_ac020.EditValue == null) return;
            if (DateTime.Compare((DateTime)dateEdit_ac020.EditValue, System.DateTime.Now) > 0)
            {
                dateEdit_ac020.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                dateEdit_ac020.ErrorText = "到达时间不能大于系统当前时间!";
                e.Cancel = true;
            }
        }

        /// <summary>
        /// 确定保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b_ok_Click(object sender, EventArgs e)
        {
            if (!SaveCheck()) return;  //数据合法性校验!!!
            Ac01 ac01 = new Ac01();

            if (this.cdata["action"].ToString() == "add")
            {
                ac01.ac001 = Tools.GetEntityPK("AC01");
            }
            else
            {
                ac01.ac001 = (this.cdata["rowdata"] as DataRow)["AC001"].ToString();
            }

            ac01.ac002 = rg_ac002.EditValue.ToString();     //性别
            ac01.ac003 = txtEdit_ac003.Text;                //逝者姓名
            ac01.ac004 = int.Parse(txtEdit_ac004.Text);     //年龄
            ac01.ac005 = lookUp_ac005.EditValue.ToString(); //死亡原因
            ac01.ac014 = txtedit_ac014.Text;                //身份证号
            ac01.ac007 = lookUp_ac007.EditValue.ToString(); //籍贯-所属区县
            ac01.ac008 = txtEdit_ac008.Text;                //籍贯-详细地址

            if (dateEdit_ac010.EditValue != null)
                ac01.ac010 = DateTime.Parse(dateEdit_ac010.EditValue.ToString());  //死亡时间
      

            ac01.ac009 = txtEdit_ac009.Text;                //接灵地址

            ac01.ac020 = DateTime.Parse(dateEdit_ac020.EditValue.ToString());      //到达中心时间

            ac01.ac050 = txtEdit_ac050.Text;                //联系人
            ac01.ac051 = txtEdit_ac051.Text;                //联系电话

            if(!(lookUp_ac052.EditValue == null || lookUp_ac052.EditValue is System.DBNull))
            {
                ac01.ac052 = lookUp_ac052.EditValue.ToString(); //与逝者关系
            }
            
            ac01.ac055 = txtEdit_ac055.Text;                //联系地址

            if(lookUp_ac060.EditValue != null)
                ac01.ac060 = lookUp_ac060.EditValue.ToString(); //灵车司机

            ac01.ac100 = Envior.cur_userId;                 //经办人
            ac01.ac200 = DateTime.Now;                      //经办日期
            ac01.ac110 = Envior.cur_userId;                 //最后经办人
            ac01.ac220 = DateTime.Now;                      //最后经办日期
            ac01.ac099 = mem_ac099.Text;                    //备注
            ac01.status = "1";                              //当前状态 
            ac01.ac077 = ac077;                             //账套标识
            

            using (SqlSugarClient db = SugarDao.GetInstance())
            {
                try
                {
                    if (this.cdata["action"].ToString() == "add")
                        db.Insert<Ac01>(ac01);
                    else
                        db.Update<Ac01>(ac01);

                    //db.InsertOrUpdate<Ac01>(ac01);

                    MessageBox.Show("保存成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    parentObject.cdata["AC001"] = ac01.ac001;
                    this.DialogResult = DialogResult.OK;
                    this.Close();

                }
                catch (Exception ee)
                {
                    MessageBox.Show("保存数据失败!\n" + ee.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// 保存前检查
        /// </summary>
        /// <returns></returns>
        private bool SaveCheck()
        {
            //逝者姓名
            if (string.IsNullOrWhiteSpace(txtEdit_ac003.Text.Trim()))
            {
                txtEdit_ac003.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac003.ErrorText = "逝者姓名必须输入!";
                txtEdit_ac003.Focus();
                return false;
            }
            //年龄
            if (string.IsNullOrWhiteSpace(txtEdit_ac004.Text.Trim()))
            {
                txtEdit_ac004.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac004.ErrorText = "年龄必须输入!";
                txtEdit_ac004.Focus();
                return false;
            }
            //死亡原因
            if(lookUp_ac005.EditValue == null)
            {
                lookUp_ac005.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                lookUp_ac005.ErrorText = "死亡原因必须输入!";
                lookUp_ac005.Focus();
                return false;
            }
            //逝者户籍
            if(lookUp_ac007.EditValue == null)
            {
                lookUp_ac007.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                lookUp_ac007.ErrorText = "逝者户籍必须输入!";
                lookUp_ac007.Focus();
                return false;
            }
            //联系人
            if (string.IsNullOrWhiteSpace(txtEdit_ac050.Text))
            {
                txtEdit_ac050.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac050.ErrorText = "联系人必须输入!";
                txtEdit_ac050.Focus();
                return false;
            }
            //与逝者关系
            //if (lookUp_ac052.EditValue == null)
            //{
            //    lookUp_ac052.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
            //    lookUp_ac052.ErrorText = "与逝者关系必须输入!";
            //    lookUp_ac052.Focus();
            //    return false;
            //}
            //联系电话
            if (string.IsNullOrWhiteSpace(txtEdit_ac051.Text))
            {
                txtEdit_ac051.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac051.ErrorText = "联系人必须输入!";
                txtEdit_ac051.Focus();
                return false;
            }
            return true;
        }

        
    }
}