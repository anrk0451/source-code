﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.DataSet;
using TianYuan_New.Business;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.Domain;
using OracleSugar;
using TianYuan_New.Dao;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    public partial class FireOutEdit : MyDialog
    {
        private DataView dt_ac005 = null;
        private DataView dt_ac052 = null;
        private DataView dt_ac060 = null;

        private string AC001 = string.Empty;
        private Ac01 ac01 = new Ac01();

        FireOutReport bo = null;

        public FireOutEdit()
        {
            InitializeComponent();
        }

        private void FireOutEdit_Load(object sender, EventArgs e)
        {
            bo = this.cdata["BusinessObject"] as FireOutReport;
            AC001 = this.cdata["AC001"].ToString();

            dt_ac005 = new DataView(Envior.mainform.appds.St01);
            dt_ac005.RowFilter = "st002='DIEREASON' and status = '1' ";
            lookUp_ac005.Properties.DataSource = dt_ac005;
            lookUp_ac005.Properties.ValueMember = "ST001";
            lookUp_ac005.Properties.DisplayMember = "ST003";

            dt_ac052 = new DataView(Envior.mainform.appds.St01);
            dt_ac052.RowFilter = "st002='RELATION' and status = '1' ";
            lookUp_ac052.Properties.DataSource = dt_ac052;
            lookUp_ac052.Properties.ValueMember = "ST001";
            lookUp_ac052.Properties.DisplayMember = "ST003";

            dt_ac060 = new DataView(Envior.mainform.appds.St01);
            dt_ac060.RowFilter = "st002='DRIVER' and status = '1' ";
            lookUp_ac060.Properties.DataSource = dt_ac060;
            lookUp_ac060.Properties.ValueMember = "ST001";
            lookUp_ac060.Properties.DisplayMember = "ST003";

            OracleDataReader reader =
                SqlAssist.ExecuteReader("select * from ac01 where ac001 ='" + AC001 + "'");

            while (reader.Read())
            {
                txtEdit_ac003.EditValue = reader["AC003"];
                rg_ac002.EditValue = reader["AC002"];
                txtEdit_ac004.EditValue = reader["AC004"];
                txtedit_ac014.EditValue = reader["AC014"];
                txtEdit_ac009.EditValue = reader["AC009"];
                dateEdit_ac010.EditValue = reader["AC010"];
                lookUp_ac005.EditValue = reader["AC005"];
                lookUp_ac060.EditValue = reader["AC060"];
                lookUp_ac007.EditValue = reader["AC007"];
                txtEdit_ac008.EditValue = reader["AC008"];
                txtEdit_ac050.EditValue = reader["AC050"];
                lookUp_ac052.EditValue = reader["AC052"];
                dateEdit_ac020.EditValue = reader["AC020"];
                txtEdit_ac051.EditValue = reader["AC051"];
                txtEdit_ac055.EditValue = reader["AC055"];
                mem_ac099.EditValue = reader["AC099"];
                dateEdit_ac020.Enabled = false;

                ac01.ac006 = reader["AC006"].ToString();
                ac01.ac015 = Convert.ToDateTime(reader["AC015"]);
                if(reader["AC018"] != null && reader["AC018"] != System.DBNull.Value)
                {
                    ac01.ac018 = Convert.ToDateTime(reader["AC018"]);
                }
                if (reader["AC019"] != null && reader["AC019"] != System.DBNull.Value)
                {
                    ac01.ac019 = Convert.ToDateTime(reader["AC019"]);
                }
                if(reader["AC022"] != null && reader["AC019"] != System.DBNull.Value)
                {
                    ac01.ac022 = reader["AC022"].ToString();
                }

                ac01.ac100 = reader["AC100"].ToString();
                ac01.ac200 = Convert.ToDateTime(reader["AC200"]);
                ac01.ac110 = reader["AC110"].ToString();
                ac01.ac220 = Convert.ToDateTime(reader["AC220"]);
                ac01.status = reader["STATUS"].ToString();

            }

        }


        private void lookUp_ac005_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac005.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if (newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("DIEREASON", this.cdata["newitem"].ToString());
                    lookUp_ac005.EditValue = newDictId;
                }
            }
        }

        /// <summary>
        /// 生成新的数据字典值
        /// </summary>
        /// <param name="dictType"></param>
        /// <param name="dictValue"></param>
        /// 返回值: 新字典Id
        private string GenNewDictValue(string dictType, string dictValue)
        {
            OracleParameter op_dictId = new OracleParameter("dictId", OracleDbType.Varchar2, 10);
            op_dictId.Direction = ParameterDirection.Input;
            op_dictId.Size = 10;
            op_dictId.Value = Tools.GetEntityPK("ST01");

            OracleParameter op_dictType = new OracleParameter("dictType", OracleDbType.Varchar2, 50);
            op_dictType.Direction = ParameterDirection.Input;
            op_dictType.Size = 50;
            op_dictType.Value = dictType;


            OracleParameter op_dictValue = new OracleParameter("dictValue", OracleDbType.Varchar2, 50);
            op_dictValue.Direction = ParameterDirection.Input;
            op_dictValue.Size = 50;
            op_dictValue.Value = dictValue;

            object sortId = SqlAssist.ExecuteScalar("select max(sortId)+1 from st01 where status = '1' and st002='" + dictType + "'", null);
            if (sortId == null)
                sortId = 1;
            else
                sortId = int.Parse(sortId.ToString());

            OracleParameter op_sortId = new OracleParameter("sortId", OracleDbType.Int16);
            op_sortId.Direction = ParameterDirection.Input;
            op_sortId.Value = sortId;

            string sql = "insert into st01(st001,st002,st003,sortId,status) values(:dictId,:dictTye,:dictValue,:sortId,'1')";

            SqlAssist.ExecuteNonQuery(sql, new OracleParameter[] { op_dictId, op_dictType, op_dictValue, op_sortId });

            DataRowView newrow = null;
            if (dictType == "DIEREASON")
            {
                newrow = dt_ac005.AddNew();
            }
            else if (dictType == "RELATION")
            {
                newrow = dt_ac052.AddNew();
            }
            else if (dictType == "DRIVER")
            {
                newrow = dt_ac060.AddNew();
            }
            newrow["ST001"] = op_dictId.Value.ToString();
            newrow["ST003"] = op_dictValue.Value.ToString();
            newrow["ST002"] = op_dictType.Value.ToString();
            newrow["SORTID"] = int.Parse(op_sortId.Value.ToString());
            newrow.EndEdit();

            return op_dictId.Value.ToString();
        }


        private void lookUp_ac052_EditValueChanged(object sender, EventArgs e)
        {
            if (lookUp_ac052.EditValue.ToString() == AppInfo.NewStItemId)
            {
                NewStItem newfrm = new NewStItem();
                newfrm.cdata["parent"] = this;
                if (newfrm.ShowDialog(this) == DialogResult.OK)  //录入新值
                {
                    string newDictId = GenNewDictValue("RELATION", this.cdata["newitem"].ToString());
                    lookUp_ac052.EditValue = newDictId;
                }
            }
        }

        /// <summary>
        /// 校验身份证号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtedit_ac014_Validating(object sender, CancelEventArgs e)
        {
            string s_idcard = txtedit_ac014.Text.Trim();
            if (string.IsNullOrWhiteSpace(s_idcard)) return;

            if (s_idcard.Length != 15 && s_idcard.Length != 18)
            {
                txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtedit_ac014.ErrorText = "身份证号位数错误!";
                e.Cancel = true;
            }
            else if (s_idcard.Length == 15)
            {
                if (!Tools.CheckIDCard15(s_idcard))
                {
                    txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtedit_ac014.ErrorText = "身份证号错误!";
                    e.Cancel = true;
                }
            }
            else if (s_idcard.Length == 18)
            {
                if (!Tools.CheckIDCard18(s_idcard))
                {
                    txtedit_ac014.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtedit_ac014.ErrorText = "身份证号错误!";
                    e.Cancel = true;
                }
            }
        }

        private void txtEdit_ac004_Validating(object sender, CancelEventArgs e)
        {
            string s_ac004 = txtEdit_ac004.Text.Trim();
            if (string.IsNullOrWhiteSpace(s_ac004)) return;

            int i;
            if (int.TryParse(s_ac004, out i))
            {
                if (i < 0)
                {
                    txtEdit_ac004.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtEdit_ac004.ErrorText = "年龄不能小于0!";
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// 死亡时间校验
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dateEdit_ac010_Validating(object sender, CancelEventArgs e)
        {
            if (dateEdit_ac010.EditValue == null) return;
            if (DateTime.Compare((DateTime)dateEdit_ac010.EditValue, System.DateTime.Now) > 0)
            {
                dateEdit_ac010.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                dateEdit_ac010.ErrorText = "死亡时间不能大于系统当前时间!";
                e.Cancel = true;
            }
        }
        /// <summary>
        /// 保存前检查
        /// </summary>
        /// <returns></returns>
        private bool SaveCheck()
        {
            //逝者姓名
            if (string.IsNullOrWhiteSpace(txtEdit_ac003.Text.Trim()))
            {
                txtEdit_ac003.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac003.ErrorText = "逝者姓名必须输入!";
                txtEdit_ac003.Focus();
                return false;
            }
            //年龄
            if (string.IsNullOrWhiteSpace(txtEdit_ac004.Text.Trim()))
            {
                txtEdit_ac004.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac004.ErrorText = "年龄必须输入!";
                txtEdit_ac004.Focus();
                return false;
            }
            //死亡原因
            if (lookUp_ac005.EditValue == null)
            {
                lookUp_ac005.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                lookUp_ac005.ErrorText = "死亡原因必须输入!";
                lookUp_ac005.Focus();
                return false;
            }
            //逝者户籍
            if (lookUp_ac007.EditValue == null)
            {
                lookUp_ac007.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                lookUp_ac007.ErrorText = "逝者户籍必须输入!";
                lookUp_ac007.Focus();
                return false;
            }
            //联系人
            if (string.IsNullOrWhiteSpace(txtEdit_ac050.Text))
            {
                txtEdit_ac050.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac050.ErrorText = "联系人必须输入!";
                txtEdit_ac050.Focus();
                return false;
            }
            //与逝者关系
            //if (lookUp_ac052.EditValue == null)
            //{
            //    lookUp_ac052.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
            //    lookUp_ac052.ErrorText = "与逝者关系必须输入!";
            //    lookUp_ac052.Focus();
            //    return false;
            //}
            //联系电话
            if (string.IsNullOrWhiteSpace(txtEdit_ac051.Text))
            {
                txtEdit_ac051.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_ac051.ErrorText = "联系人必须输入!";
                txtEdit_ac051.Focus();
                return false;
            }
            return true;
        }


        /// <summary>
        /// 保存过程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b_ok_Click(object sender, EventArgs e)
        {
            if (!SaveCheck()) return;  //数据合法性校验!!!
 
            ac01.ac001 = AC001;
 
            ac01.ac002 = rg_ac002.EditValue.ToString();     //性别
            ac01.ac003 = txtEdit_ac003.Text;                //逝者姓名
            ac01.ac004 = int.Parse(txtEdit_ac004.Text);     //年龄
            ac01.ac005 = lookUp_ac005.EditValue.ToString(); //死亡原因
            ac01.ac014 = txtedit_ac014.Text;                //身份证号
            ac01.ac007 = lookUp_ac007.EditValue.ToString(); //籍贯-所属区县
            ac01.ac008 = txtEdit_ac008.Text;                //籍贯-详细地址

            if (dateEdit_ac010.EditValue != null)
                ac01.ac010 = DateTime.Parse(dateEdit_ac010.EditValue.ToString());  //死亡时间

            ac01.ac009 = txtEdit_ac009.Text;                //接灵地址
            ac01.ac020 = DateTime.Parse(dateEdit_ac020.EditValue.ToString());      //到达中心时间

            ac01.ac050 = txtEdit_ac050.Text;                //联系人
            ac01.ac051 = txtEdit_ac051.Text;                //联系电话

            if (!(lookUp_ac052.EditValue == null || lookUp_ac052.EditValue is System.DBNull))
            {
                ac01.ac052 = lookUp_ac052.EditValue.ToString(); //与逝者关系
            }
                

            ac01.ac055 = txtEdit_ac055.Text;                //联系地址

            if (lookUp_ac060.EditValue != null)
                ac01.ac060 = lookUp_ac060.EditValue.ToString(); //灵车司机

            ac01.ac100 = Envior.cur_userId;                 //经办人
            ac01.ac200 = DateTime.Now;                      //经办日期
            ac01.ac110 = Envior.cur_userId;                 //最后经办人
            ac01.ac220 = DateTime.Now;                      //最后经办日期
            ac01.ac099 = mem_ac099.Text;                    //备注
            ac01.status = "1";                              //当前状态 
            ac01.ac077 = FireAction.GetAccountIdByAc001(AC001);

            using (SqlSugarClient db = SugarDao.GetInstance())
            {
                try
                {
                    db.Update<Ac01>(ac01);
                    MessageBox.Show("修改成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ee)
                {
                    MessageBox.Show("保存数据失败!\n" + ee.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}