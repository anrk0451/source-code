﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;

namespace TianYuan_New.Windows
{ 
    /// <summary>
    /// 火化业务办理
    /// </summary>
    public partial class FireSearch : MyDialog
    {
        private DataTable dt_ac01 = new DataTable("AC01");
        private OracleDataAdapter ac01Adapter = new OracleDataAdapter("",SqlAssist.conn);
        private string accountId = string.Empty;
        private OracleParameter op_accountId = new OracleParameter("accountId", OracleDbType.Varchar2, 3);

        public FireSearch()
        {
            InitializeComponent();
        }

        private void FireSearch_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = dt_ac01;
            
            if(this.cdata["mainForm"] is MainForm)
            {
                accountId = "1";
            }
            else
            {
                accountId = "2";
            }
            op_accountId.Value = accountId;
            ac01Adapter.SelectCommand.Parameters.Add(op_accountId);
        }

        //执行查询
        private void b_ok_Click(object sender, EventArgs e)
        {
            string s_sql = string.Empty;
            if(txtedit_ac001.EditValue == null && txtedit_ac003.EditValue == null && txtedit_ac050.EditValue == null)
            {
                MessageBox.Show("请至少输入一个条件！","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            if(txtedit_ac001.EditValue != null)
            {
                s_sql = @"select ac001,ac002,ac003,ac004,ac014,ac020,ac050,ac051 from ac01 where ac077 = :accountId and status = '1' and ac001='" + txtedit_ac001.Text + "'";
            }else if(txtedit_ac050.EditValue == null)
            {
                s_sql = @"select ac001,ac002,ac003,ac004,ac014,ac020,ac050,ac051 from ac01 where ac077 = :accountId and status = '1' and ac003  like '%" + txtedit_ac003.Text + "%'";
            }else if(txtedit_ac003.EditValue == null)
            {
                s_sql = @"select ac001,ac002,ac003,ac004,ac014,ac020,ac050,ac051 from ac01 where ac077 = :accountId and status = '1' and ac050  like '%" + txtedit_ac050.Text + "%'";
            }
            else
            {
                s_sql = @"select ac001,ac002,ac003,ac004,ac014,ac020,ac050,ac051 from ac01 where ac077 = :accountId and status = '1' and ac003  like '%" + txtedit_ac003.Text + "%' and "
                        + " ac050 like '%" + txtedit_ac050.Text + "%'";
            }

            gridView1.BeginUpdate();
            dt_ac01.Clear();
            ac01Adapter.SelectCommand.CommandText = s_sql;
            ac01Adapter.Fill(dt_ac01);
            gridView1.EndUpdate();
        }

        private void txtedit_ac001_EditValueChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtedit_ac001.Text)) return;
            txtedit_ac001.Text = txtedit_ac001.Text.PadLeft(10, '0');
        }

        /// <summary>
        /// 转换性别
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_CustomColumnDisplayText(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "AC002")
            {
                if (e.Value.ToString() == "0")
                    e.DisplayText = "男";
                else if (e.Value.ToString() == "1")
                    e.DisplayText = "女";
                else
                    e.DisplayText = "未知";
            }
        }

        /// <summary>
        /// 办理业务
        /// </summary>
        /// <param name="row"></param>
        private void Business(int row)
        {
            string s_ac001 = gridView1.GetRowCellValue(row, "AC001").ToString();
            this.Close();
            if(accountId == "1")
                (this.cdata["mainForm"] as MainForm).openBusinessObject("FireBusiness", s_ac001);
            else
                (this.cdata["mainForm"] as Main_2nd).openBusinessObject("FireBusiness", s_ac001);
 
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            int row = gridView1.FocusedRowHandle;
            if (row >= 0)
                Business(row);
        }

        private void gridView1_MouseDown(object sender, MouseEventArgs e)
        {
            GridHitInfo hInfo = gridView1.CalcHitInfo(new Point(e.X, e.Y));
            if (e.Button == MouseButtons.Left && e.Clicks == 2)
            {
                //判断光标是否在行范围内  
                if (hInfo.InRow)
                {
                    Business(gridView1.FocusedRowHandle);
                }
            }
        }
    }
}