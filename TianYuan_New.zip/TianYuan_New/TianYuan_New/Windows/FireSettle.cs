﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.DataSet;
using TianYuan_New.ActionObject;
using System.Runtime.InteropServices;

namespace TianYuan_New.Windows
{
    public partial class FireSettle : MyDialog
    {
        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);

        FireSalesSet salesSet;
        string AC001;
        List<int> rowList;
        DataTable dt_source;

        public FireSettle()
        {
            InitializeComponent();
        }

        private void FireSettle_Load(object sender, EventArgs e)
        {
            AC001 = this.cdata["AC001"].ToString();
            salesSet = this.cdata["salesSet"] as FireSalesSet;
            rowList = this.cdata["rowList"] as List<int>;

            ///拷贝要结算的记录!!!
            dt_source = salesSet.Sa01.Clone();
            foreach(int i in rowList)
            {
                dt_source.Rows.Add(salesSet.Sa01.Rows[i].ItemArray);
            }

            gridControl1.DataSource = dt_source;
        }

        private void gridView1_CustomDrawRowIndicator(object sender, DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventArgs e)
        {
            e.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            if (e.Info.IsRowIndicator)
            {
                if (e.RowHandle >= 0)
                {
                    e.Info.DisplayText = (e.RowHandle + 1).ToString();
                }
                else if (e.RowHandle < 0 && e.RowHandle > -1000)
                {
                    e.Info.Appearance.BackColor = System.Drawing.Color.AntiqueWhite;
                    e.Info.DisplayText = "G" + e.RowHandle.ToString();
                }
            }
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            string settleId = Tools.GetEntityPK("FA01");
            List<string> sa001_list = new List<string>();
            foreach(DataRow r in dt_source.Rows)
            {
                sa001_list.Add(r["SA001"].ToString());
            }

            int result = FireAction.FireBusinessSettle(settleId,
                                                       AC001,
                                                       sa001_list.ToArray(),
                                                       Envior.cur_userId
            );
            if (result > 0)
            {
                if (MessageBox.Show("结算办理成功!现在打印收据吗?","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    //打印收据
                    Print_invoice(settleId);
                    int fire_row = gridView1.LocateByValue("SA002", "06");
                    //如果有火化,打印火化证明
                    if (fire_row >= 0)
                    {   //打印火化证明
                        MessageBox.Show("现在打印火化证明!","提示",MessageBoxButtons.OK);
                        Print_HHZM(AC001);
                    }
                }
                DialogResult = DialogResult.OK;
                this.Dispose();
            }
        }

        /// <summary>
        /// 打印收据
        /// </summary>
        /// <param name="settleId"></param>
        private void Print_invoice(string settleId)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         this.Handle.ToInt32(),
                                         commandNum,
                                         "Fire_invoice",
                                         settleId,
                                         null
                );
        }

        /// <summary>
        /// 打印火化证明
        /// </summary>
        /// <param name="ac001"></param>
        private void Print_HHZM(string ac001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            int result = PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         Envior.mainform.Handle.ToInt32(),
                                         commandNum,
                                         "Fire_HHZM",
                                         ac001,
                                         null
                );
            if(result > 0)
            {  //记录火化证明打印日志
                PrtServAction.FireCertLog(AC001, Envior.cur_userId);
            }
        }

        /// <summary>
        /// 消息响应
        /// </summary>
        /// <param name="m"></param>
        //protected override void DefWndProc(ref Message m)
        //{
        //    switch (m.Msg)
        //    {
        //        case 10001:
        //            int commandNum = m.WParam.ToInt32();
        //            string responseText = PrtServAction.GetResponseText(commandNum);
        //            MessageBox.Show(responseText,"提示",MessageBoxButtons.OK,MessageBoxIcon.Stop);
        //            break;
        //        default:
        //            base.DefWndProc(ref m);///调用基类函数处理非自定义消息。
        //            break;
        //    }
        //}
    }
}