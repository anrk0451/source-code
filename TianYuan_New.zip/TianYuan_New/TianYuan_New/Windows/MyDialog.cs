﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace TianYuan_New.Windows
{
    public partial class MyDialog : DevExpress.XtraEditors.XtraForm
    {
        

        public MyDialog()
        {
            cdata = new Dictionary<string, object>();
            InitializeComponent();
        }

        ///窗体间交换数据
        public Dictionary<string,Object> cdata { get; set; }

        private void MyDialog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Convert.ToInt32(e.KeyChar) == 13)
            {
                System.Windows.Forms.SendKeys.Send("{tab}");
            }
        }

        private void MyDialog_Load(object sender, EventArgs e)
        {

        }
    }
}