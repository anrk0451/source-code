﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class NewStItem : MyDialog
    {
        private MyDialog parent;
        public NewStItem()
        {
            InitializeComponent();
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            string s_newitem = textEdit1.Text;
            if (string.IsNullOrEmpty(s_newitem))
            {
                textEdit1.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                textEdit1.ErrorText = "请输入新项目值!";
                return;
            }

            parent.cdata["newitem"] = s_newitem;
            DialogResult = DialogResult.OK;
            this.Close();

        }

        private void NewStItem_Load(object sender, EventArgs e)
        {
            parent = this.cdata["parent"] as MyDialog;
            if(parent == null)
            {
                MessageBox.Show("对象传递错误!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            textEdit1.Focus();
        }
    }
}