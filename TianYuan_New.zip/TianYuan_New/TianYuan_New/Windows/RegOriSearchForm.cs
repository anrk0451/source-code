﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class RegOriSearchForm : MyDialog
    {
        RegOriSearch bo = null;
        public RegOriSearchForm()
        {
            InitializeComponent();
        }

        private void RegOriSearchForm_Load(object sender, EventArgs e)
        {
            bo = this.cdata["BusinessObject"] as RegOriSearch;
            dateEdit2.EditValue = DateTime.Now;
            dateEdit1.EditValue = DateTime.Today.AddMonths(-1);
        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            bo.cdata["dbegin"] = dateEdit1.EditValue;
            bo.cdata["dend"] = dateEdit2.EditValue;
         
            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}