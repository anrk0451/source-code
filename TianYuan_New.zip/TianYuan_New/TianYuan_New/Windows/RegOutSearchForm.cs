﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using TianYuan_New.Business;

namespace TianYuan_New.Windows
{
    public partial class RegOutSearchForm : MyDialog
    {
        private RegOutSearch bo = null;

        public RegOutSearchForm()
        {
            InitializeComponent();
        }

        private void RegOutSearchForm_Load(object sender, EventArgs e)
        {
            bo = this.cdata["BusinessObject"] as RegOutSearch;

            dateEdit2.EditValue = DateTime.Now;
            dateEdit1.EditValue = DateTime.Today.AddMonths(-1);
        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            bo.cdata["dbegin"] = dateEdit1.EditValue;
            bo.cdata["dend"] = dateEdit2.EditValue;
            bo.cdata["RC003"] = textEdit1.EditValue;

            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}