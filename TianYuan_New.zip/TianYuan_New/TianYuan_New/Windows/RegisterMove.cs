﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    public partial class RegisterMove :MyDialog
    {
        private string rc001 = string.Empty;
        private string bitId = string.Empty;
        private string bitId_Old = string.Empty;

        public RegisterMove()
        {
            InitializeComponent();
        }

        private void RegisterMove_Load(object sender, EventArgs e)
        {
            rc001 = this.cdata["RC001"].ToString();

            OracleDataReader reader = SqlAssist.ExecuteReader("select * from rc01 where rc001='" + rc001 + "'");
            while (reader.Read())
            {
                txtEdit_rc001.Text = rc001;
                txtEdit_rc109.EditValue = reader["RC109"];
                txtEdit_rc003.EditValue = reader["RC003"];
                bitId_Old = reader["RC130"].ToString();
                be_position.EditValue = RegisterAction.GetRegPathName(rc001);
            }
        }

        private void b_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonEdit1_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonEdit1_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            FreeBit freebit = new FreeBit();
            freebit.cdata["parent"] = this;

            if (freebit.ShowDialog() == DialogResult.OK)
            {
                string regionId, bitDesc;
                regionId = this.cdata["regionId"].ToString();
                bitDesc = this.cdata["bitDesc"].ToString();
                bitId = RegisterAction.GetBitId(regionId, bitDesc);
                be_newposition.Text = RegisterAction.GetBitFullName(regionId, bitDesc);
            }
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(bitId))
            {
                be_newposition.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                be_newposition.ErrorText = "请选择变更后位置!";
                return;
            }

            int re = RegisterAction.RegisterMove(rc001, bitId_Old, bitId, Envior.cur_userId);
            if (re > 0)
            {
                MessageBox.Show("办理成功!","提示");
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}