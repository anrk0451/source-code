﻿namespace TianYuan_New.Windows
{
    partial class RegisterOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEdit_rc109 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc001 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.be_position = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc404 = new DevExpress.XtraEditors.TextEdit();
            this.rg_rc202 = new DevExpress.XtraEditors.RadioGroup();
            this.txtEdit_rc303 = new DevExpress.XtraEditors.TextEdit();
            this.txtEdit_rc004 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.rg_rc002 = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc003 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.txtEdit_fee = new DevExpress.XtraEditors.TextEdit();
            this.lc_3 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_price = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_nums = new DevExpress.XtraEditors.TextEdit();
            this.lc_2 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_diff = new DevExpress.XtraEditors.TextEdit();
            this.lc_1 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc150 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_oc003 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_oc004 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.mem_oc005 = new DevExpress.XtraEditors.MemoEdit();
            this.sb_exit = new DevExpress.XtraEditors.SimpleButton();
            this.b_ok = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc109.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc001.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.be_position.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc404.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc202.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc303.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc004.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc002.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc003.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_fee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_price.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_nums.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_diff.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc150.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_oc003.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_oc004.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_oc005.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEdit_rc109
            // 
            this.txtEdit_rc109.Enabled = false;
            this.txtEdit_rc109.Location = new System.Drawing.Point(340, 25);
            this.txtEdit_rc109.Name = "txtEdit_rc109";
            this.txtEdit_rc109.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_rc109.TabIndex = 119;
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(258, 28);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(60, 18);
            this.labelControl13.TabIndex = 118;
            this.labelControl13.Text = "寄存证号";
            // 
            // txtEdit_rc001
            // 
            this.txtEdit_rc001.Enabled = false;
            this.txtEdit_rc001.Location = new System.Drawing.Point(124, 25);
            this.txtEdit_rc001.Name = "txtEdit_rc001";
            this.txtEdit_rc001.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_rc001.TabIndex = 117;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(38, 28);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(60, 18);
            this.labelControl8.TabIndex = 116;
            this.labelControl8.Text = "逝者编号";
            // 
            // be_position
            // 
            this.be_position.Enabled = false;
            this.be_position.Location = new System.Drawing.Point(125, 67);
            this.be_position.Name = "be_position";
            this.be_position.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.be_position.Properties.ReadOnly = true;
            this.be_position.Size = new System.Drawing.Size(448, 24);
            this.be_position.TabIndex = 109;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(38, 69);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(60, 18);
            this.labelControl16.TabIndex = 108;
            this.labelControl16.Text = "寄存位置";
            // 
            // txtEdit_rc404
            // 
            this.txtEdit_rc404.Enabled = false;
            this.txtEdit_rc404.Location = new System.Drawing.Point(520, 150);
            this.txtEdit_rc404.Name = "txtEdit_rc404";
            this.txtEdit_rc404.Properties.Mask.BeepOnError = true;
            this.txtEdit_rc404.Properties.Mask.EditMask = "n0";
            this.txtEdit_rc404.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_rc404.Size = new System.Drawing.Size(53, 24);
            this.txtEdit_rc404.TabIndex = 107;
            // 
            // rg_rc202
            // 
            this.rg_rc202.EditValue = "1";
            this.rg_rc202.Enabled = false;
            this.rg_rc202.Location = new System.Drawing.Point(292, 150);
            this.rg_rc202.Name = "rg_rc202";
            this.rg_rc202.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rg_rc202.Properties.Appearance.Options.UseBackColor = true;
            this.rg_rc202.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rg_rc202.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("0", "男"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("1", "女"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("2", "未知")});
            this.rg_rc202.Size = new System.Drawing.Size(165, 24);
            this.rg_rc202.TabIndex = 106;
            // 
            // txtEdit_rc303
            // 
            this.txtEdit_rc303.Enabled = false;
            this.txtEdit_rc303.Location = new System.Drawing.Point(125, 150);
            this.txtEdit_rc303.Name = "txtEdit_rc303";
            this.txtEdit_rc303.Size = new System.Drawing.Size(89, 24);
            this.txtEdit_rc303.TabIndex = 105;
            // 
            // txtEdit_rc004
            // 
            this.txtEdit_rc004.Enabled = false;
            this.txtEdit_rc004.Location = new System.Drawing.Point(520, 111);
            this.txtEdit_rc004.Name = "txtEdit_rc004";
            this.txtEdit_rc004.Properties.Mask.BeepOnError = true;
            this.txtEdit_rc004.Properties.Mask.EditMask = "n0";
            this.txtEdit_rc004.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_rc004.Size = new System.Drawing.Size(53, 24);
            this.txtEdit_rc004.TabIndex = 97;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(470, 115);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(30, 18);
            this.labelControl3.TabIndex = 96;
            this.labelControl3.Text = "年龄";
            // 
            // rg_rc002
            // 
            this.rg_rc002.EditValue = "0";
            this.rg_rc002.Enabled = false;
            this.rg_rc002.Location = new System.Drawing.Point(292, 111);
            this.rg_rc002.Name = "rg_rc002";
            this.rg_rc002.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rg_rc002.Properties.Appearance.Options.UseBackColor = true;
            this.rg_rc002.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rg_rc002.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("0", "男"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("1", "女"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("2", "未知")});
            this.rg_rc002.Size = new System.Drawing.Size(165, 24);
            this.rg_rc002.TabIndex = 95;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(248, 115);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(30, 18);
            this.labelControl2.TabIndex = 94;
            this.labelControl2.Text = "性别";
            // 
            // txtEdit_rc003
            // 
            this.txtEdit_rc003.Location = new System.Drawing.Point(125, 111);
            this.txtEdit_rc003.Name = "txtEdit_rc003";
            this.txtEdit_rc003.Properties.ReadOnly = true;
            this.txtEdit_rc003.Size = new System.Drawing.Size(89, 24);
            this.txtEdit_rc003.TabIndex = 93;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(38, 115);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(60, 18);
            this.labelControl1.TabIndex = 91;
            this.labelControl1.Text = "逝者姓名";
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.txtEdit_fee);
            this.groupControl1.Controls.Add(this.lc_3);
            this.groupControl1.Controls.Add(this.txtEdit_price);
            this.groupControl1.Controls.Add(this.labelControl11);
            this.groupControl1.Controls.Add(this.txtEdit_nums);
            this.groupControl1.Controls.Add(this.lc_2);
            this.groupControl1.Controls.Add(this.txtEdit_diff);
            this.groupControl1.Controls.Add(this.lc_1);
            this.groupControl1.Controls.Add(this.txtEdit_rc150);
            this.groupControl1.Controls.Add(this.labelControl7);
            this.groupControl1.Location = new System.Drawing.Point(38, 355);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(535, 183);
            this.groupControl1.TabIndex = 120;
            this.groupControl1.Text = "补退费信息";
            // 
            // txtEdit_fee
            // 
            this.txtEdit_fee.Enabled = false;
            this.txtEdit_fee.Location = new System.Drawing.Point(157, 138);
            this.txtEdit_fee.Name = "txtEdit_fee";
            this.txtEdit_fee.Properties.Appearance.Options.UseTextOptions = true;
            this.txtEdit_fee.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtEdit_fee.Properties.Mask.EditMask = "N2";
            this.txtEdit_fee.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_fee.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEdit_fee.Size = new System.Drawing.Size(99, 24);
            this.txtEdit_fee.TabIndex = 136;
            // 
            // lc_3
            // 
            this.lc_3.Location = new System.Drawing.Point(24, 142);
            this.lc_3.Name = "lc_3";
            this.lc_3.Size = new System.Drawing.Size(60, 18);
            this.lc_3.TabIndex = 135;
            this.lc_3.Text = "补费金额";
            // 
            // txtEdit_price
            // 
            this.txtEdit_price.Enabled = false;
            this.txtEdit_price.Location = new System.Drawing.Point(410, 87);
            this.txtEdit_price.Name = "txtEdit_price";
            this.txtEdit_price.Properties.Appearance.Options.UseTextOptions = true;
            this.txtEdit_price.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtEdit_price.Properties.Mask.EditMask = "N2";
            this.txtEdit_price.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_price.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEdit_price.Size = new System.Drawing.Size(91, 24);
            this.txtEdit_price.TabIndex = 134;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(340, 90);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(30, 18);
            this.labelControl11.TabIndex = 133;
            this.labelControl11.Text = "单价";
            // 
            // txtEdit_nums
            // 
            this.txtEdit_nums.Location = new System.Drawing.Point(157, 87);
            this.txtEdit_nums.Name = "txtEdit_nums";
            this.txtEdit_nums.Properties.Appearance.Options.UseTextOptions = true;
            this.txtEdit_nums.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtEdit_nums.Properties.Mask.EditMask = "N1";
            this.txtEdit_nums.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_nums.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEdit_nums.Size = new System.Drawing.Size(99, 24);
            this.txtEdit_nums.TabIndex = 132;
            this.txtEdit_nums.EditValueChanged += new System.EventHandler(this.txtEdit_nums_EditValueChanged);
            this.txtEdit_nums.Validating += new System.ComponentModel.CancelEventHandler(this.txtEdit_nums_Validating);
            // 
            // lc_2
            // 
            this.lc_2.Location = new System.Drawing.Point(24, 90);
            this.lc_2.Name = "lc_2";
            this.lc_2.Size = new System.Drawing.Size(117, 18);
            this.lc_2.TabIndex = 131;
            this.lc_2.Text = "应补费年份(年限)";
            // 
            // txtEdit_diff
            // 
            this.txtEdit_diff.Enabled = false;
            this.txtEdit_diff.Location = new System.Drawing.Point(410, 38);
            this.txtEdit_diff.Name = "txtEdit_diff";
            this.txtEdit_diff.Properties.Appearance.Options.UseTextOptions = true;
            this.txtEdit_diff.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtEdit_diff.Properties.Mask.EditMask = "n0";
            this.txtEdit_diff.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_diff.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEdit_diff.Size = new System.Drawing.Size(91, 24);
            this.txtEdit_diff.TabIndex = 130;
            // 
            // lc_1
            // 
            this.lc_1.Location = new System.Drawing.Point(340, 41);
            this.lc_1.Name = "lc_1";
            this.lc_1.Size = new System.Drawing.Size(60, 18);
            this.lc_1.TabIndex = 129;
            this.lc_1.Text = "剩余天数";
            // 
            // txtEdit_rc150
            // 
            this.txtEdit_rc150.Enabled = false;
            this.txtEdit_rc150.Location = new System.Drawing.Point(157, 38);
            this.txtEdit_rc150.Name = "txtEdit_rc150";
            this.txtEdit_rc150.Properties.Mask.EditMask = "d";
            this.txtEdit_rc150.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            this.txtEdit_rc150.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEdit_rc150.Size = new System.Drawing.Size(99, 24);
            this.txtEdit_rc150.TabIndex = 128;
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(24, 41);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(60, 18);
            this.labelControl7.TabIndex = 127;
            this.labelControl7.Text = "到期时间";
            // 
            // checkEdit1
            // 
            this.checkEdit1.EditValue = true;
            this.checkEdit1.Location = new System.Drawing.Point(474, 343);
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Caption = "补退费迁出";
            this.checkEdit1.Size = new System.Drawing.Size(99, 22);
            this.checkEdit1.TabIndex = 121;
            this.checkEdit1.CheckedChanged += new System.EventHandler(this.checkEdit1_CheckedChanged);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(38, 200);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(45, 18);
            this.labelControl4.TabIndex = 122;
            this.labelControl4.Text = "迁出人";
            // 
            // txtEdit_oc003
            // 
            this.txtEdit_oc003.Location = new System.Drawing.Point(125, 197);
            this.txtEdit_oc003.Name = "txtEdit_oc003";
            this.txtEdit_oc003.Size = new System.Drawing.Size(89, 24);
            this.txtEdit_oc003.TabIndex = 123;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(248, 200);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(60, 18);
            this.labelControl5.TabIndex = 124;
            this.labelControl5.Text = "身份证号";
            // 
            // txtEdit_oc004
            // 
            this.txtEdit_oc004.Location = new System.Drawing.Point(340, 197);
            this.txtEdit_oc004.Name = "txtEdit_oc004";
            this.txtEdit_oc004.Size = new System.Drawing.Size(233, 24);
            this.txtEdit_oc004.TabIndex = 125;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(38, 247);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(60, 18);
            this.labelControl6.TabIndex = 126;
            this.labelControl6.Text = "迁出原因";
            // 
            // mem_oc005
            // 
            this.mem_oc005.Location = new System.Drawing.Point(124, 241);
            this.mem_oc005.Name = "mem_oc005";
            this.mem_oc005.Size = new System.Drawing.Size(449, 96);
            this.mem_oc005.TabIndex = 127;
            // 
            // sb_exit
            // 
            this.sb_exit.Appearance.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.sb_exit.Appearance.ForeColor = System.Drawing.Color.Snow;
            this.sb_exit.Appearance.Options.UseBackColor = true;
            this.sb_exit.Appearance.Options.UseForeColor = true;
            this.sb_exit.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.sb_exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.sb_exit.Location = new System.Drawing.Point(593, 70);
            this.sb_exit.Name = "sb_exit";
            this.sb_exit.Size = new System.Drawing.Size(126, 31);
            this.sb_exit.TabIndex = 129;
            this.sb_exit.Text = "退出";
            // 
            // b_ok
            // 
            this.b_ok.Appearance.BackColor = System.Drawing.Color.Lime;
            this.b_ok.Appearance.ForeColor = System.Drawing.Color.White;
            this.b_ok.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_ok.Appearance.Options.UseBackColor = true;
            this.b_ok.Appearance.Options.UseForeColor = true;
            this.b_ok.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_ok.Location = new System.Drawing.Point(593, 28);
            this.b_ok.Name = "b_ok";
            this.b_ok.Size = new System.Drawing.Size(126, 31);
            this.b_ok.TabIndex = 128;
            this.b_ok.Text = "确定";
            this.b_ok.Click += new System.EventHandler(this.b_ok_Click);
            // 
            // RegisterOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.sb_exit;
            this.ClientSize = new System.Drawing.Size(733, 550);
            this.Controls.Add(this.sb_exit);
            this.Controls.Add(this.b_ok);
            this.Controls.Add(this.mem_oc005);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.txtEdit_oc004);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.txtEdit_oc003);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.checkEdit1);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.txtEdit_rc109);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.txtEdit_rc001);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.be_position);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.txtEdit_rc404);
            this.Controls.Add(this.rg_rc202);
            this.Controls.Add(this.txtEdit_rc303);
            this.Controls.Add(this.txtEdit_rc004);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.rg_rc002);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtEdit_rc003);
            this.Controls.Add(this.labelControl1);
            this.Name = "RegisterOut";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "寄存迁出";
            this.Load += new System.EventHandler(this.RegisterOut_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc109.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc001.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.be_position.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc404.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc202.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc303.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc004.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc002.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc003.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_fee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_price.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_nums.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_diff.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc150.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_oc003.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_oc004.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_oc005.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtEdit_rc109;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc001;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.ButtonEdit be_position;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc404;
        private DevExpress.XtraEditors.RadioGroup rg_rc202;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc303;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc004;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.RadioGroup rg_rc002;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc003;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit txtEdit_fee;
        private DevExpress.XtraEditors.LabelControl lc_3;
        private DevExpress.XtraEditors.TextEdit txtEdit_price;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtEdit_nums;
        private DevExpress.XtraEditors.LabelControl lc_2;
        private DevExpress.XtraEditors.TextEdit txtEdit_diff;
        private DevExpress.XtraEditors.LabelControl lc_1;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc150;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit txtEdit_oc003;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtEdit_oc004;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.MemoEdit mem_oc005;
        private DevExpress.XtraEditors.SimpleButton sb_exit;
        private DevExpress.XtraEditors.SimpleButton b_ok;
    }
}