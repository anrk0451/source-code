﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    public partial class RegisterOut : MyDialog
    {
        private string rc001 = string.Empty;
        private decimal price = decimal.Zero;
        private bool isrefund = false;         //是否退费

        public RegisterOut()
        {
            InitializeComponent();
        }

        private void RegisterOut_Load(object sender, EventArgs e)
        {
            rc001 = this.cdata["RC001"].ToString();

            OracleDataReader reader = SqlAssist.ExecuteReader("select * from rc01 where rc001='" + rc001 + "'");
            while (reader.Read())
            {
                txtEdit_rc001.Text = rc001;
                txtEdit_rc109.EditValue = reader["RC109"];
                txtEdit_rc003.EditValue = reader["RC003"];
                txtEdit_rc303.EditValue = reader["RC303"];
                rg_rc002.EditValue = reader["RC002"];
                rg_rc202.EditValue = reader["RC202"];
                txtEdit_rc004.EditValue = reader["RC004"];
                txtEdit_rc404.EditValue = reader["RC404"];
                txtEdit_rc150.EditValue = reader["RC150"];

                price = RegisterAction.GetBitPrice(reader["RC130"].ToString());
                txtEdit_price.EditValue = price;

                int compare = string.Compare(Convert.ToDateTime(reader["RC150"]).ToString("yyyyMMdd"), DateTime.Now.ToString("yyyyMMdd"));
                if(compare == 0)
                {
                    checkEdit1.Enabled = false;
                    txtEdit_nums.Enabled = false;
                }else if(compare > 0)  //退费
                {
                    lc_1.Text = "剩余天数";
                    lc_2.Text = "应退费年份(年限)";
                    lc_3.Text = "退费金额";
                    isrefund = true;
                }
                else
                {
                    lc_1.Text = "过期天数";
                    lc_2.Text = "应补费年份(年限)";
                    lc_3.Text = "补费金额";
                }

                int diff = RegisterAction.CalcOutDiffDays(rc001);
                txtEdit_diff.EditValue = diff;
                txtEdit_nums.EditValue = Math.Round((diff *1.0f) / 365, 1);
                txtEdit_fee.EditValue = Convert.ToDecimal(Math.Round((diff * 1.0f) / 365, 1)) * price ;
            }

            ////是否允许取消迁出补退 /////
            if(Tools.GetRight(Envior.cur_userId,"02070") == "0")
            {
                checkEdit1.Enabled = false;
            }

        }

        private void checkEdit1_CheckedChanged(object sender, EventArgs e)
        {
            txtEdit_nums.Enabled = checkEdit1.Checked;
        }

        private void txtEdit_nums_Validating(object sender, CancelEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEdit_nums.Text))
            {
                if(Convert.ToDecimal(txtEdit_nums.Text) < 0)
                {
                    txtEdit_nums.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                    txtEdit_nums.ErrorText = "应为正值!";
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// 年限变更 更新补退费金额
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtEdit_nums_EditValueChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEdit_nums.Text))
            {
                decimal nums = Convert.ToDecimal(txtEdit_nums.Text);
                txtEdit_fee.EditValue = Math.Round(price * nums);
            }
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            if(rc001 == null)
            {
                MessageBox.Show("数据传递错误!","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            if(txtEdit_oc003.EditValue == null || txtEdit_oc003.EditValue is System.DBNull)
            {
                txtEdit_oc003.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                txtEdit_oc003.ErrorText = "请输入迁出办理人!";
                return;
            }
            if(mem_oc005.EditValue == null)
            {
                mem_oc005.ErrorImageOptions.Alignment = ErrorIconAlignment.MiddleRight;
                mem_oc005.ErrorText = "请输入迁出原因!";
                return;
            }
            string s_oc003 = txtEdit_oc003.Text;   //迁出人
            string s_oc005 = mem_oc005.Text;       //迁出原因
            string s_oc004 = txtEdit_oc004.Text;   //迁出人身份证号

            int diff = int.Parse(txtEdit_diff.EditValue.ToString());
            decimal nums = decimal.Zero;
            string fa001 = Tools.GetEntityPK("FA01");

            //补退情况
            if (checkEdit1.Checked)
            {                
                nums = decimal.Parse(txtEdit_nums.Text);
            }
            else
            {
                nums = 0;
            }

            if (MessageBox.Show("确认要继续办理迁出吗？本业务将不能回退!", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No) return;
            int re = RegisterAction.RegisterOut( rc001,
                                                 s_oc003,
                                                 s_oc004,
                                                 s_oc005,
                                                 diff,
                                                 fa001,
                                                 price,
                                                 isrefund ? 0- nums : nums,
                                                 Envior.cur_userId
                );
            if (re > 0)
            {
                MessageBox.Show("迁出办理成功!现在打印【迁出通知单】", "",MessageBoxButtons.OK,MessageBoxIcon.Information);
                RegisterAction.PrtRegisterOutCard(rc001);

                if(Math.Abs(nums) > 0)
                {
                    MessageBox.Show("现在打印收据!","提示");
                    RegisterAction.PrtRegisterOutInvoice(fa001);
                }
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}