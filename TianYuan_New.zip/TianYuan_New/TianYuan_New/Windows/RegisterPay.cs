﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Oracle.ManagedDataAccess.Client;
using TianYuan_New.ActionObject;

namespace TianYuan_New.Windows
{
    public partial class RegisterPay : MyDialog
    {
        private string rc001 = string.Empty;
        private decimal bitprice = decimal.Zero;
        private DataTable dt_rc04 = new DataTable("RC04");
        private OracleDataAdapter rc04Adapter = new OracleDataAdapter("",SqlAssist.conn);



        public RegisterPay()
        {
            InitializeComponent();
        }

        private void RegisterPay_Load(object sender, EventArgs e)
        {
            string s_rc130 = string.Empty;

            rc001 = this.cdata["RC001"].ToString();

            OracleDataReader reader = SqlAssist.ExecuteReader("select * from rc01 where rc001='" + rc001 + "'");
            while (reader.Read())
            {
                txtEdit_rc001.Text = rc001;
                txtEdit_rc109.EditValue = reader["RC109"];
                txtEdit_rc003.EditValue = reader["RC003"];
                txtEdit_rc303.EditValue = reader["RC303"];
                txtEdit_rc004.EditValue = reader["RC004"];
                txtEdit_rc404.EditValue = reader["RC404"];
                rg_rc002.EditValue = reader["RC002"];
                rg_rc202.EditValue = reader["RC202"];
                be_position.Text = RegisterAction.GetRegPathName(rc001);

                s_rc130 = reader["RC130"].ToString();
                bitprice = Convert.ToDecimal(SqlAssist.ExecuteScalar("select bi009 from bi01 where bi001='" + s_rc130 + "'", null));
                txtedit_price.EditValue = bitprice;
            }

            rc04Adapter.SelectCommand.CommandText = "select * from v_rc04 where rc001='" + rc001 + "' order by rc020";
            rc04Adapter.Fill(dt_rc04);
            gridControl1.DataSource = dt_rc04;

            comboBox1.Text = "";
        }

        private void gridView1_CustomColumnDisplayText(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventArgs e)
        {
            if(e.Column.FieldName == "RC031")  //缴费类型
            {
                if (e.Value.ToString() == "1")
                    e.DisplayText = "正常";
                else if(e.Value.ToString() == "0")
                {
                    e.DisplayText = "原始登记";
                }
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.Text)) return;
            int nums = int.Parse(comboBox1.Text);
            if(nums > 0 && bitprice>0)
            {
                txtedit_regfee.EditValue = nums * bitprice;
            }
        }

        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            int nums;
            if (!int.TryParse(comboBox1.Text, out nums))
            {
                e.Cancel = true;
                MessageBox.Show("请输入正确的缴费年限!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void b_ok_Click(object sender, EventArgs e)
        {
            int nums;
            int rowCount,rmod;
            if (!int.TryParse(comboBox1.Text, out nums))
            {
                MessageBox.Show("请输入正确的缴费年限!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!(bitprice > 0))
            {
                MessageBox.Show("参数传递错误!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string fa001 = Tools.GetEntityPK("FA01");
            int re = RegisterAction.RegisterPay(rc001, fa001, bitprice, nums, Envior.cur_userId);
            if (re > 0)
            {
                dt_rc04.Clear();
                rc04Adapter.Fill(dt_rc04);

                if (MessageBox.Show("现在打印缴费记录吗?","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    //打印缴费记录
                    rowCount = gridView1.RowCount;
                    rmod = rowCount % 11;
                    if(rmod == 0)
                    {
                        rmod = 11;
                    }
                    if(rmod == 1 && rowCount > 1)
                    {
                        MessageBox.Show("注意,请更换新证打印!", "提示");
                    }
                    PrtPayRecord(fa001); 
                }

                if (MessageBox.Show("现在打印收据吗?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    this.Print_invoice(fa001);
                }

                DialogResult = DialogResult.OK;
                this.Close();
            }            
        }

        /// <summary>
        /// 打印缴费记录(寄存证)
        /// </summary>
        /// <param name="fa001"></param>
        private void PrtPayRecord(string fa001)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         this.Handle.ToInt32(),
                                         commandNum,
                                         "Register_payrecord",
                                         fa001,
                                         null
                );
        }

        /// <summary>
        /// 打印收据
        /// </summary>
        /// <param name="settleId"></param>
        private void Print_invoice(string settleId)
        {
            int commandNum = PrtServAction.GenNewCommandNum();
            PrtServAction.SendPrtCommand(Envior.prtConnId,
                                         this.Handle.ToInt32(),
                                         commandNum,
                                         "Register_payInvoice",
                                         settleId,
                                         null
                );
        }
    }
}