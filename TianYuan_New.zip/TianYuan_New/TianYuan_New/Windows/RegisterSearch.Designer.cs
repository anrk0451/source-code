﻿namespace TianYuan_New.Windows
{
    partial class RegisterSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtedit_rc003 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtedit_rc109 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtedit_rc001 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc050 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.lookup_rc110 = new DevExpress.XtraEditors.LookUpEdit();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.b_exit = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc003.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc109.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc001.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc050.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookup_rc110.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtedit_rc003
            // 
            this.txtedit_rc003.Location = new System.Drawing.Point(109, 74);
            this.txtedit_rc003.Name = "txtedit_rc003";
            this.txtedit_rc003.Size = new System.Drawing.Size(148, 24);
            this.txtedit_rc003.TabIndex = 11;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(29, 77);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(60, 18);
            this.labelControl3.TabIndex = 10;
            this.labelControl3.Text = "逝者姓名";
            // 
            // txtedit_rc109
            // 
            this.txtedit_rc109.Location = new System.Drawing.Point(443, 26);
            this.txtedit_rc109.Name = "txtedit_rc109";
            this.txtedit_rc109.Size = new System.Drawing.Size(148, 24);
            this.txtedit_rc109.TabIndex = 9;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(359, 29);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(60, 18);
            this.labelControl2.TabIndex = 8;
            this.labelControl2.Text = "寄存证号";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(29, 29);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(60, 18);
            this.labelControl1.TabIndex = 7;
            this.labelControl1.Text = "逝者编号";
            // 
            // txtedit_rc001
            // 
            this.txtedit_rc001.Location = new System.Drawing.Point(109, 26);
            this.txtedit_rc001.Name = "txtedit_rc001";
            this.txtedit_rc001.Properties.Mask.EditMask = "d";
            this.txtedit_rc001.Size = new System.Drawing.Size(148, 24);
            this.txtedit_rc001.TabIndex = 6;
            this.txtedit_rc001.EditValueChanged += new System.EventHandler(this.txtedit_rc001_EditValueChanged);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(332, 77);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(87, 18);
            this.labelControl4.TabIndex = 12;
            this.labelControl4.Text = "家属(联系人)";
            // 
            // txtEdit_rc050
            // 
            this.txtEdit_rc050.Location = new System.Drawing.Point(443, 74);
            this.txtEdit_rc050.Name = "txtEdit_rc050";
            this.txtEdit_rc050.Size = new System.Drawing.Size(148, 24);
            this.txtEdit_rc050.TabIndex = 13;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(29, 128);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(45, 18);
            this.labelControl5.TabIndex = 14;
            this.labelControl5.Text = "寄存室";
            // 
            // lookup_rc110
            // 
            this.lookup_rc110.Location = new System.Drawing.Point(109, 125);
            this.lookup_rc110.Name = "lookup_rc110";
            this.lookup_rc110.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookup_rc110.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("RG003", "字体1")});
            this.lookup_rc110.Properties.NullText = "";
            this.lookup_rc110.Properties.ShowHeader = false;
            this.lookup_rc110.Size = new System.Drawing.Size(148, 24);
            this.lookup_rc110.TabIndex = 15;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.BackColor = System.Drawing.Color.Lime;
            this.simpleButton1.Appearance.ForeColor = System.Drawing.Color.White;
            this.simpleButton1.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.simpleButton1.Appearance.Options.UseBackColor = true;
            this.simpleButton1.Appearance.Options.UseForeColor = true;
            this.simpleButton1.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.simpleButton1.Location = new System.Drawing.Point(365, 179);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(157, 29);
            this.simpleButton1.TabIndex = 44;
            this.simpleButton1.Text = "确定";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // b_exit
            // 
            this.b_exit.Appearance.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b_exit.Appearance.ForeColor = System.Drawing.Color.SlateGray;
            this.b_exit.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_exit.Appearance.Options.UseBackColor = true;
            this.b_exit.Appearance.Options.UseForeColor = true;
            this.b_exit.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.b_exit.Location = new System.Drawing.Point(529, 179);
            this.b_exit.Name = "b_exit";
            this.b_exit.Size = new System.Drawing.Size(72, 29);
            this.b_exit.TabIndex = 43;
            this.b_exit.Text = "退出";
            // 
            // RegisterSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.b_exit;
            this.ClientSize = new System.Drawing.Size(660, 229);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.b_exit);
            this.Controls.Add(this.lookup_rc110);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.txtEdit_rc050);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.txtedit_rc003);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.txtedit_rc109);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.txtedit_rc001);
            this.Name = "RegisterSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "寄存查询条件";
            this.Load += new System.EventHandler(this.RegisterSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc003.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc109.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc001.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc050.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookup_rc110.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtedit_rc003;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtedit_rc109;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtedit_rc001;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc050;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LookUpEdit lookup_rc110;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton b_exit;
    }
}