﻿namespace TianYuan_New.Windows
{
    partial class Register_edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEdit_rc109 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc001 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.be_position = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc404 = new DevExpress.XtraEditors.TextEdit();
            this.rg_rc202 = new DevExpress.XtraEditors.RadioGroup();
            this.txtEdit_rc303 = new DevExpress.XtraEditors.TextEdit();
            this.mem_rc099 = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_ac055 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc051 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.lookUp_rc052 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc050 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtedit_rc014 = new DevExpress.XtraEditors.TextEdit();
            this.txtEdit_rc004 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.rg_rc002 = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtEdit_rc003 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.b_exit = new DevExpress.XtraEditors.SimpleButton();
            this.b_ok = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc109.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc001.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.be_position.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc404.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc202.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc303.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_rc099.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac055.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc051.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_rc052.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc050.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc014.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc004.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc002.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc003.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEdit_rc109
            // 
            this.txtEdit_rc109.Enabled = false;
            this.txtEdit_rc109.Location = new System.Drawing.Point(329, 22);
            this.txtEdit_rc109.Name = "txtEdit_rc109";
            this.txtEdit_rc109.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_rc109.TabIndex = 123;
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(247, 25);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(60, 18);
            this.labelControl13.TabIndex = 122;
            this.labelControl13.Text = "寄存证号";
            // 
            // txtEdit_rc001
            // 
            this.txtEdit_rc001.Enabled = false;
            this.txtEdit_rc001.Location = new System.Drawing.Point(113, 22);
            this.txtEdit_rc001.Name = "txtEdit_rc001";
            this.txtEdit_rc001.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_rc001.TabIndex = 121;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(27, 25);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(60, 18);
            this.labelControl8.TabIndex = 120;
            this.labelControl8.Text = "逝者编号";
            // 
            // be_position
            // 
            this.be_position.Enabled = false;
            this.be_position.Location = new System.Drawing.Point(114, 64);
            this.be_position.Name = "be_position";
            this.be_position.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.be_position.Properties.ReadOnly = true;
            this.be_position.Size = new System.Drawing.Size(448, 24);
            this.be_position.TabIndex = 113;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(27, 66);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(68, 18);
            this.labelControl16.TabIndex = 112;
            this.labelControl16.Text = "寄存位置*";
            // 
            // txtEdit_rc404
            // 
            this.txtEdit_rc404.Location = new System.Drawing.Point(509, 146);
            this.txtEdit_rc404.Name = "txtEdit_rc404";
            this.txtEdit_rc404.Properties.Mask.BeepOnError = true;
            this.txtEdit_rc404.Properties.Mask.EditMask = "n0";
            this.txtEdit_rc404.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_rc404.Size = new System.Drawing.Size(53, 24);
            this.txtEdit_rc404.TabIndex = 111;
            // 
            // rg_rc202
            // 
            this.rg_rc202.EditValue = "1";
            this.rg_rc202.Location = new System.Drawing.Point(281, 146);
            this.rg_rc202.Name = "rg_rc202";
            this.rg_rc202.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rg_rc202.Properties.Appearance.Options.UseBackColor = true;
            this.rg_rc202.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rg_rc202.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("0", "男"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("1", "女"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("2", "未知")});
            this.rg_rc202.Size = new System.Drawing.Size(165, 24);
            this.rg_rc202.TabIndex = 110;
            // 
            // txtEdit_rc303
            // 
            this.txtEdit_rc303.Location = new System.Drawing.Point(114, 146);
            this.txtEdit_rc303.Name = "txtEdit_rc303";
            this.txtEdit_rc303.Size = new System.Drawing.Size(89, 24);
            this.txtEdit_rc303.TabIndex = 109;
            // 
            // mem_rc099
            // 
            this.mem_rc099.Location = new System.Drawing.Point(114, 357);
            this.mem_rc099.Name = "mem_rc099";
            this.mem_rc099.Size = new System.Drawing.Size(448, 96);
            this.mem_rc099.TabIndex = 108;
            // 
            // labelControl14
            // 
            this.labelControl14.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl14.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl14.LineVisible = true;
            this.labelControl14.Location = new System.Drawing.Point(27, 358);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(30, 18);
            this.labelControl14.TabIndex = 107;
            this.labelControl14.Text = "备注";
            // 
            // txtEdit_ac055
            // 
            this.txtEdit_ac055.Location = new System.Drawing.Point(114, 310);
            this.txtEdit_ac055.Name = "txtEdit_ac055";
            this.txtEdit_ac055.Size = new System.Drawing.Size(448, 24);
            this.txtEdit_ac055.TabIndex = 106;
            // 
            // labelControl12
            // 
            this.labelControl12.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl12.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl12.LineVisible = true;
            this.labelControl12.Location = new System.Drawing.Point(27, 316);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(60, 18);
            this.labelControl12.TabIndex = 105;
            this.labelControl12.Text = "联系地址";
            // 
            // txtEdit_rc051
            // 
            this.txtEdit_rc051.Location = new System.Drawing.Point(114, 270);
            this.txtEdit_rc051.Name = "txtEdit_rc051";
            this.txtEdit_rc051.Size = new System.Drawing.Size(448, 24);
            this.txtEdit_rc051.TabIndex = 104;
            // 
            // labelControl11
            // 
            this.labelControl11.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl11.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl11.LineVisible = true;
            this.labelControl11.Location = new System.Drawing.Point(27, 274);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(68, 18);
            this.labelControl11.TabIndex = 103;
            this.labelControl11.Text = "联系电话*";
            // 
            // lookUp_rc052
            // 
            this.lookUp_rc052.Location = new System.Drawing.Point(352, 231);
            this.lookUp_rc052.Name = "lookUp_rc052";
            this.lookUp_rc052.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUp_rc052.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST001", "编号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ST003", "值"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("SORTID", "排序号", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.Ascending, DevExpress.Utils.DefaultBoolean.Default)});
            this.lookUp_rc052.Properties.NullText = "";
            this.lookUp_rc052.Properties.ShowHeader = false;
            this.lookUp_rc052.Size = new System.Drawing.Size(114, 24);
            this.lookUp_rc052.TabIndex = 102;
            this.lookUp_rc052.EditValueChanged += new System.EventHandler(this.lookUp_rc052_EditValueChanged);
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(256, 234);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(83, 18);
            this.labelControl10.TabIndex = 101;
            this.labelControl10.Text = "与逝者关系*";
            // 
            // txtEdit_rc050
            // 
            this.txtEdit_rc050.Location = new System.Drawing.Point(114, 231);
            this.txtEdit_rc050.Name = "txtEdit_rc050";
            this.txtEdit_rc050.Size = new System.Drawing.Size(122, 24);
            this.txtEdit_rc050.TabIndex = 100;
            // 
            // labelControl9
            // 
            this.labelControl9.LineLocation = DevExpress.XtraEditors.LineLocation.Center;
            this.labelControl9.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl9.LineVisible = true;
            this.labelControl9.Location = new System.Drawing.Point(27, 234);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(53, 18);
            this.labelControl9.TabIndex = 99;
            this.labelControl9.Text = "联系人*";
            // 
            // txtedit_rc014
            // 
            this.txtedit_rc014.Location = new System.Drawing.Point(114, 188);
            this.txtedit_rc014.Name = "txtedit_rc014";
            this.txtedit_rc014.Size = new System.Drawing.Size(448, 24);
            this.txtedit_rc014.TabIndex = 98;
            this.txtedit_rc014.Validating += new System.ComponentModel.CancelEventHandler(this.txtedit_rc014_Validating);
            // 
            // txtEdit_rc004
            // 
            this.txtEdit_rc004.Location = new System.Drawing.Point(509, 107);
            this.txtEdit_rc004.Name = "txtEdit_rc004";
            this.txtEdit_rc004.Properties.Mask.BeepOnError = true;
            this.txtEdit_rc004.Properties.Mask.EditMask = "n0";
            this.txtEdit_rc004.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEdit_rc004.Size = new System.Drawing.Size(53, 24);
            this.txtEdit_rc004.TabIndex = 97;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(459, 111);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(38, 18);
            this.labelControl3.TabIndex = 96;
            this.labelControl3.Text = "年龄*";
            // 
            // rg_rc002
            // 
            this.rg_rc002.EditValue = "0";
            this.rg_rc002.Location = new System.Drawing.Point(281, 107);
            this.rg_rc002.Name = "rg_rc002";
            this.rg_rc002.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rg_rc002.Properties.Appearance.Options.UseBackColor = true;
            this.rg_rc002.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rg_rc002.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("0", "男"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("1", "女"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("2", "未知")});
            this.rg_rc002.Size = new System.Drawing.Size(165, 24);
            this.rg_rc002.TabIndex = 95;
            this.rg_rc002.SelectedIndexChanged += new System.EventHandler(this.rg_rc002_SelectedIndexChanged);
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(237, 111);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(38, 18);
            this.labelControl2.TabIndex = 94;
            this.labelControl2.Text = "性别*";
            // 
            // txtEdit_rc003
            // 
            this.txtEdit_rc003.Location = new System.Drawing.Point(114, 107);
            this.txtEdit_rc003.Name = "txtEdit_rc003";
            this.txtEdit_rc003.Size = new System.Drawing.Size(89, 24);
            this.txtEdit_rc003.TabIndex = 93;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(27, 192);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(60, 18);
            this.labelControl4.TabIndex = 92;
            this.labelControl4.Text = "身份证号";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(27, 111);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(68, 18);
            this.labelControl1.TabIndex = 91;
            this.labelControl1.Text = "逝者姓名*";
            // 
            // b_exit
            // 
            this.b_exit.Appearance.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.b_exit.Appearance.ForeColor = System.Drawing.Color.Snow;
            this.b_exit.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_exit.Appearance.Options.UseBackColor = true;
            this.b_exit.Appearance.Options.UseForeColor = true;
            this.b_exit.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.b_exit.Location = new System.Drawing.Point(583, 67);
            this.b_exit.Name = "b_exit";
            this.b_exit.Size = new System.Drawing.Size(119, 31);
            this.b_exit.TabIndex = 124;
            this.b_exit.Text = "退出";
            this.b_exit.Click += new System.EventHandler(this.b_exit_Click);
            // 
            // b_ok
            // 
            this.b_ok.Appearance.BackColor = System.Drawing.Color.Lime;
            this.b_ok.Appearance.ForeColor = System.Drawing.Color.White;
            this.b_ok.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.b_ok.Appearance.Options.UseBackColor = true;
            this.b_ok.Appearance.Options.UseForeColor = true;
            this.b_ok.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.b_ok.Location = new System.Drawing.Point(583, 25);
            this.b_ok.Name = "b_ok";
            this.b_ok.Size = new System.Drawing.Size(119, 31);
            this.b_ok.TabIndex = 125;
            this.b_ok.Text = "确定";
            this.b_ok.Click += new System.EventHandler(this.b_ok_Click);
            // 
            // Register_edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.b_exit;
            this.ClientSize = new System.Drawing.Size(723, 471);
            this.Controls.Add(this.b_exit);
            this.Controls.Add(this.b_ok);
            this.Controls.Add(this.txtEdit_rc109);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.txtEdit_rc001);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.be_position);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.txtEdit_rc404);
            this.Controls.Add(this.rg_rc202);
            this.Controls.Add(this.txtEdit_rc303);
            this.Controls.Add(this.mem_rc099);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.txtEdit_ac055);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.txtEdit_rc051);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.lookUp_rc052);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.txtEdit_rc050);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.txtedit_rc014);
            this.Controls.Add(this.txtEdit_rc004);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.rg_rc002);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtEdit_rc003);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl1);
            this.Name = "Register_edit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "寄存信息修改";
            this.Load += new System.EventHandler(this.Register_edit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc109.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc001.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.be_position.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc404.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc202.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc303.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mem_rc099.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_ac055.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc051.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUp_rc052.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc050.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtedit_rc014.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc004.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rg_rc002.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEdit_rc003.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtEdit_rc109;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc001;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.ButtonEdit be_position;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc404;
        private DevExpress.XtraEditors.RadioGroup rg_rc202;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc303;
        private DevExpress.XtraEditors.MemoEdit mem_rc099;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtEdit_ac055;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc051;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LookUpEdit lookUp_rc052;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc050;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtedit_rc014;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc004;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.RadioGroup rg_rc002;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtEdit_rc003;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton b_exit;
        private DevExpress.XtraEditors.SimpleButton b_ok;
    }
}