﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Linq;

namespace TianYuan_New.Windows
{
    public partial class TestWin : MyDialog
    {
        private DataTable dt_fa01 = new DataTable();
        private OracleDataAdapter fa01Adapter = new OracleDataAdapter("select * from fa01", SqlAssist.conn);

        public TestWin()
        {
            InitializeComponent();
        }

        private void TestWin_Load(object sender, EventArgs e)
        {
            gridControl1.DataSource = dt_fa01;
            fa01Adapter.Fill(dt_fa01);

            gridCol_Fa004.SummaryItem.SummaryType = DevExpress.Data.SummaryItemType.Sum;
            gridCol_Fa004.SummaryItem.DisplayFormat = "Sum = {0:N2}";

           
        }
    }
}