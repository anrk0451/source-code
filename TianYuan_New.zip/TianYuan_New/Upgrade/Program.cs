﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace Upgrade
{
    class Program
    {
        static void Main(string[] args)
        {
            if(args.Count() <= 0)
            {
                return;
            }
            string targetDir = args[0];
            DirectoryInfo Dir = new DirectoryInfo(Directory.GetCurrentDirectory() + "\\" + targetDir);

            foreach (FileInfo fileInfo in Dir.GetFiles())
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + fileInfo.Name))
                {
                    File.Delete(Directory.GetCurrentDirectory() + "\\" + fileInfo.Name);
                }
                fileInfo.MoveTo(Directory.GetCurrentDirectory() + "\\" + fileInfo.Name);
            }

            Dir.Delete();

            Process myProcess = new Process();
            try
            {
                myProcess.StartInfo.UseShellExecute = false;
                myProcess.StartInfo.FileName = "tianyuan_new.exe";
                //myProcess.StartInfo.CreateNoWindow = true;
                myProcess.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return;
        }
    }
}
