--1. �����ֵ�� 
insert into st01
select pkg_business.fun_EntityPk('ST01'),
       'DIEREASON',
       dictvalue0,
       sortId,
       isused
  from tianyuan.DICTIONARY 
  where dicttype = 'DieReason';

insert into st01
select pkg_business.fun_EntityPk('ST01'),
       'DISTRICT',
       dictvalue0,
       sortId,
       isused
  from tianyuan.DICTIONARY 
  where dicttype = 'District';
  
insert into st01
select pkg_business.fun_EntityPk('ST01'),
       'RELATION',
       dictvalue0,
       sortId,
       isused
  from tianyuan.DICTIONARY 
  where dicttype = 'Relation';  

--ֻ��˾����ҵ������Ǵ���  
insert into st01
select pkg_business.fun_EntityPk('ST01'),
       'DRIVER',
       dictvalue0,
       sortId,
       isused
  from tianyuan.DICTIONARY 
  where dicttype = 'Driver';    

--2.������Ϣ
insert into si01
select lpad(feelevelId,10,'0'),
       serviceSalesType,
       servicedesc,
       fixprice,
       '0',
       sortId,
       status,
       null
  from tianyuan.serviceinfo 
 where serviceSalesType in ('01','02','03','04','07');
 
       
insert into si01
select lpad(feelevelId,10,'0'),
       '05',
       servicedesc,
       nvl(fixprice,0)
       '0',
       sortId,
       status,
       null
  from tianyuan.serviceinfo   
 where serviceSalesType in ('05','06');

insert into si01
select lpad(feelevelId,10,'0'),
       '06',
       servicedesc,
       nvl(fixprice,0),
       '0',
       sortId,
       status,
       null
  from tianyuan.serviceinfo   
 where serviceSalesType = '09';
 
--����Ʒ
insert into gi01
select lpad(commodityId,10,'0'), 
       serviceSalesType,
       commodityname,
       fixprice,
       null,
       sortId,
       status,
       null
  from tianyuan.commodity;

--�ײͱ�
insert into cb01
select lpad(comboId,10,'0'),
       '1',
       COMBONAME,
       null,
       '1'
  from tianyuan.combo where  status = 1;

insert into cb02
select pkg_business.fun_EntityPk('CB01'),
       lpad(comboId,10,'0'),
       lpad(salesItemId,10,'0'),
       serviceType,
       nums
 from tianyuan.combolist where comboId in 
 (select comboId from combo where status = 1);
           
 


  
  
